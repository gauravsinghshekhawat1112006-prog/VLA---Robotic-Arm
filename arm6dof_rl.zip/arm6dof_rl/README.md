# 6-DOF Robotic Arm: Precision Reaching & Obstacle Avoidance with RL (MuJoCo + Gymnasium)

Upgrade of the IIT Roorkee *3-DOF Planar Manipulator* problem statement to a **6-DOF spatial arm** that
reaches arbitrary 3-D points in its workspace while avoiding randomly placed spherical obstacles.
Physics runs in **MuJoCo**, the task is a custom **Gymnasium** environment, and the policy is trained
with **SAC** (PPO also supported) from Stable-Baselines3 on a laptop CPU.

## How the arm learns (no manual training)

You never move the arm yourself and you never provide demonstrations. Training is fully automatic
trial-and-error:

1. `reset()` builds a new random scenario: random start pose, random target point in 3-D, random
   obstacle (often placed right on the arm's natural path).
2. The neural-network policy looks at the observation and outputs 6 joint velocity commands.
   At first these are essentially random.
3. MuJoCo simulates 20 ms of physics; the environment computes the reward
   (closer = better, collisions = −100, big joint commands = small penalty, holding at the target = +200).
4. The episode ends by itself on **success**, **collision**, or after **200 steps (4 s)**; a new random
   episode starts immediately.
5. SAC stores every transition in a replay buffer and continuously updates the network so that
   actions leading to higher long-term reward become more likely.

This loop repeats for thousands of episodes with no rendering, so simulated time runs far faster than
real time (1.5 M steps ≈ 8 hours of simulated arm motion). All you do is run `python train.py` and wait.
Your only "manual" job as the engineer is designing the environment and reward — and, if learning
stalls, tuning them.

**Expected training time on an HP Victus-class laptop (CPU):** roughly 1–3 h for 1.5 M steps with SAC.
Reaching usually emerges within the first ~200–400 k steps; reliable obstacle avoidance takes longer.

## What changed from the 3-DOF brief

| | 3-DOF brief | This project |
|---|---|---|
| Workspace | 2-D plane | 3-D, full 360° around the base |
| Joints | 3 revolute | 6 revolute: base yaw, shoulder, elbow, forearm roll, wrist pitch, wrist roll |
| Physics / render | custom + Pygame | MuJoCo (contacts, inertia, gravity, servo dynamics) + MuJoCo renderer |
| Obstacles | circle (x, y, r) | sphere(s) (x, y, z, r), 1 by default, up to 3 |
| Collision | segment/circle test | exact MuJoCo contact detection on every arm geom (and the floor) |

"Any arbitrary point" means any point inside the reachable workspace: a spherical shell of radius
0.20–0.65 m around the shoulder (max physical reach 0.73 m), above the floor and outside the base column.
`tests/test_env.py` verifies with inverse kinematics that sampled targets are genuinely reachable.

## MDP

**Observation (35 floats with 1 obstacle):** cos/sin of the 6 joint angles, 6 angular velocities,
end-effector position, target position, goal vector (target − EE), and for each obstacle its centre,
radius, centre − EE, and the current minimum clearance between the arm surface and the obstacle.

**Action:** 6 values in [−1, 1] = normalised target angular velocity (the brief allows torques *or* target
velocities). Each step the command is integrated into joint set-points tracked by MuJoCo position servos
(max 1.5 rad/s). This is far easier to learn than raw torques and still fully physically simulated.

**Reward per step (20 ms):**

| term | formula | purpose |
|---|---|---|
| distance | −d | precision; d = EE-to-target distance in metres |
| energy | −α Σ aᵢ², α = 0.01 | smooth, economical motion |
| collision | −100 and terminate | any arm geom touches an obstacle or the floor |
| success | +200 and terminate | d < 3 cm for 10 consecutive steps (0.2 s) |
| proximity *(added)* | −0.5 · Σ max(0, 1 − clearance / 5 cm) | early warning signal before a collision; set `proximity_weight=0` for the pure brief reward |

All values are constructor arguments of `Arm6DOFReachEnv` (tolerance, hold frames, α, penalties, number
of obstacles, episode length, …).

## Project layout

```
arm6dof/
  assets/arm6dof.xml   MuJoCo model (arm, floor, target marker, 3 obstacle slots, cameras)
  kinematics.py        forward kinematics (homogeneous transforms), Jacobian, DLS inverse kinematics
  env.py               Gymnasium environment Arm6DOFReachEnv
  __init__.py          registers Arm6DOFReach-v0 and Arm6DOFReach3Obs-v0
view_model.py          step 1: open the arm in the MuJoCo viewer (sweep / IK / random / policy modes)
train.py               SAC or PPO training with eval + checkpoints
evaluate.py            100-episode evaluation -> metrics JSON/CSV + plots
plot_training.py       reward & success-rate learning curves
record_video.py        MP4 demo of successful obstacle-avoidance episodes
tests/test_env.py      FK/Jacobian vs MuJoCo, env API, reachability, collision & success logic
models/best_model.zip  trained weights (PyTorch, SB3 format)
results/               plots, metrics, demo video
```

## Quick start

```bash
python -m venv .venv && .venv\Scripts\activate        # Windows (Linux/macOS: source .venv/bin/activate)
pip install -r requirements.txt
python -m pytest -q tests/                             # 6 tests should pass

python view_model.py                                   # 1. see the arm move in MuJoCo
python view_model.py --mode ik                         #    classical IK reaching (no obstacles, no RL)

python train.py --run-name sac_main                    # 2. train (Ctrl+C at any time saves weights)
tensorboard --logdir runs                              #    optional live curves

python plot_training.py --run runs/sac_main            # 3. learning curves   -> results/*.png
python evaluate.py --episodes 100                      # 4. success metrics  -> results/eval_metrics.json
python record_video.py --n 4                           # 5. demo video       -> results/demo.mp4
python view_model.py --mode policy                     #    watch the agent live
```

Continue training from a checkpoint: `python train.py --resume runs/sac_main/checkpoints/sac_1000000_steps.zip --run-name sac_more`.
Harder task (up to 3 obstacles): `python train.py --env-id Arm6DOFReach3Obs-v0`.

## Tuning tips

* **More CPU cores → faster:** `--n-envs 8 --subproc`. For SAC keep `--device cpu`; small MLPs are
  usually slower on the GPU. PPO with `--n-envs 16 --subproc` is also a good option on multi-core CPUs.
* **Success rate plateaus with frequent timeouts** (hovering 3–6 cm away): train longer, or start with
  `success_tol=0.05` and tighten later (curriculum).
* **Many collisions:** raise `proximity_weight` or `safety_margin`.
* **Arm learns to crash on purpose** (collision early rather than accumulate −d): lower
  `collision_penalty` is *not* the fix; instead shorten `max_steps` or scale the distance term.
* Evaluation seeds (2026+) are never used in training, so eval numbers measure generalisation to new targets
  and obstacle layouts.

## Results

After training, fill this in from `results/eval_metrics.json` and the plots in `results/`.
