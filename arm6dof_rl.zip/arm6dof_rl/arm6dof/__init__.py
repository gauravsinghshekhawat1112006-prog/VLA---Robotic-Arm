"""6-DOF MuJoCo arm reaching + obstacle-avoidance environment."""
from gymnasium.envs.registration import register

from .env import Arm6DOFReachEnv  # noqa: F401

register(
    id="Arm6DOFReach-v0",
    entry_point="arm6dof.env:Arm6DOFReachEnv",
    kwargs={"n_obstacles": 1},
)
# Harder variant: up to 3 obstacles
register(
    id="Arm6DOFReach3Obs-v0",
    entry_point="arm6dof.env:Arm6DOFReachEnv",
    kwargs={"n_obstacles": 3, "obstacle_prob": 0.8},
)
