"""
Arm6DOFReachEnv – Gymnasium environment for a 6-DOF MuJoCo arm that must bring
its end-effector to a random 3-D target while avoiding random spherical obstacles.

MDP (3-D generalisation of the original 3-DOF problem statement)
-----------------------------------------------------------------
Observation (27 + 8*n_obstacles floats):
    cos(q) (6), sin(q) (6)          joint angles (wrap-safe encoding)
    omega * 0.1 (6)                 joint angular velocities
    p_ee (3), p_target (3)          end-effector and target positions
    p_target - p_ee (3)             goal vector
    per obstacle: centre (3), radius (1), centre - p_ee (3), clearance (1)
Action (6,) in [-1, 1]:
    normalised TARGET ANGULAR VELOCITY per joint (option allowed by the brief).
    It is integrated into joint position set-points tracked by MuJoCo servos,
    which is far easier to learn than raw torque while staying physically simulated.
Reward per control step:
    R = -d                                    distance term
        - alpha * sum(a_i^2)                  energy / smoothness term
        - w_prox * sum(max(0, 1 - c_k/m))     (optional) soft proximity shaping
        - 100  and terminate                  if any arm geom touches an obstacle/floor
        + 200  and terminate                  if d < tol for `success_hold` consecutive steps
Episode ends on success, collision, or after `max_steps` steps (truncation).
"""
from __future__ import annotations

import os
import time

import gymnasium as gym
import mujoco
import numpy as np
from gymnasium import spaces

from . import kinematics as K

XML_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "arm6dof.xml")
MAX_OBSTACLES = 3
PARK_POS = np.array([10.0, 0.0, 0.5])


def _seg_point_dist(p, a, b):
    ab = b - a
    t = np.clip(np.dot(p - a, ab) / max(np.dot(ab, ab), 1e-12), 0.0, 1.0)
    return np.linalg.norm(p - (a + t * ab))


class Arm6DOFReachEnv(gym.Env):
    metadata = {"render_modes": ["human", "rgb_array"], "render_fps": 50}

    def __init__(
        self,
        render_mode: str | None = None,
        n_obstacles: int = 1,
        obstacle_prob: float = 1.0,      # probability each obstacle is present in an episode
        block_prob: float = 0.7,         # probability an obstacle is placed ON the start->target line
        obstacle_radius=(0.04, 0.08),
        max_steps: int = 200,
        success_tol: float = 0.03,       # metres
        success_hold: int = 10,          # consecutive control steps inside tolerance
        alpha_energy: float = 0.01,
        collision_penalty: float = 100.0,
        success_bonus: float = 200.0,
        proximity_weight: float = 0.5,   # set 0.0 for the "pure" reward of the brief
        safety_margin: float = 0.05,
        frame_skip: int = 10,            # 10 x 2 ms = 20 ms control period (50 Hz)
        max_joint_vel: float = 1.5,      # rad/s at |a| = 1
        target_radius=(0.20, 0.65),      # distance of target from shoulder centre
        camera: str = "main",
        width: int = 960,
        height: int = 720,
    ):
        super().__init__()
        assert 0 <= n_obstacles <= MAX_OBSTACLES
        self.render_mode = render_mode
        self.n_obstacles = n_obstacles
        self.obstacle_prob = obstacle_prob
        self.block_prob = block_prob
        self.obstacle_radius = obstacle_radius
        self.max_steps = max_steps
        self.success_tol = success_tol
        self.success_hold = success_hold
        self.alpha_energy = alpha_energy
        self.collision_penalty = collision_penalty
        self.success_bonus = success_bonus
        self.proximity_weight = proximity_weight
        self.safety_margin = safety_margin
        self.frame_skip = frame_skip
        self.max_joint_vel = max_joint_vel
        self.target_radius = target_radius
        self.camera, self.width, self.height = camera, width, height

        # ---- MuJoCo model (each env instance owns its own copy, so edits are safe)
        self.model = mujoco.MjModel.from_xml_path(XML_PATH)
        self.data = mujoco.MjData(self.model)
        self.dt = self.model.opt.timestep * frame_skip
        self.metadata["render_fps"] = int(round(1.0 / self.dt))

        m = self.model
        self.ee_site = m.site("ee").id
        self.target_mocap = m.body_mocapid[m.body("target").id]
        self.target_geom = m.geom("target_geom").id
        self.obs_mocap = [m.body_mocapid[m.body(f"obs{i}").id] for i in range(MAX_OBSTACLES)]
        self.obs_geom = [m.geom(f"obs{i}_geom").id for i in range(MAX_OBSTACLES)]
        self.floor_geom = m.geom("floor").id
        self.arm_geoms = np.array([g for g in range(m.ngeom) if m.geom_contype[g] == 1])
        self.hazard_geoms = set([self.floor_geom] + self.obs_geom)
        self.arm_geom_set = set(self.arm_geoms.tolist())
        self.q_lo = m.jnt_range[:, 0].copy()
        self.q_hi = m.jnt_range[:, 1].copy()
        self.model.geom_size[self.target_geom, 0] = success_tol

        # ---- spaces
        obs_dim = 27 + 8 * n_obstacles
        self.observation_space = spaces.Box(-np.inf, np.inf, shape=(obs_dim,), dtype=np.float32)
        self.action_space = spaces.Box(-1.0, 1.0, shape=(6,), dtype=np.float32)

        # ---- episode state
        self.q_des = np.zeros(6)
        self.target = np.zeros(3)
        self.obstacles = np.zeros((n_obstacles, 4))   # x, y, z, r
        self.obs_active = np.zeros(n_obstacles, dtype=bool)
        self.blocking = False
        self.steps = 0
        self.hold = 0
        self._renderer = None
        self._viewer = None

    # ------------------------------------------------------------------ helpers
    @property
    def ee_pos(self) -> np.ndarray:
        return self.data.site_xpos[self.ee_site].copy()

    def _sample_target(self) -> np.ndarray:
        rmin, rmax = self.target_radius
        while True:
            r = self.np_random.uniform(rmin ** 3, rmax ** 3) ** (1 / 3)  # uniform in volume
            v = self.np_random.normal(size=3)
            p = K.SHOULDER + r * v / np.linalg.norm(v)
            if p[2] < 0.08:                      # not in / too close to the floor
                continue
            if np.linalg.norm(p[:2]) < 0.12:     # not inside the base column
                continue
            return p

    def _path_point(self, a: np.ndarray, b: np.ndarray, t: float) -> np.ndarray:
        """Point at fraction t along a 'natural' path from a to b: either the straight
        line or the cylindrical arc around the base axis (how a yawing arm moves)."""
        if self.np_random.random() < 0.5:
            return a + t * (b - a)
        ra, rb = np.linalg.norm(a[:2]), np.linalg.norm(b[:2])
        pa, pb = np.arctan2(a[1], a[0]), np.arctan2(b[1], b[0])
        dphi = (pb - pa + np.pi) % (2 * np.pi) - np.pi
        phi, rad = pa + t * dphi, ra + t * (rb - ra)
        return np.array([rad * np.cos(phi), rad * np.sin(phi), a[2] + t * (b[2] - a[2])])

    def _arm_clearance(self, centre: np.ndarray, radius: float) -> float:
        """Minimum surface-to-surface distance between a sphere and all arm geoms."""
        m, d = self.model, self.data
        best = np.inf
        for g in self.arm_geoms:
            c = d.geom_xpos[g]
            gtype = m.geom_type[g]
            if gtype in (mujoco.mjtGeom.mjGEOM_CAPSULE, mujoco.mjtGeom.mjGEOM_CYLINDER):
                axis = d.geom_xmat[g].reshape(3, 3)[:, 2]
                h = m.geom_size[g, 1]
                dist = _seg_point_dist(centre, c - h * axis, c + h * axis) - m.geom_size[g, 0]
            elif gtype == mujoco.mjtGeom.mjGEOM_SPHERE:
                dist = np.linalg.norm(centre - c) - m.geom_size[g, 0]
            else:  # box etc. -> bounding sphere (conservative)
                dist = np.linalg.norm(centre - c) - m.geom_rbound[g]
            best = min(best, dist - radius)
        return float(best)

    def _set_obstacle(self, i: int, centre, radius):
        g = self.obs_geom[i]
        self.data.mocap_pos[self.obs_mocap[i]] = centre
        self.model.geom_size[g, 0] = radius
        self.model.geom_rbound[g] = radius

    def _place_obstacles(self, ee0: np.ndarray):
        """Random obstacles that (a) do not overlap the arm at start, (b) leave the
        target free and (c) with prob `block_prob` sit on the straight path."""
        for i in range(MAX_OBSTACLES):               # park everything first
            self._set_obstacle(i, PARK_POS + np.array([0, i, 0]), 0.05)
        self.obs_active[:] = False
        self.obstacles[:] = 0.0
        self.blocking = False
        mujoco.mj_forward(self.model, self.data)

        for i in range(self.n_obstacles):
            if self.np_random.random() > self.obstacle_prob:
                continue
            for _ in range(200):
                r = self.np_random.uniform(*self.obstacle_radius)
                block = self.np_random.random() < self.block_prob
                if block:
                    c = self._path_point(ee0, self.target, self.np_random.uniform(0.4, 0.85))
                    c = c + self.np_random.normal(scale=0.02, size=3)
                else:
                    c = self._sample_target()
                ok = (
                    np.linalg.norm(c - self.target) > r + 0.07        # target stays free
                    and np.linalg.norm(c - ee0) > r + 0.07            # gripper not trapped
                    and c[2] - r > 0.02                               # above the floor
                    and (np.linalg.norm(c[:2]) > r + 0.09 or c[2] - r > 0.22)  # off the base column
                    and self._arm_clearance(c, r) > 0.04              # not touching arm at t=0
                    and all(np.linalg.norm(c - self.obstacles[j, :3]) > r + self.obstacles[j, 3]
                            for j in range(i) if self.obs_active[j])
                )
                if ok:
                    self._set_obstacle(i, c, r)
                    self.obstacles[i] = [*c, r]
                    self.obs_active[i] = True
                    self.blocking |= block
                    break

    def _in_collision(self) -> bool:
        d = self.data
        for k in range(d.ncon):
            g1, g2 = d.contact[k].geom1, d.contact[k].geom2
            if (g1 in self.arm_geom_set and g2 in self.hazard_geoms) or \
               (g2 in self.arm_geom_set and g1 in self.hazard_geoms):
                return True
        return False

    def _clearances(self) -> np.ndarray:
        out = np.full(self.n_obstacles, 1.0)
        for i in range(self.n_obstacles):
            if self.obs_active[i]:
                out[i] = self._arm_clearance(self.obstacles[i, :3], self.obstacles[i, 3])
        return out

    def _get_obs(self, clear=None) -> np.ndarray:
        q, w = self.data.qpos, self.data.qvel
        ee = self.ee_pos
        parts = [np.cos(q), np.sin(q), 0.1 * w, ee, self.target, self.target - ee]
        clear = self._clearances() if clear is None else clear
        for i in range(self.n_obstacles):
            if self.obs_active[i]:
                c, r = self.obstacles[i, :3], self.obstacles[i, 3]
                parts += [c, [r], c - ee, [min(clear[i], 1.0)]]
            else:  # absent obstacle -> neutral encoding
                parts += [np.zeros(3), [0.0], np.zeros(3), [1.0]]
        return np.concatenate(parts).astype(np.float32)

    # ------------------------------------------------------------------ gym API
    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        options = options or {}
        m, d = self.model, self.data
        mujoco.mj_resetData(m, d)

        q0 = K.HOME_QPOS + self.np_random.uniform(-0.25, 0.25, size=6)
        q0[0] = self.np_random.uniform(-np.pi, np.pi)          # random base heading
        q0 = np.clip(q0, self.q_lo, self.q_hi)
        if "qpos" in options:
            q0 = np.asarray(options["qpos"], dtype=float)
        d.qpos[:] = q0
        d.ctrl[:] = q0
        self.q_des = q0.copy()
        mujoco.mj_forward(m, d)
        ee0 = self.ee_pos

        self.target = np.asarray(options["target"], float) if "target" in options else self._sample_target()
        d.mocap_pos[self.target_mocap] = self.target

        if "obstacles" in options:  # list of (x, y, z, r)
            for i in range(MAX_OBSTACLES):
                self._set_obstacle(i, PARK_POS + np.array([0, i, 0]), 0.05)
            self.obs_active[:] = False
            for i, (x, y, z, r) in enumerate(options["obstacles"][: self.n_obstacles]):
                self._set_obstacle(i, [x, y, z], r)
                self.obstacles[i] = [x, y, z, r]
                self.obs_active[i] = True
            self.blocking = True
        else:
            self._place_obstacles(ee0)
        mujoco.mj_forward(m, d)

        self.steps, self.hold = 0, 0
        self.prev_dist = float(np.linalg.norm(self.target - ee0))
        if self.render_mode == "human":
            self.render()
        return self._get_obs(), self._info(self.prev_dist, False, False)

    def step(self, action):
        a = np.clip(np.asarray(action, dtype=np.float64), -1.0, 1.0)
        d = self.data

        # integrate velocity command into servo set-points (with anti wind-up)
        self.q_des = self.q_des + a * self.max_joint_vel * self.dt
        self.q_des = np.clip(self.q_des, d.qpos - 0.3, d.qpos + 0.3)
        self.q_des = np.clip(self.q_des, self.q_lo, self.q_hi)
        d.ctrl[:] = self.q_des

        collided = False
        for _ in range(self.frame_skip):
            mujoco.mj_step(self.model, d)
            if self._in_collision():
                collided = True
                break
        self.steps += 1

        dist = float(np.linalg.norm(self.target - self.ee_pos))
        clear = self._clearances()

        # ---- reward
        r_dist = -dist
        r_energy = -self.alpha_energy * float(np.sum(a ** 2))
        r_prox = 0.0
        if self.proximity_weight > 0:
            viol = np.clip(1.0 - clear[self.obs_active] / self.safety_margin, 0.0, 1.0)
            r_prox = -self.proximity_weight * float(np.sum(viol))
        reward = r_dist + r_energy + r_prox

        self.hold = self.hold + 1 if dist < self.success_tol else 0
        success = self.hold >= self.success_hold
        if collided:
            reward -= self.collision_penalty
        elif success:
            reward += self.success_bonus

        terminated = collided or success
        truncated = (not terminated) and self.steps >= self.max_steps
        info = self._info(dist, success, collided, clear)
        info.update(r_dist=r_dist, r_energy=r_energy, r_prox=r_prox)
        if self.render_mode == "human":
            self.render()
        return self._get_obs(clear), float(reward), terminated, truncated, info

    def _info(self, dist, success, collided, clear=None):
        clear = self._clearances() if clear is None else clear
        return {
            "distance": dist,
            "is_success": bool(success),
            "collision": bool(collided),
            "blocking": bool(self.blocking),
            "min_clearance": float(clear.min()) if self.n_obstacles else 1.0,
            "steps": self.steps,
        }

    # ------------------------------------------------------------------ rendering
    def render(self):
        if self.render_mode == "rgb_array":
            if self._renderer is None:
                self._renderer = mujoco.Renderer(self.model, height=self.height, width=self.width)
            self._renderer.update_scene(self.data, camera=self.camera)
            return self._renderer.render()
        if self.render_mode == "human":
            if self._viewer is None:
                import mujoco.viewer
                self._viewer = mujoco.viewer.launch_passive(self.model, self.data)
                self._last_render = time.time()
            self._viewer.sync()
            # keep real-time speed
            sleep = self.dt - (time.time() - self._last_render)
            if sleep > 0:
                time.sleep(sleep)
            self._last_render = time.time()
        return None

    def close(self):
        if self._renderer is not None:
            self._renderer.close()
            self._renderer = None
        if self._viewer is not None:
            self._viewer.close()
            self._viewer = None
