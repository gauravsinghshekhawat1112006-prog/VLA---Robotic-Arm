"""
Evaluate a trained model over N (default 100) fresh, seeded episodes.

  python evaluate.py                                   # models/best_model.zip
  python evaluate.py --model runs/sac_main/best_model.zip --episodes 100
  python evaluate.py --render                          # watch it live in the MuJoCo viewer

Writes results/eval_metrics.json, results/eval_episodes.csv and
results/eval_outcomes.png, results/eval_distance.png.
"""
import argparse
import json
import os

import gymnasium as gym
import matplotlib
import numpy as np
import pandas as pd

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from stable_baselines3 import PPO, SAC  # noqa: E402

import arm6dof  # noqa: E402,F401


def load_model(path, algo=None):
    if algo is None:
        info = os.path.join(os.path.dirname(path), "best_model_info.json")
        algo = json.load(open(info))["algo"] if os.path.exists(info) else None
    for A in ([SAC, PPO] if algo in (None, "sac") else [PPO, SAC]):
        try:
            return A.load(path, device="cpu")
        except Exception:  # wrong algorithm class -> try the other
            continue
    raise RuntimeError(f"Could not load {path}")


def run_episodes(model, env, n, seed0, deterministic=True):
    rows = []
    for ep in range(n):
        obs, info = env.reset(seed=seed0 + ep)
        start_d, ep_ret, energy, min_clear = info["distance"], 0.0, 0.0, np.inf
        while True:
            action, _ = model.predict(obs, deterministic=deterministic)
            obs, r, term, trunc, info = env.step(action)
            ep_ret += r
            energy += float(np.sum(np.square(action)))
            min_clear = min(min_clear, info["min_clearance"])
            if term or trunc:
                break
        outcome = "success" if info["is_success"] else "collision" if info["collision"] else "timeout"
        rows.append(dict(episode=ep, outcome=outcome, success=info["is_success"],
                         collision=info["collision"], blocking=info["blocking"],
                         steps=info["steps"], time_s=info["steps"] * env.unwrapped.dt,
                         start_distance=start_d, final_distance=info["distance"],
                         episode_return=ep_ret, sum_sq_action=energy, min_clearance=min_clear))
    return pd.DataFrame(rows)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", default="models/best_model.zip")
    p.add_argument("--algo", choices=["sac", "ppo"], default=None)
    p.add_argument("--env-id", default="Arm6DOFReach-v0")
    p.add_argument("--episodes", type=int, default=100)
    p.add_argument("--seed", type=int, default=2026, help="eval seeds never used in training")
    p.add_argument("--render", action="store_true")
    p.add_argument("--out", default="results")
    args = p.parse_args()

    os.makedirs(args.out, exist_ok=True)
    model = load_model(args.model, args.algo)
    env = gym.make(args.env_id, render_mode="human" if args.render else None)
    df = run_episodes(model, env, args.episodes, args.seed)
    env.close()

    succ = df[df.success]
    blk = df[df.blocking]
    metrics = {
        "model": args.model,
        "episodes": int(len(df)),
        "success_rate": float(df.success.mean()),
        "collision_rate": float(df.collision.mean()),
        "timeout_rate": float((df.outcome == "timeout").mean()),
        "success_rate_when_obstacle_blocks_path": float(blk.success.mean()) if len(blk) else None,
        "n_blocking_episodes": int(len(blk)),
        "mean_final_distance_m": float(df.final_distance.mean()),
        "median_final_distance_m": float(df.final_distance.median()),
        "mean_time_to_success_s": float(succ.time_s.mean()) if len(succ) else None,
        "mean_episode_return": float(df.episode_return.mean()),
        "mean_min_clearance_m": float(df.min_clearance.mean()),
    }
    df.to_csv(os.path.join(args.out, "eval_episodes.csv"), index=False)
    with open(os.path.join(args.out, "eval_metrics.json"), "w") as f:
        json.dump(metrics, f, indent=2)

    # ---- plots
    counts = df.outcome.value_counts().reindex(["success", "collision", "timeout"], fill_value=0)
    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    ax[0].bar(counts.index, counts.values, color=["#2e9d4f", "#d13b3b", "#999999"])
    ax[0].set_title(f"Outcomes over {len(df)} evaluation episodes")
    ax[0].set_ylabel("episodes")
    for i, v in enumerate(counts.values):
        ax[0].text(i, v + 0.5, f"{v}", ha="center")
    groups = {"all": df, "obstacle on path": blk, "obstacle elsewhere": df[~df.blocking]}
    rates = [g.success.mean() * 100 if len(g) else 0 for g in groups.values()]
    ax[1].bar(list(groups), rates, color="#3a6fb0")
    ax[1].set_ylim(0, 105)
    ax[1].set_ylabel("success rate (%)")
    ax[1].set_title("Success rate by scenario")
    for i, v in enumerate(rates):
        ax[1].text(i, v + 1, f"{v:.0f}%", ha="center")
    fig.tight_layout()
    fig.savefig(os.path.join(args.out, "eval_outcomes.png"), dpi=130)

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.hist(df.final_distance * 100, bins=30, color="#3a6fb0")
    tol = env.unwrapped.success_tol * 100
    ax.axvline(tol, color="k", ls="--", label=f"success tolerance ({tol:.0f} cm)")
    ax.set_xlabel("final end-effector distance to target (cm)")
    ax.set_ylabel("episodes")
    ax.legend()
    fig.tight_layout()
    fig.savefig(os.path.join(args.out, "eval_distance.png"), dpi=130)

    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
