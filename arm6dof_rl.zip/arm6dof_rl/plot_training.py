"""
Learning-convergence plots from a training run.

  python plot_training.py --run runs/sac_main

Reads runs/<run>/monitor/*.monitor.csv (every training episode) and
runs/<run>/eval/evaluations.npz (periodic deterministic evaluations) and writes
results/reward_curve.png and results/success_curve.png.
"""
import argparse
import glob
import os

import matplotlib
import numpy as np
import pandas as pd

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402


def load_monitor(run):
    frames = []
    for f in glob.glob(os.path.join(run, "monitor", "*.monitor.csv")):
        df = pd.read_csv(f, skiprows=1)
        frames.append(df)
    if not frames:
        raise FileNotFoundError(f"no monitor files in {run}/monitor")
    df = pd.concat(frames).sort_values("t").reset_index(drop=True)
    df["timesteps"] = df["l"].cumsum()
    return df


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--run", default=None, help="run folder (default: newest in runs/)")
    p.add_argument("--window", type=int, default=200, help="rolling window in episodes")
    p.add_argument("--out", default="results")
    args = p.parse_args()
    run = args.run or max(glob.glob("runs/*"), key=os.path.getmtime)
    os.makedirs(args.out, exist_ok=True)

    df = load_monitor(run)
    w = args.window
    roll = lambda s: s.rolling(w, min_periods=max(1, w // 10)).mean()  # noqa: E731
    ev_path = os.path.join(run, "eval", "evaluations.npz")
    ev = np.load(ev_path) if os.path.exists(ev_path) else None

    # ---- reward curve
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.plot(df.timesteps, df.r, color="#9bb8dd", alpha=0.25, lw=0.5, label="training episode return")
    ax.plot(df.timesteps, roll(df.r), color="#1f4e8c", lw=2, label=f"training (rolling {w} eps)")
    if ev is not None:
        m, s = ev["results"].mean(1), ev["results"].std(1)
        ax.plot(ev["timesteps"], m, "o-", color="#e07b00", lw=2, ms=4, label="deterministic eval (mean)")
        ax.fill_between(ev["timesteps"], m - s, m + s, color="#e07b00", alpha=0.15)
    ax.set_xlabel("environment steps")
    ax.set_ylabel("episode return")
    ax.set_title("Learning curve - Arm6DOFReach-v0")
    ax.grid(alpha=0.3)
    ax.legend(loc="lower right")
    fig.tight_layout()
    fig.savefig(os.path.join(args.out, "reward_curve.png"), dpi=130)

    # ---- success / collision rate curve
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.plot(df.timesteps, roll(df.is_success.astype(float)) * 100, color="#2e9d4f", lw=2,
            label="training success rate")
    ax.plot(df.timesteps, roll(df.collision.astype(float)) * 100, color="#d13b3b", lw=2,
            label="training collision rate")
    if ev is not None and "successes" in ev.files and len(ev["successes"]):
        ax.plot(ev["timesteps"], ev["successes"].mean(1) * 100, "o--", color="#145a2b", ms=4,
                label="eval success rate")
    ax.set_ylim(-2, 102)
    ax.set_xlabel("environment steps")
    ax.set_ylabel("% of episodes")
    ax.set_title("Success & collision rate during training")
    ax.grid(alpha=0.3)
    ax.legend(loc="center right")
    fig.tight_layout()
    fig.savefig(os.path.join(args.out, "success_curve.png"), dpi=130)

    print(f"{len(df)} training episodes, {int(df.timesteps.iloc[-1]):,} steps "
          f"-> {args.out}/reward_curve.png, {args.out}/success_curve.png")


if __name__ == "__main__":
    main()
