"""
Record an MP4 demo of the trained policy (offscreen MuJoCo rendering).

  python record_video.py                          # 4 successful obstacle-avoidance episodes
  python record_video.py --n 6 --camera side --any   # include any outcome

Picks episodes where an obstacle blocks the direct path and (unless --any) the
arm succeeds, then writes results/demo.mp4.
Headless Linux: prefix with MUJOCO_GL=egl (or osmesa). Windows/macOS need nothing.
"""
import argparse
import os

import gymnasium as gym
import imageio.v2 as imageio
import numpy as np
from PIL import Image, ImageDraw, ImageFont

import arm6dof  # noqa: F401
from evaluate import load_model


def overlay(frame, lines):
    img = Image.fromarray(frame)
    d = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype("DejaVuSans.ttf", 20)
    except OSError:
        font = ImageFont.load_default()
    y = 10
    for text, color in lines:
        d.text((12, y), text, fill=color, font=font, stroke_width=2, stroke_fill=(0, 0, 0))
        y += 26
    return np.asarray(img)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", default="models/best_model.zip")
    p.add_argument("--env-id", default="Arm6DOFReach-v0")
    p.add_argument("--n", type=int, default=4, help="episodes to include")
    p.add_argument("--max-tries", type=int, default=200)
    p.add_argument("--any", action="store_true", help="don't filter on success/blocking")
    p.add_argument("--camera", default="main", choices=["main", "side", "top"])
    p.add_argument("--seed", type=int, default=5000)
    p.add_argument("--out", default="results/demo.mp4")
    args = p.parse_args()

    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    model = load_model(args.model)
    env = gym.make(args.env_id, render_mode="rgb_array", camera=args.camera, width=960, height=720)
    fps = env.unwrapped.metadata["render_fps"]
    writer = imageio.get_writer(args.out, fps=fps, codec="libx264", quality=8, macro_block_size=8)

    kept = tries = 0
    while kept < args.n and tries < args.max_tries:
        seed = args.seed + tries
        tries += 1
        # dry run without rendering to find a qualifying episode (fast)
        obs, info = env.reset(seed=seed)
        if not args.any and not info["blocking"]:
            continue
        done = False
        while not done:
            obs, r, term, trunc, info = env.step(model.predict(obs, deterministic=True)[0])
            done = term or trunc
        if not args.any and not info["is_success"]:
            continue

        # replay the same seed with rendering (env + policy are deterministic)
        kept += 1
        obs, info = env.reset(seed=seed)
        frames, done, t = [], False, 0
        while True:
            label = [(f"Episode {kept}/{args.n}   t = {t * env.unwrapped.dt:4.2f} s", (255, 255, 255)),
                     (f"distance to target: {info['distance'] * 100:5.1f} cm", (120, 255, 150)),
                     (f"min clearance to obstacle: {info['min_clearance'] * 100:5.1f} cm", (255, 150, 150))]
            if done:
                status = "SUCCESS" if info["is_success"] else "COLLISION" if info["collision"] else "TIMEOUT"
                label.append((status, (80, 255, 80) if info["is_success"] else (255, 80, 80)))
            frames.append(overlay(env.render(), label))
            if done:
                frames += [frames[-1]] * int(fps * 0.8)  # hold the last frame
                break
            obs, r, term, trunc, info = env.step(model.predict(obs, deterministic=True)[0])
            done = term or trunc
            t += 1
        for f in frames:
            writer.append_data(f)
        print(f"episode {kept}: seed={seed} outcome="
              f"{'success' if info['is_success'] else 'collision' if info['collision'] else 'timeout'}"
              f" steps={info['steps']}")
    writer.close()
    env.close()
    print(f"saved {args.out} ({kept} episodes)")


if __name__ == "__main__":
    main()
