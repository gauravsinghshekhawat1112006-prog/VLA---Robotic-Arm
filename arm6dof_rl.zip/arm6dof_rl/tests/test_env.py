"""Run with:  python -m pytest -q tests/"""
import os
import sys

import mujoco
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import arm6dof  # noqa: E402,F401
from arm6dof import kinematics as K  # noqa: E402
from arm6dof.env import XML_PATH, Arm6DOFReachEnv  # noqa: E402


def test_fk_matches_mujoco():
    m = mujoco.MjModel.from_xml_path(XML_PATH)
    d = mujoco.MjData(m)
    rng = np.random.default_rng(0)
    for _ in range(200):
        q = rng.uniform(K.JOINT_LOWER, K.JOINT_UPPER)
        d.qpos[:] = q
        mujoco.mj_kinematics(m, d)
        assert np.allclose(K.fk(q), d.site("ee").xpos, atol=1e-9)


def test_jacobian_matches_mujoco():
    m = mujoco.MjModel.from_xml_path(XML_PATH)
    d = mujoco.MjData(m)
    rng = np.random.default_rng(1)
    jacp = np.zeros((3, m.nv))
    for _ in range(50):
        q = rng.uniform(K.JOINT_LOWER, K.JOINT_UPPER)
        d.qpos[:] = q
        mujoco.mj_forward(m, d)
        mujoco.mj_jacSite(m, d, jacp, None, m.site("ee").id)
        assert np.allclose(K.jacobian(q), jacp, atol=1e-8)


def test_sampled_targets_are_reachable():
    """Every target the env samples can be reached kinematically (IK error < 1 cm)."""
    env = Arm6DOFReachEnv()
    env.reset(seed=0)
    fails = 0
    for i in range(100):
        t = env._sample_target()
        best = min(K.ik(t, q0=K.HOME_QPOS + np.r_[np.arctan2(t[1], t[0]), 0, 0, 0, 0, 0] * s)[1]
                   for s in (1.0, 0.0))
        fails += best > 0.01
    assert fails <= 2, f"{fails} unreachable targets"


def test_env_api_and_determinism():
    from gymnasium.utils.env_checker import check_env
    env = Arm6DOFReachEnv()
    check_env(env, skip_render_check=True)
    o1, _ = env.reset(seed=123)
    o2, _ = env.reset(seed=123)
    assert np.allclose(o1, o2)
    assert env.observation_space.contains(o1)


def test_collision_terminates_with_penalty():
    env = Arm6DOFReachEnv(proximity_weight=0.0)
    env.reset(seed=0)
    # put an obstacle right on the forearm
    c = env.data.geom("forearm").xpos.copy()
    env.reset(seed=0, options={"qpos": env.data.qpos.copy(), "target": [0.3, 0.3, 0.4],
                                "obstacles": [(*c, 0.05)]})
    _, r, term, _, info = env.step(np.zeros(6))
    assert term and info["collision"] and r < -99


def test_success_bonus():
    env = Arm6DOFReachEnv(n_obstacles=0, success_hold=3)
    env.reset(seed=0)
    target = env.ee_pos.copy()  # target exactly at the current EE
    env.reset(seed=0, options={"qpos": env.data.qpos.copy(), "target": target})
    for _ in range(3):
        _, r, term, _, info = env.step(np.zeros(6))
    assert term and info["is_success"] and r > 199
