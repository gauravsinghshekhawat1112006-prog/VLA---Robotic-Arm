"""
Train an RL agent on Arm6DOFReach-v0.  The agent learns entirely by itself:
this script just starts N simulated arms, lets them act, collects rewards and
updates the neural network - thousands of episodes, no human in the loop.

Examples
--------
  python train.py                                  # SAC, 1.5M steps (recommended)
  python train.py --algo ppo --n-envs 8 --timesteps 5000000
  python train.py --timesteps 20000 --run-name smoke   # quick pipeline check
  tensorboard --logdir runs                        # watch live curves

Outputs (runs/<run-name>/):
  best_model.zip        best eval-success model  (also copied to models/best_model.zip)
  final_model.zip       weights at the end of training
  checkpoints/          periodic snapshots (resume with --resume)
  monitor/              per-episode training logs (reward, length, success)
  eval/evaluations.npz  periodic deterministic evaluations
  tb/                   TensorBoard logs
"""
import argparse
import json
import os
import shutil
import time

import gymnasium as gym
import numpy as np
import torch
from stable_baselines3 import PPO, SAC
from stable_baselines3.common.callbacks import (BaseCallback, CallbackList,
                                                CheckpointCallback, EvalCallback)
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.vec_env import DummyVecEnv, SubprocVecEnv

import arm6dof  # noqa: F401  (registers the env ids)

try:
    import tensorboard  # noqa: F401
    HAS_TB = True
except ImportError:  # TensorBoard is optional
    HAS_TB = False


class SuccessRateLogger(BaseCallback):
    """Logs rolling training success / collision rate to TensorBoard + stdout."""

    def __init__(self, window=100, print_every=20_000):
        super().__init__()
        self.succ, self.coll = [], []
        self.window, self.print_every, self._last = window, print_every, 0
        self.t0 = time.time()

    def _on_step(self):
        for info, done in zip(self.locals["infos"], self.locals["dones"]):
            if done:
                self.succ.append(float(info.get("is_success", 0)))
                self.coll.append(float(info.get("collision", 0)))
        if self.succ:
            s = np.mean(self.succ[-self.window:])
            c = np.mean(self.coll[-self.window:])
            self.logger.record("rollout/success_rate", s)
            self.logger.record("rollout/collision_rate", c)
            if self.num_timesteps - self._last >= self.print_every:
                self._last = self.num_timesteps
                fps = self.num_timesteps / (time.time() - self.t0)
                print(f"[{self.num_timesteps:>9,d} steps | {fps:5.0f} sps] episodes={len(self.succ):6d} "
                      f"success={s:5.1%} collision={c:5.1%}", flush=True)
        return True


def make_model(algo, env, args, tb):
    policy_kwargs = dict(net_arch=[256, 256, 256], activation_fn=torch.nn.ReLU)
    if algo == "sac":
        return SAC(
            "MlpPolicy", env,
            learning_rate=3e-4, buffer_size=1_000_000, batch_size=256,
            learning_starts=10_000, tau=0.005, gamma=0.98,
            train_freq=1, gradient_steps=args.gradient_steps, ent_coef="auto",
            policy_kwargs=policy_kwargs, tensorboard_log=tb,
            seed=args.seed, device=args.device, verbose=0,
        )
    return PPO(
        "MlpPolicy", env,
        learning_rate=3e-4, n_steps=1024, batch_size=512, n_epochs=10,
        gamma=0.98, gae_lambda=0.95, clip_range=0.2, ent_coef=0.0,
        policy_kwargs=dict(net_arch=dict(pi=[256, 256], vf=[256, 256]), log_std_init=-0.5),
        tensorboard_log=tb, seed=args.seed, device=args.device, verbose=0,
    )


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--algo", choices=["sac", "ppo"], default="sac")
    p.add_argument("--env-id", default="Arm6DOFReach-v0")
    p.add_argument("--timesteps", type=int, default=1_500_000)
    p.add_argument("--n-envs", type=int, default=4)
    p.add_argument("--gradient-steps", type=int, default=2, help="SAC updates per vec-env step")
    p.add_argument("--subproc", action="store_true", help="run envs in separate processes")
    p.add_argument("--eval-freq", type=int, default=25_000, help="in total env steps")
    p.add_argument("--eval-episodes", type=int, default=30)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--device", default="auto", help="'cpu' is usually fastest for these small MLPs")
    p.add_argument("--run-name", default=None)
    p.add_argument("--resume", default=None, help="path to a .zip checkpoint to continue from")
    args = p.parse_args()

    run = args.run_name or f"{args.algo}_{time.strftime('%Y%m%d_%H%M%S')}"
    out = os.path.join("runs", run)
    for sub in ("monitor", "eval", "checkpoints", "tb"):
        os.makedirs(os.path.join(out, sub), exist_ok=True)
    with open(os.path.join(out, "config.json"), "w") as f:
        json.dump(vars(args), f, indent=2)

    vec_cls = SubprocVecEnv if args.subproc else DummyVecEnv
    env = make_vec_env(args.env_id, n_envs=args.n_envs, seed=args.seed, vec_env_cls=vec_cls,
                       monitor_dir=os.path.join(out, "monitor"),
                       monitor_kwargs=dict(info_keywords=("is_success", "collision", "blocking")))
    eval_env = make_vec_env(args.env_id, n_envs=1, seed=args.seed + 10_000)

    if args.resume:
        Algo = SAC if args.algo == "sac" else PPO
        model = Algo.load(args.resume, env=env, device=args.device)
        model.tensorboard_log = os.path.join(out, "tb") if HAS_TB else None
    else:
        model = make_model(args.algo, env, args, os.path.join(out, "tb") if HAS_TB else None)

    callbacks = CallbackList([
        SuccessRateLogger(),
        EvalCallback(eval_env, n_eval_episodes=args.eval_episodes,
                     eval_freq=max(args.eval_freq // args.n_envs, 1),
                     best_model_save_path=out, log_path=os.path.join(out, "eval"),
                     deterministic=True, verbose=1),
        CheckpointCallback(save_freq=max(100_000 // args.n_envs, 1),
                           save_path=os.path.join(out, "checkpoints"), name_prefix=args.algo),
    ])

    print(f"Training {args.algo.upper()} on {args.env_id} for {args.timesteps:,} steps -> {out}")
    t0 = time.time()
    try:
        model.learn(total_timesteps=args.timesteps, callback=callbacks, progress_bar=False,
                    reset_num_timesteps=args.resume is None, tb_log_name=args.algo)
    except KeyboardInterrupt:
        print("Interrupted - saving current weights.")
    model.save(os.path.join(out, "final_model"))
    print(f"Done in {(time.time() - t0) / 60:.1f} min")

    os.makedirs("models", exist_ok=True)
    best = os.path.join(out, "best_model.zip")
    src = best if os.path.exists(best) else os.path.join(out, "final_model.zip")
    shutil.copy(src, os.path.join("models", "best_model.zip"))
    with open(os.path.join("models", "best_model_info.json"), "w") as f:
        json.dump({"source": src, "algo": args.algo, "env_id": args.env_id, "run": run}, f, indent=2)
    print(f"Best model copied to models/best_model.zip  (from {src})")


if __name__ == "__main__":  # required for SubprocVecEnv on Windows
    main()
