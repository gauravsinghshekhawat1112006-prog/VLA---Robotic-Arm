"""
Step 1 - deploy and inspect the 6-DOF arm in MuJoCo (no RL involved).

  python view_model.py                 # joint sweep demo: every joint moves sinusoidally
  python view_model.py --mode ik       # classical IK moves the arm to random targets (ignores obstacles)
  python view_model.py --mode random   # random actions through the Gym env
  python view_model.py --mode policy --model models/best_model.zip   # watch the trained agent
  python -m mujoco.viewer --mjcf arm6dof/assets/arm6dof.xml          # raw model, use the Control panel sliders

In the viewer: double-click a body to select it, Ctrl+right-drag to push it,
[Tab]/[Shift+Tab] toggles the side panels, [Space] pauses.
(macOS: run with `mjpython` instead of `python`.)
"""
import argparse
import time

import mujoco
import mujoco.viewer
import numpy as np

from arm6dof import kinematics as K
from arm6dof.env import XML_PATH, Arm6DOFReachEnv


def sweep():
    m = mujoco.MjModel.from_xml_path(XML_PATH)
    d = mujoco.MjData(m)
    mujoco.mj_resetDataKeyframe(m, d, 0)
    amp = np.array([1.5, 0.6, 0.8, 1.5, 1.0, 1.5])
    with mujoco.viewer.launch_passive(m, d) as v:
        while v.is_running():
            t0 = time.time()
            d.ctrl[:] = K.HOME_QPOS + amp * np.sin(0.5 * d.time * np.arange(1, 7) / 3)
            mujoco.mj_step(m, d)
            v.sync()
            time.sleep(max(0.0, m.opt.timestep - (time.time() - t0)))


def ik_demo():
    env = Arm6DOFReachEnv(render_mode="human", n_obstacles=0)
    env.reset(seed=0)
    while True:
        env.reset()
        q_goal, err = K.ik(env.target, q0=env.data.qpos.copy())
        print(f"target {np.round(env.target, 3)}  IK error {err * 1000:.1f} mm")
        for _ in range(150):
            # proportional velocity command toward the IK solution
            a = np.clip((q_goal - env.data.qpos) * 2.0, -1, 1)
            *_, term, trunc, info = env.step(a)
            if term or trunc:
                break
        print(f"   reached={info['is_success']}  final distance {info['distance'] * 100:.1f} cm")


def run_env(policy):
    env = Arm6DOFReachEnv(render_mode="human")
    obs, _ = env.reset(seed=0)
    ep = 0
    while True:
        obs, r, term, trunc, info = env.step(policy(obs, env))
        if term or trunc:
            ep += 1
            out = "SUCCESS" if info["is_success"] else "COLLISION" if info["collision"] else "timeout"
            print(f"episode {ep}: {out}  steps={info['steps']}  final distance={info['distance'] * 100:.1f} cm")
            time.sleep(0.5)
            obs, _ = env.reset()


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--mode", choices=["sweep", "ik", "random", "policy"], default="sweep")
    p.add_argument("--model", default="models/best_model.zip")
    args = p.parse_args()
    if args.mode == "sweep":
        sweep()
    elif args.mode == "ik":
        ik_demo()
    elif args.mode == "random":
        run_env(lambda o, e: e.action_space.sample())
    else:
        from evaluate import load_model
        model = load_model(args.model)
        run_env(lambda o, e: model.predict(o, deterministic=True)[0])


if __name__ == "__main__":
    main()
