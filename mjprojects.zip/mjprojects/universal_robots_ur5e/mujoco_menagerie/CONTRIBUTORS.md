# MuJoCo Menagerie – Contributors

Built by the Google DeepMind team with contributions from the open-source community — thank you to everyone who helped shape this project.

## Core Team

- [Alessio Quaglino](https://github.com/quagla) — Google DeepMind
- [Baruch Tabanpour](https://github.com/btaba) — Google DeepMind
- [Kevin Zakka](https://github.com/kevinzakka) — Maintainer, Google DeepMind
- [Nimrod Gileadi](https://github.com/nimrod-gileadi) — Google DeepMind
- [Saran Tunyasuvunakool](https://github.com/saran-t) — Google DeepMind
- [Silvia Cruciani](https://github.com/silviacruciani) — Google DeepMind
- [Tom Erez](https://github.com/erez-tom) — Google DeepMind
- [Yuval Tassa](https://github.com/yuvaltassa) — Google DeepMind

## Community Contributors

- [Albert Li](https://github.com/alberthli)
- [Alper Ahmetoglu](https://github.com/alper111)
- [Andreas Kuhner](https://github.com/AndreasKuhner)
- [Andrew Luo](https://github.com/Andrew-Luo1)
- [Ayzaan Wahid](https://github.com/ayzaan)
- [Chenhui Zuo](https://github.com/zchJo)
- [Chi-Tao Kuan](https://github.com/ctkuan-flexiv)
- [Chintan Desai](https://github.com/hello-chintan)
- [Christian Rauch](https://github.com/christianrauch)
- [Dada Tian](https://github.com/lonelyfluency)
- [Eugene Frizza](https://github.com/eufrizz)
- [Haochen Shi](https://github.com/hshi74)
- [Ian Noh](https://github.com/dongridong)
- [Jason Chen](https://github.com/chenxin199305)
- [Johnny Nunez](https://github.com/johnnynunez)
- [Jonathan Zamora](https://github.com/jonzamora)
- [Jooyoung Lim](https://github.com/mmporong)
- [Kallinteris Andreas](https://github.com/Kallinteris-Andreas)
- [Lev Kozlov](https://github.com/lvjonok)
- [Lorenzo Amatucci](https://github.com/lorenzo96-cmd)
- [Louis Le Lay](https://github.com/louislelay)
- [Martin Günther](https://github.com/muhrix)
- [Mohamed Fazil](https://github.com/hello-fazil)
- [Nan Wang](https://github.com/Nan-Tetheria)
- [Nikita Cherniadev](https://github.com/chernyadev)
- [Omar Rayyan](https://github.com/omarrayyann)
- [Sai Kishor Kothakota](https://github.com/saikishor)
- [Taehyeong Kim](https://github.com/kimtaehyeong99)
- [Taylor Howell](https://github.com/thowell)
- [Thomas Lips](https://github.com/tlpss)
- [Thomas Peyrucain](https://github.com/thomaspeyrucain)
- [Tony Ma](https://github.com/toekneema)
- [Varad Vaidya](https://github.com/varadVaidya)
- [Yanan Sui](https://github.com/yanansui)

---

Want to contribute? Check out our [CONTRIBUTING.md](./CONTRIBUTING.md) guide and submit a pull request!
