import os
import time
import json

import numpy as np
import mujoco
import mujoco.viewer
import glfw
from PIL import Image


# ============================================================
# Configuration
# ============================================================

SCENE = "ur5e_2f85.xml"

IMAGE_WIDTH = 320
IMAGE_HEIGHT = 240

# Record at 20 Hz
RECORD_HZ = 20.0
RECORD_DT = 1.0 / RECORD_HZ

STEP = 0.05
GRIPPER_STEP = 25

EPISODE_DIR = "demo_000"


# ============================================================
# Load MuJoCo
# ============================================================

model = mujoco.MjModel.from_xml_path(SCENE)
data = mujoco.MjData(model)


# ============================================================
# Home configuration
# ============================================================

home = np.array([
    -1.5708,
    -1.5708,
     1.5708,
    -1.5708,
    -1.5708,
     0.0,
])

target = home.copy()

# Robotiq:
# 0   = open
# 255 = closed
gripper_target = 0

data.qpos[:6] = home
data.ctrl[:6] = home
data.ctrl[6] = gripper_target

mujoco.mj_forward(model, data)


# ============================================================
# Create output directories
# ============================================================

os.makedirs(EPISODE_DIR, exist_ok=True)
os.makedirs(os.path.join(EPISODE_DIR, "workspace"), exist_ok=True)
os.makedirs(os.path.join(EPISODE_DIR, "wrist"), exist_ok=True)


# ============================================================
# Renderer
# ============================================================

renderer = mujoco.Renderer(
    model,
    height=IMAGE_HEIGHT,
    width=IMAGE_WIDTH,
)


# ============================================================
# Keyboard control
# ============================================================

def key_callback(key):

    global target
    global gripper_target

    # -----------------------------
    # UR5e joints
    # -----------------------------

    if key == glfw.KEY_Q:
        target[0] -= STEP

    elif key == glfw.KEY_E:
        target[0] += STEP

    elif key == glfw.KEY_W:
        target[1] += STEP

    elif key == glfw.KEY_S:
        target[1] -= STEP

    elif key == glfw.KEY_R:
        target[2] += STEP

    elif key == glfw.KEY_F:
        target[2] -= STEP

    elif key == glfw.KEY_T:
        target[3] += STEP

    elif key == glfw.KEY_G:
        target[3] -= STEP

    elif key == glfw.KEY_Y:
        target[4] += STEP

    elif key == glfw.KEY_H:
        target[4] -= STEP

    elif key == glfw.KEY_U:
        target[5] += STEP

    elif key == glfw.KEY_J:
        target[5] -= STEP

    # -----------------------------
    # Gripper
    # -----------------------------

    elif key == glfw.KEY_O:
        gripper_target -= GRIPPER_STEP

    elif key == glfw.KEY_P:
        gripper_target += GRIPPER_STEP

    # -----------------------------
    # Home
    # -----------------------------

    elif key == glfw.KEY_SPACE:
        data.qpos[:6] = home
        data.qvel[:6] = 0
        target[:] = home
        gripper_target = 0
        mujoco.mj_forward(model, data)

    # Safety limits
    target[:] = np.clip(
        target,
        -6.28,
        6.28,
    )

    gripper_target = int(
        np.clip(
            gripper_target,
            0,
            255,
        )
    )


# ============================================================
# Data storage
# ============================================================

records = []

frame_id = 0

last_record_time = time.time()

episode_start = time.time()


# ============================================================
# Viewer
# ============================================================

print("""
========================================
UR5e + Robotiq Demonstration Recorder
========================================

UR5e:

Q / E : Joint 1
W / S : Joint 2
R / F : Joint 3
T / G : Joint 4
Y / H : Joint 5
U / J : Joint 6

Gripper:

O : Open
P : Close

SPACE : Home + Open Gripper

Move the robot and gripper around to
create a demonstration.

Close the viewer when finished.

Recording at 20 Hz.
========================================
""")


with mujoco.viewer.launch_passive(
    model,
    data,
    key_callback=key_callback,
) as viewer:

    while viewer.is_running():

        # ----------------------------------------------------
        # Control
        # ----------------------------------------------------

        data.ctrl[:6] = target
        data.ctrl[6] = gripper_target

        mujoco.mj_step(model, data)

        viewer.sync()


        # ----------------------------------------------------
        # Record at fixed rate
        # ----------------------------------------------------

        now = time.time()

        if now - last_record_time >= RECORD_DT:

            timestamp = now - episode_start


            # -----------------------------------------------
            # Robot state
            # -----------------------------------------------

            qpos = data.qpos[:6].copy()
            qvel = data.qvel[:6].copy()

            # 7-dimensional action:
            # 6 UR5e joint targets + gripper target
            action = np.concatenate([
                target,
                [gripper_target],
            ])


            # -----------------------------------------------
            # Workspace camera
            # -----------------------------------------------

            renderer.update_scene(
                data,
                camera="workspace_camera",
            )

            workspace_image = renderer.render()

            workspace_path = os.path.join(
                EPISODE_DIR,
                "workspace",
                f"{frame_id:06d}.png",
            )

            Image.fromarray(workspace_image).save(
                workspace_path
            )


            # -----------------------------------------------
            # Wrist camera
            # -----------------------------------------------

            renderer.update_scene(
                data,
                camera="wrist_camera",
            )

            wrist_image = renderer.render()

            wrist_path = os.path.join(
                EPISODE_DIR,
                "wrist",
                f"{frame_id:06d}.png",
            )

            Image.fromarray(wrist_image).save(
                wrist_path
            )


            # -----------------------------------------------
            # Metadata
            # -----------------------------------------------

            records.append({
                "frame": frame_id,
                "timestamp": timestamp,
                "qpos": qpos.tolist(),
                "qvel": qvel.tolist(),
                "action": action.tolist(),
                "workspace_image": workspace_path,
                "wrist_image": wrist_path,
            })


            frame_id += 1

            last_record_time = now


# ============================================================
# Save metadata
# ============================================================

metadata_path = os.path.join(
    EPISODE_DIR,
    "data.json",
)

with open(metadata_path, "w") as f:
    json.dump(
        records,
        f,
        indent=2,
    )


print()
print("========================================")
print("Episode finished")
print("========================================")
print(f"Frames recorded : {len(records)}")
print(f"Output directory: {EPISODE_DIR}")
print(f"Metadata        : {metadata_path}")
