import time
import numpy as np
import mujoco
import mujoco.viewer
import glfw


# --------------------------------------------------
# Load model
# --------------------------------------------------

model = mujoco.MjModel.from_xml_path("ur5e_2f85.xml")
data = mujoco.MjData(model)


# --------------------------------------------------
# UR5e home position
# --------------------------------------------------

home = np.array([
    -1.5708,
    -1.5708,
     1.5708,
    -1.5708,
    -1.5708,
     0.0,
])

target = home.copy()

# Robotiq gripper:
# 0   = open
# 255 = closed
gripper_target = 0


data.qpos[:6] = home
data.ctrl[:6] = home
data.ctrl[6] = gripper_target

mujoco.mj_forward(model, data)


# --------------------------------------------------
# Keyboard settings
# --------------------------------------------------

STEP = 0.05

# Gripper step
GRIPPER_STEP = 25

# Joint limits for safety
LOWER = np.array([
    -6.28,
    -6.28,
    -6.28,
    -6.28,
    -6.28,
    -6.28,
])

UPPER = np.array([
     6.28,
     6.28,
     6.28,
     6.28,
     6.28,
     6.28,
])


def key_callback(key):
    global target
    global gripper_target

    if key == glfw.KEY_A:
        target[0] -= STEP

    elif key == glfw.KEY_D:
        target[0] += STEP

    elif key == glfw.KEY_W:
        target[1] += STEP

    elif key == glfw.KEY_S:
        target[1] -= STEP

    elif key == glfw.KEY_R:
        target[2] += STEP

    elif key == glfw.KEY_F:
        target[2] -= STEP

    elif key == glfw.KEY_T:
        target[3] += STEP

    elif key == glfw.KEY_G:
        target[3] -= STEP

    elif key == glfw.KEY_Y:
        target[4] += STEP

    elif key == glfw.KEY_H:
        target[4] -= STEP

    elif key == glfw.KEY_U:
        target[5] += STEP

    elif key == glfw.KEY_J:
        target[5] -= STEP

    elif key == glfw.KEY_O:
        # Open gripper
        gripper_target -= GRIPPER_STEP

    elif key == glfw.KEY_P:
        # Close gripper
        gripper_target += GRIPPER_STEP

    elif key == glfw.KEY_SPACE:
        # Home robot and open gripper
        target[:] = home
        gripper_target = 0

    # Keep targets inside safe limits
    target[:] = np.clip(target, LOWER, UPPER)
    gripper_target = int(np.clip(gripper_target, 0, 255))


# --------------------------------------------------
# Run viewer
# --------------------------------------------------

print("""
========================================
UR5e + Robotiq 2F-85 Teleoperation
========================================

UR5e joints:

Joint 1:  A / D
Joint 2:  W / S
Joint 3:  R / F
Joint 4:  T / G
Joint 5:  Y / H
Joint 6:  U / J

Gripper:

O = Open
P = Close

SPACE = Home + Open Gripper

Close the viewer window to quit.

Joint STEP = 0.05 rad
Gripper STEP = 25
========================================
""")


with mujoco.viewer.launch_passive(
    model,
    data,
    key_callback=key_callback,
) as viewer:

    while viewer.is_running():

        # Send desired joint positions to UR5e
        data.ctrl[:6] = target

        # Send desired position to Robotiq
        data.ctrl[6] = gripper_target

        # Advance physics
        mujoco.mj_step(model, data)

        # Update viewer
        viewer.sync()

        time.sleep(0.002)
