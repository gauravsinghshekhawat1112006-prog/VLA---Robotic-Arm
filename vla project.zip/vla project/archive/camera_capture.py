import mujoco
import mujoco.viewer
from PIL import Image
import time
import cv2
import numpy as np

model_path = "C:/mujoco_menagerie/universal_robots_ur5e/vla_scene.xml"

model = mujoco.MjModel.from_xml_path(model_path)
data = mujoco.MjData(model)
ee_id = mujoco.mj_name2id(
    model,
    mujoco.mjtObj.mjOBJ_BODY,
    "tool0"
)

print("End-effector ID:", ee_id)

home_position = [
    -1.0,
    -1.57,
     1.57,
    -1.57,
    -1.57,
     0.0
]

renderer = mujoco.Renderer(
    model,
    height=480,
    width=640
)

camera_id = mujoco.mj_name2id(
    model,
    mujoco.mjtObj.mjOBJ_CAMERA,
    "vla_camera"
)

print("Camera ID:", camera_id)

with mujoco.viewer.launch_passive(model, data) as viewer:

    while viewer.is_running():

        # Move robot
        for i in range(6):
            data.ctrl[i] = home_position[i]

        # Run simulation
        mujoco.mj_step(model, data)
        position = data.xpos[ee_id]

        print(
        "End-effector:",
         position[0],
         position[1],
         position[2]
        )

        # Render camera
        renderer.update_scene(
            data,
            camera=camera_id
        )

        image = renderer.render()

        # MuJoCo gives RGB
        # OpenCV needs BGR
        image_bgr = cv2.cvtColor(
            image,
            cv2.COLOR_RGB2BGR
        )

        # Show camera view
        cv2.imshow(
            "VLA Camera View",
            image_bgr
        )

        # Update MuJoCo viewer
        viewer.sync()

        # Press Q to close camera window
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

        time.sleep(0.01)

cv2.destroyAllWindows()
renderer.close()

print("Program finished.")