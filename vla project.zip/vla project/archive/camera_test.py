import mujoco

model_path = "C:/mujoco_menagerie/universal_robots_ur5e/vla_scene.xml"

print("Loading:")
print(model_path)

# Read the actual XML file
with open(model_path, "r") as f:
    xml_text = f.read()

print("\nDoes Python see 'vla_camera'?")
print("vla_camera" in xml_text)

print("\nCamera text found:")

start = xml_text.find("<camera")

if start != -1:
    print(xml_text[start:start + 200])
else:
    print("NO CAMERA FOUND IN FILE")

# Load MuJoCo model
model = mujoco.MjModel.from_xml_path(model_path)

print("\nNumber of cameras:", model.ncam)

print("\nCameras in model:")

for i in range(model.ncam):
    print(i, model.camera(i).name)

camera_id = mujoco.mj_name2id(
    model,
    mujoco.mjtObj.mjOBJ_CAMERA,
    "vla_camera"
)

print("\nVLA camera ID:", camera_id)