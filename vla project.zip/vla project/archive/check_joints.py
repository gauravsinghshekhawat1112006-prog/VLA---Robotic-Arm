import mujoco

model_path = "C:/mujoco_menagerie/universal_robots_ur5e/vla_scene.xml"

model = mujoco.MjModel.from_xml_path(model_path)

print("Joints in the model:")

for i in range(model.njnt):
    name = mujoco.mj_id2name(
        model,
        mujoco.mjtObj.mjOBJ_JOINT,
        i
    )
    print(i, name)
    