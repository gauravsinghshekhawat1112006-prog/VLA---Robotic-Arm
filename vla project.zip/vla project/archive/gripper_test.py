import mujoco
import mujoco.viewer
import time

# -----------------------------
# File paths
# -----------------------------

robot_path = "C:/mujoco_menagerie/universal_robots_ur5e/vla_scene.xml"
gripper_path = "C:/mujoco_gripper/robotiq_2f85/2f85.xml"

# -----------------------------
# Load UR5e
# -----------------------------

print("Loading UR5e...")
robot_spec = mujoco.MjSpec.from_file(robot_path)

# Find the attachment site
attachment_site = robot_spec.site("attachment_site")

if attachment_site is None:
    raise RuntimeError("attachment_site not found!")

print("Found attachment_site!")

# -----------------------------
# Load Robotiq 2F-85
# -----------------------------

print("Loading Robotiq 2F-85...")
gripper_spec = mujoco.MjSpec.from_file(gripper_path)

print("Gripper loaded!")

# -----------------------------
# Attach gripper to UR5e
# -----------------------------

print("Attaching gripper...")

robot_spec.attach(
    gripper_spec,
    site=attachment_site,
    prefix="gripper_"
)

print("Gripper attached!")

# -----------------------------
# Compile complete model
# -----------------------------

model = robot_spec.compile()
data = mujoco.MjData(model)

print("Complete model compiled!")
print("Number of bodies:", model.nbody)
print("Number of joints:", model.njnt)
print("Number of actuators:", model.nu)

# -----------------------------
# Open viewer
# -----------------------------

print("Opening MuJoCo viewer...")

with mujoco.viewer.launch_passive(model, data) as viewer:

    while viewer.is_running():

        mujoco.mj_step(model, data)

        viewer.sync()

        time.sleep(0.01)

print("Program finished.")