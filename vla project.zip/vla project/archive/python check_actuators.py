import mujoco

model_path = "C:/mujoco_menagerie/universal_robots_ur5e/vla_scene.xml"

model = mujoco.MjModel.from_xml_path(model_path)

print("Number of actuators:", model.nu)

print("\nActuators:")

for i in range(model.nu):
    print(i, model.actuator(i).name)