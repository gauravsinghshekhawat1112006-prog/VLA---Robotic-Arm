import mujoco
import mujoco.viewer

# Path to the scene file inside your sparse checkout directory
model_path = "C:/mujoco_menagerie/universal_robots_ur5e/scene.xml"

# Load model and launch full interactive viewer
model = mujoco.MjModel.from_xml_path(model_path)
data = mujoco.MjData(model)

# This launches an interactive GUI window (Control joints, drag links with mouse)
mujoco.viewer.launch(model, data)
