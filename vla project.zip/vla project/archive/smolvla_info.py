from lerobot.policies.smolvla.modeling_smolvla import SmolVLAPolicy

print("Loading SmolVLA...")

policy = SmolVLAPolicy.from_pretrained("lerobot/smolvla_base")

print("\nSmolVLA loaded!")
print("\nObservation features:")
print(policy.config.input_features)

print("\nAction features:")
print(policy.config.output_features)