import mujoco
import mujoco.viewer
import torch
import numpy as np

from lerobot.policies.smolvla.modeling_smolvla import SmolVLAPolicy
from lerobot.policies.factory import make_pre_post_processors


# ==========================================
# 1. Load MuJoCo
# ==========================================

model_path = "C:/mujoco_menagerie/universal_robots_ur5e/vla_scene.xml"

model = mujoco.MjModel.from_xml_path(model_path)
data = mujoco.MjData(model)

print("MuJoCo model loaded!")


# ==========================================
# 2. Load SmolVLA
# ==========================================

print("Loading SmolVLA...")

device = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)

print("Device:", device)

policy = SmolVLAPolicy.from_pretrained(
    "lerobot/smolvla_base"
)

policy = policy.to(device)

print("SmolVLA loaded!")


# ==========================================
# 3. Create SmolVLA processors
# ==========================================

print("Creating SmolVLA processor...")

preprocess, postprocess = make_pre_post_processors(
    policy_cfg=policy.config,
    pretrained_path="lerobot/smolvla_base",
)

print("Processor ready!")


# ==========================================
# 4. Camera
# ==========================================

renderer = mujoco.Renderer(
    model,
    height=256,
    width=256
)

camera_id = mujoco.mj_name2id(
    model,
    mujoco.mjtObj.mjOBJ_CAMERA,
    "vla_camera"
)

print("Camera ID:", camera_id)


# ==========================================
# 5. Robot joints
# ==========================================

joint_names = [
    "shoulder_pan_joint",
    "shoulder_lift_joint",
    "elbow_joint",
    "wrist_1_joint",
    "wrist_2_joint",
    "wrist_3_joint"
]

joint_ids = []

for name in joint_names:

    joint_id = mujoco.mj_name2id(
        model,
        mujoco.mjtObj.mjOBJ_JOINT,
        name
    )

    joint_ids.append(joint_id)

print("Joint IDs:", joint_ids)


# ==========================================
# 6. Language instruction
# ==========================================

task = "Pick up the red cube"

print("Task:", task)


# ==========================================
# 7. Open MuJoCo Viewer
# ==========================================

print("\nOpening MuJoCo viewer...")

with mujoco.viewer.launch_passive(model, data) as viewer:

    inference_done = False

    while viewer.is_running():

        # ----------------------------------
        # Step MuJoCo
        # ----------------------------------

        mujoco.mj_step(model, data)


        # ----------------------------------
        # Run SmolVLA only once
        # ----------------------------------

        if not inference_done:

            print("\n==============================")
            print("Preparing observation...")
            print("==============================")


            # ----------------------------------
            # Robot state
            # ----------------------------------

            robot_state = np.array(
                [
                    data.qpos[joint_id]
                    for joint_id in joint_ids
                ],
                dtype=np.float32
            )

            print("Robot state:")
            print(robot_state)


            # ----------------------------------
            # Camera image
            # ----------------------------------

            renderer.update_scene(
                data,
                camera=camera_id
            )

            image = renderer.render()

            print("Camera image captured!")


            # ----------------------------------
            # Convert image to tensor
            # ----------------------------------

            image_tensor = (
                torch.from_numpy(image.copy())
                .float()
                / 255.0
            )

            # HWC -> CHW
            image_tensor = image_tensor.permute(
                2, 0, 1
            )


            # ----------------------------------
            # Create observation
            # ----------------------------------

            observation = {

                "observation.state":
                    torch.tensor(robot_state),

                "observation.images.camera1":
                    image_tensor,

                "observation.images.camera2":
                    image_tensor,

                "observation.images.camera3":
                    image_tensor,

                "task":
                    task
            }


            # ----------------------------------
            # SmolVLA preprocessing
            # ----------------------------------

            print("\nPreprocessing observation...")

            processed_observation = preprocess(
                observation
            )

            print("Preprocessing successful!")


            # ----------------------------------
            # SmolVLA inference
            # ----------------------------------

            print("\nRunning SmolVLA inference...")

            with torch.no_grad():

                action = policy.select_action(
                    processed_observation
                )


            # ----------------------------------
            # Postprocess action
            # ----------------------------------

            action = postprocess(action)
            print("\nSmolVLA action feature:")
            print(policy.config.output_features)

            print("\nAction after postprocessing:")
            print(action)

            print("\nAction min/max:")
            print(action.min().item(), action.max().item())

            # ----------------------------------
            # Print action
            # ----------------------------------

            print("\n==============================")
            print("SmolVLA ACTION:")
            print(action)

            print("\nAction shape:")
            print(action.shape)

            print("\nAction values:")
            print(action.detach().cpu().numpy())

            print("==============================")


            inference_done = True

            print("\nSmolVLA inference completed!")
            print("Viewer will remain open.")


        # ----------------------------------
        # Update viewer
        # ----------------------------------

        viewer.sync()


# ==========================================
# 8. Cleanup
# ==========================================

renderer.close()

print("\nProgram finished.")