import torch
from lerobot.policies.smolvla.modeling_smolvla import SmolVLAPolicy

print("Loading SmolVLA...")

device = "cuda" if torch.cuda.is_available() else "cpu"
print("Device:", device)

policy = SmolVLAPolicy.from_pretrained("lerobot/smolvla_base")
policy = policy.to(device)

print("SmolVLA loaded successfully!")