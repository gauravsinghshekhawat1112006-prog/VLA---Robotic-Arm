import mujoco
import mujoco.viewer
import time

# --------------------------------------------------
# 1. Load UR5e model
# --------------------------------------------------

model_path = "C:/mujoco_menagerie/universal_robots_ur5e/vla_scene.xml"

model = mujoco.MjModel.from_xml_path(model_path)
data = mujoco.MjData(model)


# --------------------------------------------------
# 2. Function to control the 6 joints
# --------------------------------------------------

def move_robot(q):
    """
    q = list of 6 joint positions in radians

    Order:
    0 -> shoulder_pan
    1 -> shoulder_lift
    2 -> elbow
    3 -> wrist_1
    4 -> wrist_2
    5 -> wrist_3
    """

    if len(q) != 6:
        print("Error: You must provide exactly 6 joint values.")
        return

    for i in range(6):
        data.ctrl[i] = q[i]


# --------------------------------------------------
# 3. Define robot position
# --------------------------------------------------

home_position = [
    -1.57,   # shoulder_pan
    -1.57,   # shoulder_lift
     1.57,   # elbow
    -1.57,   # wrist_1
    -1.57,   # wrist_2
     0.0     # wrist_3
]


# --------------------------------------------------
# 4. Start MuJoCo viewer
# --------------------------------------------------

with mujoco.viewer.launch_passive(model, data) as viewer:

    while viewer.is_running():

        # Send desired joint positions
        move_robot(home_position)

        # Run physics simulation
        mujoco.mj_step(model, data)

        # Update viewer
        viewer.sync()

        # Small delay
        time.sleep(0.01)