import mujoco
import mujoco.viewer
import pygame
import time


# =========================================================
# MAIN XML
# =========================================================

MODEL_PATH = r"C:\mujoco_menagerie\universal_robots_ur5e\vla_scene.xml"


# =========================================================
# LOAD MODEL
# =========================================================

print("Loading model...")

model = mujoco.MjModel.from_xml_path(MODEL_PATH)
data = mujoco.MjData(model)
print("Model loaded successfully!")
print()
print("===== ALL ACTUATORS =====")

for i in range(model.nu):
    name = mujoco.mj_id2name(
        model,
        mujoco.mjtObj.mjOBJ_ACTUATOR,
        i
    )
    print(i, name)

print("========================")
print()

print("Model loaded successfully!")


# =========================================================
# FIND ACTUATORS
# =========================================================

def find_actuator(name):

    actuator_id = mujoco.mj_name2id(
        model,
        mujoco.mjtObj.mjOBJ_ACTUATOR,
        name
    )

    if actuator_id < 0:
        raise RuntimeError(f"Actuator not found: {name}")

    return actuator_id


shoulder_pan_actuator = find_actuator("shoulder_pan")
shoulder_lift_actuator = find_actuator("shoulder_lift")
elbow_actuator = find_actuator("elbow")
wrist1_actuator = find_actuator("wrist_1")
wrist2_actuator = find_actuator("wrist_2")
wrist3_actuator = find_actuator("wrist_3")

gripper_actuator = find_actuator("gripper_fingers_actuator")


print()
print("ACTUATORS")
print("Shoulder Pan :", shoulder_pan_actuator)
print("Shoulder Lift:", shoulder_lift_actuator)
print("Elbow        :", elbow_actuator)
print("Wrist 1      :", wrist1_actuator)
print("Wrist 2      :", wrist2_actuator)
print("Wrist 3      :", wrist3_actuator)
print("Gripper      :", gripper_actuator)

print()
print(
    "Gripper range:",
    model.actuator_ctrlrange[gripper_actuator]
)


# =========================================================
# FIND JOINTS
# =========================================================

def find_joint(name):
    joint_id = mujoco.mj_name2id(
        model,
        mujoco.mjtObj.mjOBJ_JOINT,
        name
    )

    if joint_id < 0:
        raise RuntimeError(f"Joint not found: {name}")

    return joint_id


shoulder_pan_joint = find_joint("shoulder_pan_joint")
shoulder_lift_joint = find_joint("shoulder_lift_joint")
elbow_joint = find_joint("elbow_joint")
wrist1_joint = find_joint("wrist_1_joint")
wrist2_joint = find_joint("wrist_2_joint")
wrist3_joint = find_joint("wrist_3_joint")


# =========================================================
# QPOS ADDRESSES
# =========================================================

shoulder_pan_qpos = model.jnt_qposadr[shoulder_pan_joint]
shoulder_lift_qpos = model.jnt_qposadr[shoulder_lift_joint]
elbow_qpos = model.jnt_qposadr[elbow_joint]
wrist1_qpos = model.jnt_qposadr[wrist1_joint]
wrist2_qpos = model.jnt_qposadr[wrist2_joint]
wrist3_qpos = model.jnt_qposadr[wrist3_joint]


# =========================================================
# INITIAL TARGETS
# =========================================================

targets = {

    shoulder_pan_joint:
        data.qpos[shoulder_pan_qpos],

    shoulder_lift_joint:
        data.qpos[shoulder_lift_qpos],

    elbow_joint:
        data.qpos[elbow_qpos],

    wrist1_joint:
        data.qpos[wrist1_qpos],

    wrist2_joint:
        data.qpos[wrist2_qpos],

    wrist3_joint:
        data.qpos[wrist3_qpos]
}


# =========================================================
# SETTINGS
# =========================================================

JOINT_SPEED = 1.0
DEADZONE = 0.10

GRIPPER_OPEN = 0.0
GRIPPER_CLOSE = 255.0

gripper_target = GRIPPER_OPEN


# =========================================================
# CLAMP FUNCTION
# =========================================================

def clamp(value, low, high):
    return max(low, min(high, value))


# =========================================================
# INITIAL CONTROL VALUES
# =========================================================

data.ctrl[shoulder_pan_actuator] = targets[shoulder_pan_joint]
data.ctrl[shoulder_lift_actuator] = targets[shoulder_lift_joint]
data.ctrl[elbow_actuator] = targets[elbow_joint]
data.ctrl[wrist1_actuator] = targets[wrist1_joint]
data.ctrl[wrist2_actuator] = targets[wrist2_joint]
data.ctrl[wrist3_actuator] = targets[wrist3_joint]

data.ctrl[gripper_actuator] = GRIPPER_OPEN

mujoco.mj_forward(model, data)


# =========================================================
# CONTROLLER SETUP
# =========================================================

pygame.init()
pygame.joystick.init()

if pygame.joystick.get_count() == 0:
    print("Controller not detected!")
    pygame.quit()
    raise SystemExit


joystick = pygame.joystick.Joystick(0)
joystick.init()

print()
print("Controller:", joystick.get_name())
print("Axes:", joystick.get_numaxes())
print("Buttons:", joystick.get_numbuttons())
print("Hats:", joystick.get_numhats())


# =========================================================
# CONTROLS
# =========================================================

print()
print("============================================")
print("CONTROLLER MAPPING")
print("============================================")
print("Left Stick X  -> Shoulder Pan")
print("Left Stick Y  -> Shoulder Lift")
print("Right Stick Y -> Elbow")
print("Right Stick X -> Wrist 1")
print("D-Pad X       -> Wrist 2")
print("D-Pad Y       -> Wrist 3")
print()
print("Button 0      -> GRIPPER CLOSE")
print("Button 1      -> GRIPPER OPEN")
print("============================================")
print()


# =========================================================
# RUN SIMULATION
# =========================================================

with mujoco.viewer.launch_passive(model, data) as viewer:

    last_time = time.time()

    while viewer.is_running():

        # =================================================
        # TIME
        # =================================================

        current_time = time.time()

        dt = current_time - last_time

        last_time = current_time

        if dt > 0.05:
            dt = 0.05


        # =================================================
        # CONTROLLER EVENTS
        # =================================================

        pygame.event.pump()


        # =================================================
        # READ STICKS
        # =================================================

        left_x = joystick.get_axis(0)
        left_y = joystick.get_axis(1)

        right_x = joystick.get_axis(2)
        right_y = joystick.get_axis(3)


        # =================================================
        # DEADZONE
        # =================================================

        if abs(left_x) < DEADZONE:
            left_x = 0.0

        if abs(left_y) < DEADZONE:
            left_y = 0.0

        if abs(right_x) < DEADZONE:
            right_x = 0.0

        if abs(right_y) < DEADZONE:
            right_y = 0.0


        # =================================================
        # ARM MOVEMENT
        # =================================================

        # Shoulder Pan
        targets[shoulder_pan_joint] += (
            left_x * JOINT_SPEED * dt
        )

        # Shoulder Lift
        targets[shoulder_lift_joint] += (
            -left_y * JOINT_SPEED * dt
        )

        # Elbow
        targets[elbow_joint] += (
            -right_y * JOINT_SPEED * dt
        )

        # Wrist 1
        targets[wrist1_joint] += (
            right_x * JOINT_SPEED * dt
        )


        # =================================================
        # D-PAD
        # =================================================

        if joystick.get_numhats() > 0:

            hat_x, hat_y = joystick.get_hat(0)

            # Wrist 2
            if hat_x != 0:

                targets[wrist2_joint] += (
                    hat_x * JOINT_SPEED * dt
                )

            # Wrist 3
            if hat_y != 0:

                targets[wrist3_joint] += (
                    hat_y * JOINT_SPEED * dt
                )


        # =================================================
        # JOINT LIMITS
        # =================================================

        for joint in targets:

            targets[joint] = clamp(
                targets[joint],
                model.jnt_range[joint, 0],
                model.jnt_range[joint, 1]
            )


        # =================================================
        # SEND ARM TARGETS
        # =================================================

        data.ctrl[shoulder_pan_actuator] = \
            targets[shoulder_pan_joint]

        data.ctrl[shoulder_lift_actuator] = \
            targets[shoulder_lift_joint]

        data.ctrl[elbow_actuator] = \
            targets[elbow_joint]

        data.ctrl[wrist1_actuator] = \
            targets[wrist1_joint]

        data.ctrl[wrist2_actuator] = \
            targets[wrist2_joint]

        data.ctrl[wrist3_actuator] = \
            targets[wrist3_joint]


        # =================================================
        # GRIPPER
        # =================================================

        # Button 0 = CLOSE
        if joystick.get_button(0):
            gripper_target = GRIPPER_CLOSE

        # Button 1 = OPEN
        if joystick.get_button(1):
            gripper_target = GRIPPER_OPEN

        data.ctrl[gripper_actuator] = gripper_target


        # =================================================
        # STEP
        # =================================================

        mujoco.mj_step(model, data)

        viewer.sync()

        time.sleep(0.005)


pygame.quit()