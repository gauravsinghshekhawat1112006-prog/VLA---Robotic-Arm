import time
from pathlib import Path

import mujoco
import mujoco.viewer
import pygame
import numpy as np

from lerobot.datasets import LeRobotDataset


# =========================================================
# CONFIG
# =========================================================

MODEL_PATH = r"C:\mujoco_menagerie\universal_robots_ur5e\vla_scene.xml"

DATASET_ROOT = Path(
    r"C:\Users\Krishna\lerobot\datasets\ares_ur5e_pick_cube"
)

REPO_ID = "ares/ur5e_pick_cube"

TASK = "Pick up the red cube"

FPS = 30

NUM_EPISODES = 10

EPISODE_TIME_S = 30.0

IMAGE_SIZE = 256


# =========================================================
# CHECK DATASET PATH
# =========================================================

if DATASET_ROOT.exists():

    raise RuntimeError(
        f"Dataset folder already exists:\n{DATASET_ROOT}\n\n"
        "Delete/rename it before starting a new dataset."
    )


# =========================================================
# LOAD MUJOCO
# =========================================================

print("Loading MuJoCo model...")

model = mujoco.MjModel.from_xml_path(MODEL_PATH)

data = mujoco.MjData(model)

print("Model loaded.")


# =========================================================
# ACTUATOR FINDER
# =========================================================

def find_actuator(name):

    actuator_id = mujoco.mj_name2id(
        model,
        mujoco.mjtObj.mjOBJ_ACTUATOR,
        name
    )

    if actuator_id < 0:
        raise RuntimeError(
            f"Actuator not found: {name}"
        )

    return actuator_id


# =========================================================
# ACTUATORS
# =========================================================

shoulder_pan_actuator = find_actuator(
    "shoulder_pan"
)

shoulder_lift_actuator = find_actuator(
    "shoulder_lift"
)

elbow_actuator = find_actuator(
    "elbow"
)

wrist1_actuator = find_actuator(
    "wrist_1"
)

wrist2_actuator = find_actuator(
    "wrist_2"
)

wrist3_actuator = find_actuator(
    "wrist_3"
)

gripper_actuator = find_actuator(
    "gripper_fingers_actuator"
)


# =========================================================
# JOINT FINDER
# =========================================================

def find_joint(name):

    joint_id = mujoco.mj_name2id(
        model,
        mujoco.mjtObj.mjOBJ_JOINT,
        name
    )

    if joint_id < 0:
        raise RuntimeError(
            f"Joint not found: {name}"
        )

    return joint_id


# =========================================================
# JOINTS
# =========================================================

shoulder_pan_joint = find_joint(
    "shoulder_pan_joint"
)

shoulder_lift_joint = find_joint(
    "shoulder_lift_joint"
)

elbow_joint = find_joint(
    "elbow_joint"
)

wrist1_joint = find_joint(
    "wrist_1_joint"
)

wrist2_joint = find_joint(
    "wrist_2_joint"
)

wrist3_joint = find_joint(
    "wrist_3_joint"
)

gripper_driver_joint = find_joint(
    "gripper_right_driver_joint"
)


# =========================================================
# QPOS ADDRESSES
# =========================================================

shoulder_pan_qpos = model.jnt_qposadr[
    shoulder_pan_joint
]

shoulder_lift_qpos = model.jnt_qposadr[
    shoulder_lift_joint
]

elbow_qpos = model.jnt_qposadr[
    elbow_joint
]

wrist1_qpos = model.jnt_qposadr[
    wrist1_joint
]

wrist2_qpos = model.jnt_qposadr[
    wrist2_joint
]

wrist3_qpos = model.jnt_qposadr[
    wrist3_joint
]

gripper_qpos = model.jnt_qposadr[
    gripper_driver_joint
]


# =========================================================
# CAMERA IDs
# =========================================================

workspace_camera = mujoco.mj_name2id(
    model,
    mujoco.mjtObj.mjOBJ_CAMERA,
    "workspace_camera"
)

wrist_camera = mujoco.mj_name2id(
    model,
    mujoco.mjtObj.mjOBJ_CAMERA,
    "wrist_camera"
)

if workspace_camera < 0:
    raise RuntimeError(
        "workspace_camera not found"
    )

if wrist_camera < 0:
    raise RuntimeError(
        "wrist_camera not found"
    )


print()
print("Workspace camera:", workspace_camera)
print("Wrist camera:", wrist_camera)


# =========================================================
# CONTROLLER
# =========================================================

pygame.init()

pygame.joystick.init()

if pygame.joystick.get_count() == 0:

    pygame.quit()

    raise RuntimeError(
        "Controller not detected!"
    )


joystick = pygame.joystick.Joystick(0)

joystick.init()


print()
print("Controller:", joystick.get_name())


# =========================================================
# SETTINGS
# =========================================================

JOINT_SPEED = 1.0

DEADZONE = 0.10

GRIPPER_OPEN = 0.0

GRIPPER_CLOSED = 255.0


# =========================================================
# INITIAL STATE
# =========================================================

initial_qpos = data.qpos.copy()

initial_qvel = data.qvel.copy()


# =========================================================
# TARGETS
# =========================================================

targets = {

    shoulder_pan_joint:
        data.qpos[shoulder_pan_qpos],

    shoulder_lift_joint:
        data.qpos[shoulder_lift_qpos],

    elbow_joint:
        data.qpos[elbow_qpos],

    wrist1_joint:
        data.qpos[wrist1_qpos],

    wrist2_joint:
        data.qpos[wrist2_qpos],

    wrist3_joint:
        data.qpos[wrist3_qpos]
}


gripper_target = GRIPPER_OPEN


# =========================================================
# CLAMP
# =========================================================

def clamp(value, low, high):

    return max(
        low,
        min(high, value)
    )


# =========================================================
# RESET EPISODE
# =========================================================

def reset_episode():

    global gripper_target

    data.qpos[:] = initial_qpos

    data.qvel[:] = 0

    data.ctrl[:] = 0

    targets[shoulder_pan_joint] = (
        data.qpos[shoulder_pan_qpos]
    )

    targets[shoulder_lift_joint] = (
        data.qpos[shoulder_lift_qpos]
    )

    targets[elbow_joint] = (
        data.qpos[elbow_qpos]
    )

    targets[wrist1_joint] = (
        data.qpos[wrist1_qpos]
    )

    targets[wrist2_joint] = (
        data.qpos[wrist2_qpos]
    )

    targets[wrist3_joint] = (
        data.qpos[wrist3_qpos]
    )

    gripper_target = GRIPPER_OPEN

    data.ctrl[
        shoulder_pan_actuator
    ] = targets[shoulder_pan_joint]

    data.ctrl[
        shoulder_lift_actuator
    ] = targets[shoulder_lift_joint]

    data.ctrl[
        elbow_actuator
    ] = targets[elbow_joint]

    data.ctrl[
        wrist1_actuator
    ] = targets[wrist1_joint]

    data.ctrl[
        wrist2_actuator
    ] = targets[wrist2_joint]

    data.ctrl[
        wrist3_actuator
    ] = targets[wrist3_joint]

    data.ctrl[
        gripper_actuator
    ] = GRIPPER_OPEN

    mujoco.mj_forward(
        model,
        data
    )


# =========================================================
# CREATE DATASET
# =========================================================

features = {

    "observation.state": {
        "dtype": "float32",
        "shape": (7,),
        "names": [
            "shoulder_pan",
            "shoulder_lift",
            "elbow",
            "wrist_1",
            "wrist_2",
            "wrist_3",
            "gripper"
        ]
    },

    "action": {
        "dtype": "float32",
        "shape": (7,),
        "names": [
            "shoulder_pan",
            "shoulder_lift",
            "elbow",
            "wrist_1",
            "wrist_2",
            "wrist_3",
            "gripper"
        ]
    },

    "observation.images.camera1": {
        "dtype": "image",
        "shape": (
            IMAGE_SIZE,
            IMAGE_SIZE,
            3
        ),
        "names": [
            "height",
            "width",
            "channel"
        ]
    },

    "observation.images.camera2": {
        "dtype": "image",
        "shape": (
            IMAGE_SIZE,
            IMAGE_SIZE,
            3
        ),
        "names": [
            "height",
            "width",
            "channel"
        ]
    }
}


dataset = LeRobotDataset.create(

    repo_id=REPO_ID,

    root=DATASET_ROOT,

    fps=FPS,

    robot_type="ur5e_robotiq_mujoco",

    features=features,

    use_videos=False
)


print()
print("Dataset created at:")
print(DATASET_ROOT)


# =========================================================
# RENDERER
# =========================================================

renderer = mujoco.Renderer(
    model,
    height=IMAGE_SIZE,
    width=IMAGE_SIZE
)


# =========================================================
# VIEWER
# =========================================================

with mujoco.viewer.launch_passive(
    model,
    data
) as viewer:

    print()
    print("======================================")
    print("STARTING DATA COLLECTION")
    print("======================================")
    print()
    print("Task:", TASK)
    print("Episodes:", NUM_EPISODES)
    print("Episode duration:", EPISODE_TIME_S)
    print()
    print("Control:")
    print("Left stick X  -> Shoulder Pan")
    print("Left stick Y  -> Shoulder")
    print("Right stick Y -> Elbow")
    print("Right stick X -> Wrist 1")
    print("D-pad X       -> Wrist 2")
    print("D-pad Y       -> Wrist 3")
    print("Button 0      -> Close gripper")
    print("Button 1      -> Open gripper")
    print()
    print("======================================")


    frame_period = 1.0 / FPS

    next_frame_time = time.perf_counter()


    # =====================================================
    # EPISODES
    # =====================================================

    for episode_index in range(NUM_EPISODES):

        reset_episode()

        print()
        print(
            f"========== EPISODE "
            f"{episode_index + 1}/{NUM_EPISODES} =========="
        )

        print("GO!")


        episode_start = time.perf_counter()

        next_frame_time = time.perf_counter()


        while (
            viewer.is_running()
            and
            (
                time.perf_counter()
                - episode_start
            ) < EPISODE_TIME_S
        ):

            # =============================================
            # CONTROLLER EVENTS
            # =============================================

            pygame.event.pump()


            # =============================================
            # READ STICKS
            # =============================================

            left_x = joystick.get_axis(0)

            left_y = joystick.get_axis(1)

            right_x = joystick.get_axis(2)

            right_y = joystick.get_axis(3)


            # =============================================
            # DEADZONE
            # =============================================

            if abs(left_x) < DEADZONE:
                left_x = 0.0

            if abs(left_y) < DEADZONE:
                left_y = 0.0

            if abs(right_x) < DEADZONE:
                right_x = 0.0

            if abs(right_y) < DEADZONE:
                right_y = 0.0


            # =============================================
            # ARM
            # =============================================

            targets[
                shoulder_pan_joint
            ] += (
                left_x
                * JOINT_SPEED
                * frame_period
            )


            targets[
                shoulder_lift_joint
            ] += (
                -left_y
                * JOINT_SPEED
                * frame_period
            )


            targets[
                elbow_joint
            ] += (
                -right_y
                * JOINT_SPEED
                * frame_period
            )


            targets[
                wrist1_joint
            ] += (
                right_x
                * JOINT_SPEED
                * frame_period
            )


            # =============================================
            # D-PAD
            # =============================================

            if joystick.get_numhats() > 0:

                hat_x, hat_y = joystick.get_hat(0)


                # Wrist 2
                if hat_x != 0:

                    targets[
                        wrist2_joint
                    ] += (
                        hat_x
                        * JOINT_SPEED
                        * frame_period
                    )


                # Wrist 3
                if hat_y != 0:

                    targets[
                        wrist3_joint
                    ] += (
                        hat_y
                        * JOINT_SPEED
                        * frame_period
                    )


            # =============================================
            # JOINT LIMITS
            # =============================================

            for joint in targets:

                targets[joint] = clamp(

                    targets[joint],

                    model.jnt_range[
                        joint,
                        0
                    ],

                    model.jnt_range[
                        joint,
                        1
                    ]
                )


            # =============================================
            # ARM COMMANDS
            # =============================================

            data.ctrl[
                shoulder_pan_actuator
            ] = targets[shoulder_pan_joint]

            data.ctrl[
                shoulder_lift_actuator
            ] = targets[shoulder_lift_joint]

            data.ctrl[
                elbow_actuator
            ] = targets[elbow_joint]

            data.ctrl[
                wrist1_actuator
            ] = targets[wrist1_joint]

            data.ctrl[
                wrist2_actuator
            ] = targets[wrist2_joint]

            data.ctrl[
                wrist3_actuator
            ] = targets[wrist3_joint]


            # =============================================
            # GRIPPER
            # =============================================

            if joystick.get_button(0):

                gripper_target = GRIPPER_CLOSED


            if joystick.get_button(1):

                gripper_target = GRIPPER_OPEN


            data.ctrl[
                gripper_actuator
            ] = gripper_target


            # =============================================
            # SIMULATION STEP
            # =============================================

            mujoco.mj_step(
                model,
                data
            )


            # =============================================
            # RECORD FRAME
            # =============================================

            current_time = time.perf_counter()


            if current_time >= next_frame_time:

                # -----------------------------------------
                # CAMERA 1 - WORKSPACE
                # -----------------------------------------

                renderer.update_scene(
                    data,
                    camera=workspace_camera
                )

                workspace_image = renderer.render().copy()


                # -----------------------------------------
                # CAMERA 2 - WRIST
                # -----------------------------------------

                renderer.update_scene(
                    data,
                    camera=wrist_camera
                )

                wrist_image = renderer.render().copy()


                # -----------------------------------------
                # ACTUAL ROBOT STATE
                # -----------------------------------------

                gripper_position = clamp(

                    (
                        data.qpos[gripper_qpos]
                        / 0.8
                    )
                    * 255.0,

                    0.0,

                    255.0
                )


                state = np.array([

                    data.qpos[
                        shoulder_pan_qpos
                    ],

                    data.qpos[
                        shoulder_lift_qpos
                    ],

                    data.qpos[
                        elbow_qpos
                    ],

                    data.qpos[
                        wrist1_qpos
                    ],

                    data.qpos[
                        wrist2_qpos
                    ],

                    data.qpos[
                        wrist3_qpos
                    ],

                    gripper_position

                ], dtype=np.float32)


                # -----------------------------------------
                # ACTION SENT TO ROBOT
                # -----------------------------------------

                action = np.array([

                    data.ctrl[
                        shoulder_pan_actuator
                    ],

                    data.ctrl[
                        shoulder_lift_actuator
                    ],

                    data.ctrl[
                        elbow_actuator
                    ],

                    data.ctrl[
                        wrist1_actuator
                    ],

                    data.ctrl[
                        wrist2_actuator
                    ],

                    data.ctrl[
                        wrist3_actuator
                    ],

                    data.ctrl[
                        gripper_actuator
                    ]

                ], dtype=np.float32)


                # -----------------------------------------
                # FRAME
                # -----------------------------------------

                frame = {

                    "observation.state":
                        state,

                    "action":
                        action,

                    "observation.images.camera1":
                        workspace_image,

                    "observation.images.camera2":
                        wrist_image,

                    "task":
                        TASK
                }


                dataset.add_frame(frame)


                next_frame_time += frame_period


            # =============================================
            # VIEWER
            # =============================================

            viewer.sync()


            # =============================================
            # SMALL SLEEP
            # =============================================

            time.sleep(0.001)


        # =================================================
        # SAVE EPISODE
        # =================================================

        dataset.save_episode()

        print(
            f"Episode {episode_index + 1} saved."
        )


    # =====================================================
    # CLOSE RENDERER
    # =====================================================

    renderer.close()


# =========================================================
# FINALIZE DATASET
# =========================================================

dataset.finalize()


pygame.quit()


print()
print("======================================")
print("DATA COLLECTION COMPLETE")
print("======================================")
print()
print("Dataset saved at:")
print(DATASET_ROOT)