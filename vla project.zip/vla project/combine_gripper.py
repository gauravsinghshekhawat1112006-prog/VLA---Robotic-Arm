import xml.etree.ElementTree as ET
import os
import shutil

# ---------------- PATHS ----------------
UR5E_XML = r"C:\mujoco_menagerie\universal_robots_ur5e\ur5e.xml"
GRIPPER_XML = r"C:\mujoco_gripper\robotiq_2f85\2f85.xml"

OUTPUT_XML = r"C:\mujoco_menagerie\universal_robots_ur5e\vla_scene_gripper.xml"

GRIPPER_ASSETS = r"C:\mujoco_gripper\robotiq_2f85\assets"


# ---------------- LOAD XML FILES ----------------
ur5e_tree = ET.parse(UR5E_XML)
ur5e_root = ur5e_tree.getroot()

gripper_tree = ET.parse(GRIPPER_XML)
gripper_root = gripper_tree.getroot()


# ---------------- CREATE NEW ROOT ----------------
root = ET.Element("mujoco")
root.set("model", "ur5e_with_robotiq_2f85")


# ---------------- COPY UR5E TOP LEVEL ELEMENTS ----------------
for child in ur5e_root:
    if child.tag == "worldbody":
        continue

    root.append(child)


# ---------------- FIND UR5E WORLDBODY ----------------
ur5e_worldbody = ur5e_root.find("worldbody")

if ur5e_worldbody is None:
    raise RuntimeError("Could not find UR5e worldbody")


# Copy UR5e worldbody
new_worldbody = ET.SubElement(root, "worldbody")

for child in ur5e_worldbody:
    new_worldbody.append(child)


# ---------------- FIND WRIST 3 ----------------
wrist3 = new_worldbody.find(".//body[@name='wrist_3_link']")

if wrist3 is None:
    raise RuntimeError("Could not find wrist_3_link")


# ---------------- ADD GRIPPER ASSETS ----------------
gripper_asset = gripper_root.find("asset")

if gripper_asset is not None:

    root_asset = root.find("asset")

    if root_asset is None:
        root_asset = ET.SubElement(root, "asset")

    for item in gripper_asset:
        # Change mesh paths to absolute paths
        if item.tag == "mesh":

            file_path = item.get("file")

            if file_path:
                item.set(
                    "file",
                    os.path.join(GRIPPER_ASSETS, file_path)
                )

        root_asset.append(item)


# ---------------- ADD GRIPPER DEFAULTS ----------------
gripper_default = gripper_root.find("default")

if gripper_default is not None:
    root.append(gripper_default)


# ---------------- ADD GRIPPER CONTACT ----------------
gripper_contact = gripper_root.find("contact")

if gripper_contact is not None:
    root.append(gripper_contact)


# ---------------- ADD GRIPPER TENDON ----------------
gripper_tendon = gripper_root.find("tendon")

if gripper_tendon is not None:
    root.append(gripper_tendon)


# ---------------- ADD GRIPPER EQUALITY ----------------
gripper_equality = gripper_root.find("equality")

if gripper_equality is not None:
    root.append(gripper_equality)


# ---------------- ATTACH GRIPPER ----------------
gripper_worldbody = gripper_root.find("worldbody")

if gripper_worldbody is None:
    raise RuntimeError("Could not find gripper worldbody")

base_mount = gripper_worldbody.find(".//body[@name='base_mount']")

if base_mount is None:
    raise RuntimeError("Could not find base_mount")


# Detach from original XML tree
gripper_worldbody.remove(base_mount)


# Attach to UR5e wrist
base_mount.set("pos", "0 0.1 0")
base_mount.set("quat", "-1 1 0 0")

wrist3.append(base_mount)


# ---------------- ADD GRIPPER ACTUATOR ----------------
gripper_actuator = gripper_root.find("actuator")

if gripper_actuator is not None:

    root_actuator = root.find("actuator")

    if root_actuator is None:
        root_actuator = ET.SubElement(root, "actuator")

    for actuator in gripper_actuator:
        root_actuator.append(actuator)


# ---------------- SAVE ----------------
tree = ET.ElementTree(root)

ET.indent(tree, space="  ")

tree.write(
    OUTPUT_XML,
    encoding="utf-8",
    xml_declaration=True
)

print()
print("======================================")
print("Combined model created successfully!")
print("======================================")
print()
print(OUTPUT_XML)
print()