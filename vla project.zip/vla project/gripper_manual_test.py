import mujoco
import mujoco.viewer
import time

# ============================================================
# PATHS
# ============================================================

robot_path = "C:/mujoco_menagerie/universal_robots_ur5e/vla_scene.xml"
gripper_path = "C:/mujoco_gripper/robotiq_2f85/2f85.xml"


# ============================================================
# LOAD UR5e
# ============================================================

print("Loading UR5e...")

robot_spec = mujoco.MjSpec.from_file(robot_path)

attachment_site = robot_spec.site("attachment_site")

if attachment_site is None:
    raise RuntimeError("attachment_site not found!")

print("Found attachment_site")


# ============================================================
# LOAD GRIPPER
# ============================================================

print("Loading Robotiq 2F-85...")

gripper_spec = mujoco.MjSpec.from_file(gripper_path)

print("Gripper loaded")


# ============================================================
# ATTACH GRIPPER
# ============================================================

robot_spec.attach(
    gripper_spec,
    site=attachment_site,
    prefix="gripper_"
)

print("Gripper attached")


# ============================================================
# COMPILE
# ============================================================

model = robot_spec.compile()
data = mujoco.MjData(model)

print("Model compiled")


# ============================================================
# FIND GRIPPER ACTUATOR
# ============================================================

gripper_actuator_id = mujoco.mj_name2id(
    model,
    mujoco.mjtObj.mjOBJ_ACTUATOR,
    "gripper_fingers_actuator"
)

print("Gripper actuator ID:", gripper_actuator_id)

print()
print("======================================")
print("GRIPPER CONTROL")
print("======================================")
print("Use the MuJoCo control slider.")
print("Gripper range: 0 - 255")
print("======================================")
print()


# ============================================================
# OPEN VIEWER
# ============================================================

with mujoco.viewer.launch_passive(model, data) as viewer:

    while viewer.is_running():

        # IMPORTANT:
        # Do NOT overwrite data.ctrl here.
        #
        # The MuJoCo GUI control slider directly changes
        # data.ctrl[gripper_actuator_id].

        mujoco.mj_step(model, data)

        viewer.sync()

        time.sleep(0.005)


print("Program finished.")