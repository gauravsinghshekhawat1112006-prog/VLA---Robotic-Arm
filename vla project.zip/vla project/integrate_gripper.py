import xml.etree.ElementTree as ET

SCENE = r"C:\mujoco_menagerie\universal_robots_ur5e\vla_scene.xml"

tree = ET.parse(SCENE)
root = tree.getroot()

# -------------------------------------------------
# Rename Robotiq default classes so they don't
# conflict with UR5e classes
# -------------------------------------------------

rename = {
    "2f85": "gripper2f85",
    "driver": "gripper_driver",
    "follower": "gripper_follower",
    "spring_link": "gripper_spring_link",
    "coupler": "gripper_coupler",
    "visual": "gripper_visual",
    "collision": "gripper_collision",
    "pad_box1": "gripper_pad_box1",
    "pad_box2": "gripper_pad_box2",
}

# Find the Robotiq default block
defaults = root.find("default")

if defaults is None:
    raise RuntimeError("No default section found")

# Find the Robotiq top-level default
gripper_default = None

for d in defaults.findall("default"):
    if d.get("class") == "2f85":
        gripper_default = d
        break

if gripper_default is None:
    raise RuntimeError("Robotiq default class '2f85' not found")

# Rename default class hierarchy
for element in gripper_default.iter("default"):
    old = element.get("class")
    if old in rename:
        element.set("class", rename[old])

# Rename the Robotiq top-level class itself
gripper_default.set("class", "gripper2f85")


# -------------------------------------------------
# Find Robotiq base_mount and rename its classes
# -------------------------------------------------

base_mount = root.find(".//body[@name='base_mount']")

if base_mount is None:
    raise RuntimeError("base_mount not found")

for element in base_mount.iter():

    class_name = element.get("class")

    if class_name in rename:
        element.set("class", rename[class_name])


# -------------------------------------------------
# Rename Robotiq actuator class
# -------------------------------------------------

for actuator in root.findall("./actuator/*"):

    if actuator.get("name") == "fingers_actuator":
        actuator.set("class", "gripper2f85")


# -------------------------------------------------
# Rename Robotiq mesh classes
# -------------------------------------------------

for mesh in root.findall("./asset/mesh"):

    if mesh.get("class") == "2f85":
        mesh.set("class", "gripper2f85")


# -------------------------------------------------
# Save existing vla_scene.xml
# -------------------------------------------------

ET.indent(tree, space="  ")

tree.write(
    SCENE,
    encoding="utf-8",
    xml_declaration=True
)

print("======================================")
print("Robotiq class conflicts fixed")
print("======================================")
print(SCENE)