import mujoco
import mujoco.viewer
import torch
import numpy as np
import time

from lerobot.policies.smolvla.modeling_smolvla import SmolVLAPolicy
from lerobot.policies.factory import make_pre_post_processors


# ============================================================
# PATHS
# ============================================================

robot_path = "C:/mujoco_menagerie/universal_robots_ur5e/vla_scene.xml"
gripper_path = "C:/mujoco_gripper/robotiq_2f85/2f85.xml"


# ============================================================
# LOAD UR5e
# ============================================================

print("Loading UR5e...")

robot_spec = mujoco.MjSpec.from_file(robot_path)

attachment_site = robot_spec.site("attachment_site")

if attachment_site is None:
    raise RuntimeError("attachment_site not found!")

print("Found attachment_site")


# ============================================================
# LOAD ROBOTIQ 2F-85
# ============================================================

print("Loading Robotiq 2F-85...")

gripper_spec = mujoco.MjSpec.from_file(gripper_path)

print("Gripper loaded")


# ============================================================
# ATTACH GRIPPER
# ============================================================

robot_spec.attach(
    gripper_spec,
    site=attachment_site,
    prefix="gripper_"
)

print("Gripper attached")


# ============================================================
# COMPILE MODEL
# ============================================================

model = robot_spec.compile()
data = mujoco.MjData(model)

print("MuJoCo model compiled successfully!")


# ============================================================
# FIND GRIPPER ACTUATOR
# ============================================================

gripper_actuator_id = mujoco.mj_name2id(
    model,
    mujoco.mjtObj.mjOBJ_ACTUATOR,
    "gripper_fingers_actuator"
)

print("Gripper actuator ID:", gripper_actuator_id)


# ============================================================
# LOAD SMOLVLA
# ============================================================

print()
print("Loading SmolVLA...")

device = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)

print("Device:", device)

policy = SmolVLAPolicy.from_pretrained(
    "lerobot/smolvla_base"
)

policy = policy.to(device)

print("SmolVLA loaded successfully!")


# ============================================================
# CREATE PROCESSORS
# ============================================================

print()
print("Creating SmolVLA processor...")

preprocess, postprocess = make_pre_post_processors(
    policy_cfg=policy.config,
    pretrained_path="lerobot/smolvla_base",
)

print("Processor ready!")


# ============================================================
# CAMERA
# ============================================================

renderer = mujoco.Renderer(
    model,
    height=256,
    width=256
)

camera_id = mujoco.mj_name2id(
    model,
    mujoco.mjtObj.mjOBJ_CAMERA,
    "vla_camera"
)

if camera_id < 0:
    raise RuntimeError("vla_camera not found!")

print("Camera ID:", camera_id)


# ============================================================
# UR5e JOINTS
# ============================================================

joint_names = [
    "shoulder_pan_joint",
    "shoulder_lift_joint",
    "elbow_joint",
    "wrist_1_joint",
    "wrist_2_joint",
    "wrist_3_joint"
]

joint_ids = []

for name in joint_names:

    joint_id = mujoco.mj_name2id(
        model,
        mujoco.mjtObj.mjOBJ_JOINT,
        name
    )

    if joint_id < 0:
        raise RuntimeError(
            f"Joint not found: {name}"
        )

    joint_ids.append(joint_id)

print("Joint IDs:", joint_ids)


# ============================================================
# TASK
# ============================================================

task = "Pick up the red cube"

print()
print("Task:", task)


# ============================================================
# OPEN VIEWER
# ============================================================

print()
print("Opening MuJoCo viewer...")

with mujoco.viewer.launch_passive(model, data) as viewer:

    inference_done = False

    while viewer.is_running():

        # ====================================================
        # RUN SIMULATION
        # ====================================================

        mujoco.mj_step(model, data)


        # ====================================================
        # SMOLVLA INFERENCE - ONLY ONCE
        # ====================================================

        if not inference_done:

            print()
            print("======================================")
            print("Preparing observation...")
            print("======================================")


            # ------------------------------------------------
            # ROBOT STATE
            # ------------------------------------------------

            robot_state = np.array(
                [
                    data.qpos[joint_id]
                    for joint_id in joint_ids
                ],
                dtype=np.float32
            )

            print()
            print("Robot state:")
            print(robot_state)


            # ------------------------------------------------
            # CAMERA IMAGE
            # ------------------------------------------------

            renderer.update_scene(
                data,
                camera=camera_id
            )

            image = renderer.render()

            print("Camera image captured!")


            # ------------------------------------------------
            # IMAGE → TENSOR
            # ------------------------------------------------

            image_tensor = (
                torch.from_numpy(image.copy())
                .float()
                / 255.0
            )

            image_tensor = image_tensor.permute(2, 0, 1)


            # ------------------------------------------------
            # OBSERVATION
            # ------------------------------------------------

            observation = {

                "observation.state":
                    torch.tensor(
                        robot_state,
                        dtype=torch.float32
                    ),

                "observation.images.camera1":
                    image_tensor,

                "observation.images.camera2":
                    image_tensor,

                "observation.images.camera3":
                    image_tensor,

                "task":
                    task
            }


            # ------------------------------------------------
            # PREPROCESS
            # ------------------------------------------------

            print()
            print("Preprocessing observation...")

            processed_observation = preprocess(
                observation
            )

            print("Preprocessing successful!")


            # ------------------------------------------------
            # SMOLVLA INFERENCE
            # ------------------------------------------------

            print()
            print("Running SmolVLA inference...")

            with torch.no_grad():

                action = policy.select_action(
                    processed_observation
                )


            # ------------------------------------------------
            # POSTPROCESS
            # ------------------------------------------------

            action = postprocess(action)


            # ------------------------------------------------
            # PRINT ACTION
            # ------------------------------------------------

            print()
            print("======================================")
            print("SMOLVLA ACTION")
            print("======================================")

            print(action)

            print()
            print("Action shape:")
            print(action.shape)


            # ------------------------------------------------
            # GRIPPER STATUS
            # ------------------------------------------------

            print()
            print("======================================")
            print("GRIPPER")
            print("======================================")

            print(
                "Current gripper control:",
                data.ctrl[gripper_actuator_id]
            )

            print()
            print(
                "Use the MuJoCo gripper slider "
                "to manually control the gripper."
            )


            # =================================================
            # IMPORTANT
            # =================================================
            #
            # SmolVLA action is NOT sent to the UR5e yet.
            #
            # We will first correctly map the SmolVLA action
            # representation to the UR5e control space.
            #
            # =================================================


            inference_done = True

            print()
            print("======================================")
            print("SmolVLA inference completed!")
            print("Viewer will remain open.")
            print("======================================")


        # ====================================================
        # UPDATE VIEWER
        # ====================================================

        viewer.sync()

        time.sleep(0.005)


# ============================================================
# CLEANUP
# ============================================================

renderer.close()

print()
print("Program finished.")