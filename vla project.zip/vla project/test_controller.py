import pygame
import time

pygame.init()
pygame.joystick.init()

if pygame.joystick.get_count() == 0:
    print("❌ No controller detected")
    exit()

joystick = pygame.joystick.Joystick(0)
joystick.init()

print("✅ Controller:", joystick.get_name())
print("Axes:", joystick.get_numaxes())
print("Buttons:", joystick.get_numbuttons())
print("D-pads:", joystick.get_numhats())

print("\n================================")
print("   ARES CONTROLLER MAPPING TEST")
print("================================")
print("Move ONE control at a time.")
print("Press Ctrl+C to stop.\n")

last_axes = [0] * joystick.get_numaxes()
last_buttons = [0] * joystick.get_numbuttons()
last_hats = [(0, 0)] * joystick.get_numhats()

while True:

    pygame.event.pump()

    # ---------- AXES ----------
    for i in range(joystick.get_numaxes()):
        value = round(joystick.get_axis(i), 2)

        if abs(value - last_axes[i]) > 0.05:
            print(f"AXIS {i}  →  {value}")
            last_axes[i] = value

    # ---------- BUTTONS ----------
    for i in range(joystick.get_numbuttons()):
        value = joystick.get_button(i)

        if value != last_buttons[i]:
            if value == 1:
                print(f"BUTTON {i}  →  PRESSED")
            else:
                print(f"BUTTON {i}  →  RELEASED")

            last_buttons[i] = value

    # ---------- D-PAD ----------
    for i in range(joystick.get_numhats()):
        value = joystick.get_hat(i)

        if value != last_hats[i]:
            print(f"D-PAD {i}  →  {value}")
            last_hats[i] = value

    time.sleep(0.02)