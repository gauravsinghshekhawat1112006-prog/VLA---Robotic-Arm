# Robot arm cube pickup: how to run everything on your Mac

This folder has everything needed: the scene, the arm meshes (`assets/`), all scripts and
two trained models.

| Model | File | What it is |
|---|---|---|
| **New** (default) | `training/run7_graded_b/checkpoints/best.pt` | Picks all around the robot, 0.20–0.66 m from the base. Graded gripper (squeezes according to cube size). 126/144 in the final test. |
| Original | `training/run3_360/checkpoints/best.pt` | The earlier 360° model. On/off gripper. 125/144 in the same test. |
| Old front-only | `training/run1/checkpoints/best.pt` | First model, front area only, needs `vla_scene_v2.xml`. |

Every command below is typed in **Terminal**, inside this folder.
On a Mac, any command that opens a window must start with **`mjpython`**, not `python`.

## 1. Install (only once)

    cd ~/Downloads/vla_mac_inner          # or wherever you unzipped it
    python3 -m venv .venv
    source .venv/bin/activate
    pip install mujoco h5py numpy pillow matplotlib torch imageio imageio-ffmpeg

Every time you open a new Terminal later, run only these two lines first:

    cd ~/Downloads/vla_mac_inner
    source .venv/bin/activate

Check that it works (no window, prints PASS/FAIL):

    python verify_setup.py --model vla_scene_v3.xml

## 2. The main viewer: sliders + live gripper camera  ← start here

    mjpython viewer_cam.py

What you see:
- **Top-left corner:** two live pictures. The **first (top) is the gripper camera**, the camera
  mounted on the gripper. The **second is the overhead camera**. These are exactly the two
  pictures the model looks at to decide each move.
- **Right panel:** click **Control** to open it. At the bottom are 3 sliders:
  **CUBE_X** (+ forward / − behind, metres), **CUBE_Y** (+ robot's left / − right, metres)
  and **CUBE_YAW** (turn the cube, degrees).
- A see-through box shows where the cube will go: green = inside the trained area
  (0.20–0.66 m from the base), orange = outside.

Keys (click the 3D view first, so the keys go to it and not to the sliders):

| Key | What it does |
|---|---|
| **R** | Restart: arm back to start, cube at the slider spot, model picks it up |
| **N** | New random spot (sliders move there too) |
| **P** | Pause / continue |
| **Tab** | Show/hide the left panel (hidden at start so it does not cover the camera pictures) |

The Terminal prints each result and a running score. Use **R**, not the panel's "Reset" button.
The arm's own sliders in the Control panel do nothing (the model drives the arm).

Options:

    mjpython viewer_cam.py --cams wrist            # only the gripper camera picture
    mjpython viewer_cam.py --cam-size 0.40         # bigger pictures (fraction of window height)
    mjpython viewer_cam.py --cams none             # no pictures
    mjpython viewer_cam.py --ckpt training/run3_360/checkpoints/best.pt --gripper binary   # original model

`viewer_sidebar.py` is the older version of this viewer (same sliders, no camera pictures).

## 3. Put the cube at exact coordinates (no sliders)

    mjpython play_policy.py --ckpt training/run7_graded_b/checkpoints/best.pt --x -0.45 --y 0.0    # behind
    mjpython play_policy.py --ckpt training/run7_graded_b/checkpoints/best.pt --x 0.0 --y 0.50     # left
    mjpython play_policy.py --ckpt training/run7_graded_b/checkpoints/best.pt --x 0.25 --y 0.0     # close in

`x` = forward, `y` = robot's left, both in metres. `--yaw 20` turns the cube.
Keep spots 0.20–0.66 m from the base. Closer than 0.20 m the arm hits its own base.

## 4. Test a model properly (no window, gives a score)

Quick test, about 10 minutes (4 spots per band):

    python eval_radial.py --ckpt training/run7_graded_b/checkpoints/best.pt --out evaluation/my_quick --per-band 4 --seed 9700
    python eval_radial.py --out evaluation/my_quick --summarize

Full test, the same 96 spots as in the report (about 1 to 2 hours):

    python eval_radial.py --ckpt training/run7_graded_b/checkpoints/best.pt --out evaluation/my_full --per-band 32 --seed 9700
    python eval_radial.py --out evaluation/my_full --summarize

Add `--cube-mm 45 60 --per-band 16 --seed 9800` for the mixed-size test.
If it stops halfway, run the same command again: it continues where it stopped.
Results go to `evaluation/my_.../results.json`, plus a few videos in `videos/`.

My own results (the ones in the report) are in `evaluation/inner_test/`.

## 5. Record new demos and train more (optional)

Record 50 demos with the scripted pilot (no window):

    python record_episodes.py --auto 50 --headless --model vla_scene_v3.xml --spawn ring --inner-frac 0.5 --cube-mm 45 60 --yaw-deg 30 --gripper graded --max-sec 25 --out dataset/more --seed 5000

Convert them and fine-tune the new model (uses the Apple GPU if it can; else add `--device cpu`):

    python convert_dataset.py --data dataset/more --out dataset/cache
    python train_policy.py --data dataset/cache --out training/my_run --init training/run7_graded_b/checkpoints/best.pt --epochs 4 --lr 7e-5 --frames-per-epoch 40000

If training stops, add `--resume` to the same command. Then watch your model:

    mjpython viewer_cam.py --ckpt training/my_run/checkpoints/best.pt

Training only on 50 new demos can make the model forget other areas. The new model was trained
on 300 new demos plus 340 old ones (see the report).

## 6. Report and charts

`report/REPORT_inner_radius_gripper.md` explains what changed and the honest results;
`report/charts/` has the charts.

## Files

| File | What it does |
|---|---|
| `viewer_cam.py` | Viewer with sliders and live camera pictures (section 2) |
| `viewer_sidebar.py` | Same viewer without camera pictures |
| `play_policy.py` | Viewer with typed coordinates (section 3) |
| `policy.py` | The model (the "brain") |
| `record_episodes.py` | Scene control, scripted pilot, IK, demo recording |
| `convert_dataset.py`, `train_policy.py` | Prepare demos and train |
| `eval_radial.py` | Test by distance band (section 4) |
| `eval_region.py`, `eval_policy.py` | Older tests (by direction) |
| `compare_plots.py`, `plot_coverage_circle.py` | Make the report charts |
| `relabel_gripper.py`, `diag_gripper.py`, `diag_grasp_timing.py` | Gripper tools used for the new model |
| `verify_setup.py`, `validate_dataset.py`, `inspect_episode.py`, `merge_workers.py`, `coverage_360.py` | Helpers |
| `vla_scene_v3.xml` | The scene (overhead camera). `vla_scene_v2.xml` is the old front-only one |
