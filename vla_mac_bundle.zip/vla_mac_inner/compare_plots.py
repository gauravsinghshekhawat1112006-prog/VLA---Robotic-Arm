"""
compare_plots.py  -  before/after charts for the inner-radius + gripper fine-tune.

  python compare_plots.py --before ../eval_inner/baseline_run3_60mm --after ../eval_inner/final_run4_60mm \
      --before-sizes ../eval_inner/baseline_run3_sizes --after-sizes ../eval_inner/final_run4_sizes \
      --stages ../training/run4_inner_s1 ../training/run4_inner_s2 ../training/run4_inner_s3 \
      --stage-evals ../eval_inner/quick_s1 ../eval_inner/quick_s2 ../eval_inner/quick_s3 \
      --gripper-diag ../diag/gripper_response.json --out ../eval_inner/charts

Every number comes from the part*.json / traces written by eval_radial.py and the log.csv written
by train_policy.py; nothing is typed in by hand.
  1_success_vs_radius.png   grasp-and-lift rate in 4 cm distance bins, before vs after
  2_before_after_bands.png  inner / middle / outer, before vs after (60 mm set and 45-60 mm set)
  3_success_vs_angle.png    grasp-and-lift rate per 45 deg direction
  4_training.png            validation loss over all fine-tune epochs + quick test after each stage
  5_gripper.png             gripper command vs measured finger opening
"""
import argparse
import csv
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from eval_radial import BANDS, load_rows

BEFORE, AFTER, INK, MUTED, GRID = "#2a78d6", "#eb6834", "#0b0b0b", "#52514e", "#e4e3df"
plt.rcParams.update({"axes.edgecolor": MUTED, "axes.labelcolor": INK, "xtick.color": MUTED, "ytick.color": MUTED,
                     "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": GRID,
                     "grid.linewidth": 0.8, "font.size": 10, "figure.facecolor": "#fcfcfb", "axes.facecolor": "#fcfcfb",
                     "lines.linewidth": 2, "legend.frameon": False})


def rate(rows):
    return (sum(r["grasp_lift"] for r in rows) / len(rows), len(rows)) if rows else (np.nan, 0)


def binned(rows, key, edges):
    out = []
    for a, b in zip(edges[:-1], edges[1:]):
        out.append(rate([r for r in rows if a <= r[key] < b]))
    return out


def shade_bands(ax):
    for (name, (a, b)), c in zip(BANDS.items(), ("#f2efe8", "#fcfcfb", "#f2efe8")):
        ax.axvspan(a, b, color=c, zorder=0)
        ax.text((a + b) / 2, 1.07, name, ha="center", color=MUTED, fontsize=9)


def line_pair(ax, x, sets, labels, key, edges):
    for rows, lab, col in zip(sets, labels, (BEFORE, AFTER)):
        if rows is None:
            continue
        v = binned(rows, key, edges)
        ax.plot(x, [p for p, _ in v], "-o", color=col, ms=6, label=lab, mec="#fcfcfb", mew=2)
    ax.set_ylim(0, 1.12)
    ax.set_yticks([0, .25, .5, .75, 1])
    ax.set_yticklabels(["0%", "25%", "50%", "75%", "100%"])


def plot_radius(before, after, out):
    edges = np.arange(0.20, 0.661, 0.04)
    edges[-1] = 0.661
    x = (edges[:-1] + edges[1:]) / 2
    fig, ax = plt.subplots(figsize=(8, 4))
    shade_bands(ax)
    line_pair(ax, x, (before, after), ("before (run3)", "after (run7)"), "radius", edges)
    n = [k for _, k in binned(before, "radius", edges)]
    ax.set(xlabel="cube distance from robot base (m)", ylabel="grasp-and-lift rate",
           title=f"Success vs distance (same {len(before)} test spots, 60 mm cube; tries per bin: {min(n)}-{max(n)})")
    ax.legend(loc="lower left")
    fig.tight_layout()
    fig.savefig(out, dpi=130)
    plt.close(fig)


def plot_bands(sets, out):
    fig, axes = plt.subplots(1, len(sets), figsize=(5 * len(sets), 4), squeeze=False)
    for ax, (title, before, after) in zip(axes[0], sets):
        x = np.arange(len(BANDS))
        for i, (rows, lab, col) in enumerate(((before, "before (run3)", BEFORE), (after, "after (run7)", AFTER))):
            if rows is None:
                continue
            v = [rate([r for r in rows if r["band"] == b]) for b in BANDS]
            bars = ax.bar(x + (i - 0.5) * 0.38, [p for p, _ in v], 0.36, color=col, label=lab, edgecolor="#fcfcfb", lw=2)
            for bar, (p, k) in zip(bars, v):
                ax.text(bar.get_x() + bar.get_width() / 2, p + 0.02, f"{round(p * k)}/{k}", ha="center", fontsize=8, color=INK)
        ax.set_xticks(x)
        ax.set_xticklabels([f"{b}\n{a:.2f}-{c:.2f} m" for b, (a, c) in BANDS.items()])
        ax.set_ylim(0, 1.15)
        ax.set(title=title, ylabel="grasp-and-lift rate")
        ax.grid(axis="x", visible=False)
        ax.legend(loc="lower right")
    fig.tight_layout()
    fig.savefig(out, dpi=130)
    plt.close(fig)


def plot_angle(before, after, out):
    edges = np.arange(0, 361, 45)
    x = edges[:-1] + 22.5
    fig, ax = plt.subplots(figsize=(8, 4))
    line_pair(ax, x, (before, after), ("before (run3)", "after (run7)"), "angle_deg", edges)
    ax.set_xticks(x)
    ax.set_xticklabels(["0-45\nfront", "45-90", "90-135\nleft", "135-180", "180-225\nbehind", "225-270",
                        "270-315\nright", "315-360"])
    ax.set(xlabel="direction of the cube (deg, 0 = in front of the robot)", ylabel="grasp-and-lift rate",
           title="Success vs direction (all 3 bands, 60 mm cube)")
    ax.legend(loc="lower left")
    fig.tight_layout()
    fig.savefig(out, dpi=130)
    plt.close(fig)


def plot_training(stages, stage_evals, out):
    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    e0, ticks = 0, []
    for k, d in enumerate(stages):
        rows = list(csv.DictReader(open(os.path.join(d, "log.csv"))))
        e = [e0 + int(r["epoch"]) for r in rows]
        ax[0].plot(e, [float(r["train_loss"]) for r in rows], color=BEFORE, label="training" if k == 0 else None)
        ax[0].plot(e, [float(r["val_loss"]) for r in rows], color=AFTER, label="validation" if k == 0 else None)
        ax[0].axvline(e0 + 0.5, color=MUTED, lw=0.8, ls=":")
        ax[0].text(e0 + 0.7, 0.98, f"stage {k + 1}", color=MUTED, fontsize=8, va="top", transform=ax[0].get_xaxis_transform())
        ticks.append(e[-1])
        e0 = e[-1]
    ax[0].set(xlabel="fine-tune epoch (all stages)", ylabel="loss (L1 move + gripper)",
              title="Training loss (imitation learning: there is no reward)")
    ax[0].legend()
    if stage_evals:
        labels = ["before fine-tune"] + [f"after stage {i}" for i in range(1, len(stage_evals))]
        x = np.arange(len(stage_evals))
        for j, b in enumerate(BANDS):
            v = [rate([r for r in load_rows(d) if r["band"] == b])[0] for d in stage_evals]
            ax[1].plot(x, v, "-o", ms=7, mec="#fcfcfb", mew=2, label=b, color=(BEFORE, AFTER, "#1baf7a")[j])
        n = len(load_rows(stage_evals[0])) // len(BANDS)
        ax[1].set_xticks(x)
        ax[1].set_xticklabels(labels)
        ax[1].set_ylim(0, 1.1)
        ax[1].set(ylabel="grasp-and-lift rate", title=f"Quick physics test after each stage ({n} tries per band)")
        ax[1].legend(loc="lower right")
    fig.tight_layout()
    fig.savefig(out, dpi=130)
    plt.close(fig)


def plot_gripper(diag, before_dir, after_dir, out):
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.2))
    if diag:
        d = json.load(open(diag))
        ax[0].plot([r["cmd"] / 255 for r in d["free"]], [r["opening"] for r in d["free"]], color=MUTED,
                   label="empty gripper (bench test)")
    for dd, lab, col in ((before_dir, "before: while holding", BEFORE), (after_dir, "after: while holding", AFTER)):
        rows = [r for r in load_rows(dd) if r["pickup"]]
        c, o = [], []
        for r in rows:
            tr = np.load(os.path.join(dd, "traces", f"id{r['id']:03d}.npz"))
            k = r["success_step"]
            c.append(float(np.mean(tr["cmd"][k:])))
            o.append(float(np.mean(tr["opening"][k:])))
        ax[0].scatter(c, o, s=30, color=col, edgecolor="#fcfcfb", lw=1, label=lab, zorder=3)
    ax[0].set(xlabel="gripper command (0 = open, 1 = fully closed)", ylabel="measured finger closure (0 = open, 1 = shut)",
              title="Command vs actual finger position")
    ax[0].legend(loc="upper left", fontsize=8)
    # one example episode of each model: command and measured opening over time
    for dd, lab, col in ((before_dir, "before", BEFORE), (after_dir, "after", AFTER)):
        rows = [r for r in load_rows(dd) if r["grasp_lift"] and r["band"] == "inner"]
        if not rows:
            continue
        tr = np.load(os.path.join(dd, "traces", f"id{rows[0]['id']:03d}.npz"))
        t = np.arange(len(tr["cmd"])) / 20.0
        ax[1].plot(t, tr["cmd"], color=col, label=f"{lab}: command")
        ax[1].plot(t, tr["opening"], color=col, ls="--", lw=1.5, label=f"{lab}: measured opening")
    ax[1].set(xlabel="time (s)", ylabel="0 = open", title=f"One inner pickup over time (spot id {rows[0]['id']})")
    ax[1].legend(fontsize=8, loc="upper left")
    fig.tight_layout()
    fig.savefig(out, dpi=130)
    plt.close(fig)


def plot_attempts(attempts, out):
    """Every model tried, same 60 mm spots: grasp-and-lift per band (honest record of what did not work too)."""
    cols = ["#8f8e88", "#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#6250d6"]
    fig, ax = plt.subplots(figsize=(10, 4))
    x = np.arange(len(BANDS))
    w = 0.8 / len(attempts)
    for i, (lab, d) in enumerate(attempts):
        rows = load_rows(d)
        v = [rate([r for r in rows if r["band"] == b]) for b in BANDS]
        bars = ax.bar(x - 0.4 + w * (i + 0.5), [p for p, _ in v], w * 0.92, color=cols[i % len(cols)], label=lab)
        for bar, (p, k) in zip(bars, v):
            ax.text(bar.get_x() + bar.get_width() / 2, p + 0.015, f"{round(p * k)}", ha="center", fontsize=7, color=INK)
    ax.set_xticks(x)
    ax.set_xticklabels([f"{b}  {a:.2f}-{c:.2f} m" for b, (a, c) in BANDS.items()])
    ax.set_ylim(0, 1.12)
    ax.set(ylabel="grasp-and-lift rate", title="All fine-tune attempts on the same 96 spots (60 mm cube, 32 per band)")
    ax.grid(axis="x", visible=False)
    ax.legend(fontsize=8, ncol=6, loc="upper center", bbox_to_anchor=(0.5, -0.12))
    fig.tight_layout()
    fig.savefig(out, dpi=130)
    plt.close(fig)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--before", required=True)
    p.add_argument("--after", required=True)
    p.add_argument("--before-sizes")
    p.add_argument("--after-sizes")
    p.add_argument("--stages", nargs="*", default=[])
    p.add_argument("--stage-evals", nargs="*", default=[])
    p.add_argument("--gripper-diag")
    p.add_argument("--attempts", nargs="*", default=[], help="LABEL=DIR pairs for the all-attempts chart")
    p.add_argument("--out", required=True)
    a = p.parse_args()
    os.makedirs(a.out, exist_ok=True)
    before, after = load_rows(a.before), load_rows(a.after)
    plot_radius(before, after, os.path.join(a.out, "1_success_vs_radius.png"))
    sets = [("60 mm cube (same spots)", before, after)]
    if a.before_sizes and a.after_sizes:
        sets.append(("45-60 mm cubes (same spots)", load_rows(a.before_sizes), load_rows(a.after_sizes)))
    plot_bands(sets, os.path.join(a.out, "2_before_after_bands.png"))
    plot_angle(before, after, os.path.join(a.out, "3_success_vs_angle.png"))
    if a.stages:
        plot_training(a.stages, a.stage_evals, os.path.join(a.out, "4_training.png"))
    plot_gripper(a.gripper_diag, a.before_sizes or a.before, a.after_sizes or a.after, os.path.join(a.out, "5_gripper.png"))
    if a.attempts:
        plot_attempts([t.split("=", 1) for t in a.attempts], os.path.join(a.out, "6_all_attempts.png"))
    print("charts in", a.out)


if __name__ == "__main__":
    main()
