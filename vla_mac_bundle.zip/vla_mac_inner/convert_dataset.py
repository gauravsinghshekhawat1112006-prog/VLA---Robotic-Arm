"""
convert_dataset.py  -  HDF5 episodes -> one compact training file (.npz).

  python convert_dataset.py --data ../dataset/episodes --out ../dataset/train_cache.npz [--size 112]
  python convert_dataset.py --data ../dataset360/episodes --out ../dataset360/cache   (folder = big datasets)

If --out is a folder (no .npz), images go to <out>/images.npy, which training opens
memory-mapped, so datasets bigger than RAM work; everything else goes to <out>/meta.npz.
--data can be given several times to combine folders.

What goes in (policy inputs, NO ground-truth cube position):
  images  (N, 2, S, S, 3) uint8   workspace + wrist camera, resized to SxS
  state   (N, 10) float32         joint_pos (6) + gripper opening (1) + ee_pos (3)
What the policy learns to output:
  action  (N, 4) float32          delta EE xyz (m) + gripper (0/1)  (the recorder's `action`)
Plus episode bookkeeping:
  episode_index (N,), frame_index (N,), episode_ends (E,) and per-file names.
Normalisation stats are computed from the data and stored in the file.

The same resize function (`preprocess_image`) is used at evaluation time.
"""
import argparse
import glob
import json
import os

import h5py
import numpy as np
from PIL import Image


def preprocess_image(img, size):
    return np.asarray(Image.fromarray(img).resize((size, size), Image.BILINEAR))


def state_vector(joint_pos, gripper, ee_pos):
    return np.concatenate([joint_pos, np.atleast_1d(gripper), ee_pos]).astype(np.float32)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", required=True, action="append")
    p.add_argument("--out", required=True)
    p.add_argument("--size", type=int, default=112)
    args = p.parse_args()

    files = [f for d in args.data for f in sorted(glob.glob(os.path.join(d, "episode_*.hdf5")))]
    folder = not args.out.endswith(".npz")
    mm = None
    if folder:
        os.makedirs(args.out, exist_ok=True)
        total = 0
        for f in files:
            with h5py.File(f, "r") as h:
                total += int(h.attrs["num_steps"]) if bool(h.attrs["success"]) else 0
        mm = np.lib.format.open_memmap(os.path.join(args.out, "images.npy"), "w+", np.uint8,
                                       (total, 2, args.size, args.size, 3))
    cube_xy = []
    images, states, actions, ep_idx, fr_idx, ends, names, instr = [], [], [], [], [], [], [], []
    n = 0
    for e, f in enumerate(files):
        with h5py.File(f, "r") as h:
            if not bool(h.attrs["success"]):
                print("skipping unsuccessful", f)
                continue
            T = int(h.attrs["num_steps"])
            ws = h["observations/images/workspace"][:]
            wr = h["observations/images/wrist"][:]
            for t in range(T):
                im = np.stack([preprocess_image(ws[t], args.size), preprocess_image(wr[t], args.size)])
                if folder:
                    mm[n + t] = im
                else:
                    images.append(im)
            states.append(np.concatenate([h["observations/joint_pos"][:], h["observations/gripper"][:],
                                          h["observations/ee_pos"][:]], 1))
            actions.append(h["action"][:])
            ep_idx.append(np.full(T, len(names)))
            fr_idx.append(np.arange(T))
            n += T
            ends.append(n)
            names.append(os.path.relpath(f))
            cube_xy.append(h["observations/cube_pos"][0, :2])
            instr.append(str(h.attrs["language_instruction"]))
        print(f"{os.path.basename(f)}: {T} steps")

    states = np.concatenate(states).astype(np.float32)
    actions = np.concatenate(actions).astype(np.float32)
    stats = {
        "state_mean": states.mean(0).tolist(), "state_std": (states.std(0) + 1e-6).tolist(),
        "action_mean": actions[:, :3].mean(0).tolist(), "action_std": (actions[:, :3].std(0) + 1e-6).tolist(),
        "image_size": args.size, "num_episodes": len(names), "num_frames": int(n),
        "state_layout": "joint_pos(6), gripper(1), ee_pos(3)",
        "action_layout": "delta_ee_xyz(3, m/step), gripper(1, 0 open .. 1 closed, in-between allowed)",
    }
    meta = dict(state=states, action=actions,
                episode_index=np.concatenate(ep_idx), frame_index=np.concatenate(fr_idx),
                episode_ends=np.array(ends), names=np.array(names), instructions=np.array(instr),
                episode_cube_xy=np.array(cube_xy, np.float32),
                stats=json.dumps(stats))
    if folder:
        mm.flush()
        np.savez(os.path.join(args.out, "meta.npz"), **meta)
    else:
        np.savez(args.out, images=np.stack(images), **meta)
    print(f"wrote {args.out}: {len(names)} episodes, {n} frames, image size {args.size}")


def load_cache(path):
    """-> dict of arrays (images memory-mapped for folder caches)."""
    if path.endswith(".npz"):
        raw = np.load(path)
        return {k: raw[k] for k in raw.files}
    raw = np.load(os.path.join(path, "meta.npz"))
    d = {k: raw[k] for k in raw.files}
    d["images"] = np.load(os.path.join(path, "images.npy"), mmap_mode="r")
    return d


if __name__ == "__main__":
    main()
