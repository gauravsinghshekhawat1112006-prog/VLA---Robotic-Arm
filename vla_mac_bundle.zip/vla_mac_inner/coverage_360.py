"""coverage_360.py - where the demo cubes start, by region and distance (same bins as eval_region.py).
  python coverage_360.py --data ../dataset360/episodes --out ../dataset360/validation"""
import argparse, glob, json, os
import h5py, numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from eval_region import REGIONS, DISTS


def region_of(angle_deg):
    a = angle_deg % 360
    return "front" if (a < 45 or a >= 315) else "left" if a < 135 else "back" if a < 225 else "right"


def dist_of(r):
    for k, (r0, r1) in DISTS.items():
        if r0 <= r < r1 or (k == "far" and r >= r0):
            return k
    return "near"


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", required=True, action="append")
    p.add_argument("--out", required=True)
    a = p.parse_args()
    os.makedirs(a.out, exist_ok=True)
    rows = []
    for f in [f for d in a.data for f in sorted(glob.glob(os.path.join(d, "episode_*.hdf5")))]:
        with h5py.File(f, "r") as h:
            c = h["observations/cube_pos"][0]
            q = h.attrs.get("cube_init_quat", np.array([1, 0, 0, 0]))
            rows.append(dict(file=os.path.relpath(f), x=float(c[0]), y=float(c[1]), steps=int(h.attrs["num_steps"]),
                             yaw=float(np.degrees(2 * np.arctan2(q[3], q[0]))), success=bool(h.attrs["success"])))
    for r in rows:
        r["angle"] = float(np.degrees(np.arctan2(r["y"], r["x"])) % 360)
        r["radius"] = float(np.hypot(r["x"], r["y"]))
        r["region"], r["dist"] = region_of(r["angle"]), dist_of(r["radius"])
    table = {g: {d: sum(r["region"] == g and r["dist"] == d for r in rows) for d in DISTS} for g in REGIONS}
    summ = dict(episodes=len(rows), successful=sum(r["success"] for r in rows), steps_total=sum(r["steps"] for r in rows),
                by_region={g: sum(table[g].values()) for g in REGIONS}, by_region_and_distance=table,
                straight_behind_170_190=sum(170 <= r["angle"] <= 190 for r in rows),
                radius_range=[round(min(r["radius"] for r in rows), 3), round(max(r["radius"] for r in rows), 3)],
                yaw_range_deg=[round(min(r["yaw"] for r in rows), 1), round(max(r["yaw"] for r in rows), 1)])
    json.dump(summ, open(os.path.join(a.out, "coverage_360.json"), "w"), indent=2)
    fig, ax = plt.subplots(1, 2, figsize=(11, 5))
    ax[0].scatter([-r["y"] for r in rows], [r["x"] for r in rows], s=8)
    ax[0].plot(0, 0, "ks", ms=9)
    for rr in (0.33, 0.44, 0.55, 0.66):
        ax[0].add_patch(plt.Circle((0, 0), rr, fill=False, ls=":", color="gray"))
    ax[0].set(aspect="equal", xlim=(-0.75, 0.75), ylim=(-0.75, 0.75), title=f"{len(rows)} demo cube starts (front up)",
              xlabel="<- robot left   right ->", ylabel="<- behind   front ->")
    ax[1].hist([r["angle"] for r in rows], bins=36, range=(0, 360))
    ax[1].set(xlabel="cube angle around base (deg, 0 = front, 90 = left)", ylabel="demos", title="Angle coverage")
    fig.tight_layout()
    fig.savefig(os.path.join(a.out, "coverage_360.png"), dpi=110)
    print(json.dumps(summ, indent=2))


if __name__ == "__main__":
    main()
