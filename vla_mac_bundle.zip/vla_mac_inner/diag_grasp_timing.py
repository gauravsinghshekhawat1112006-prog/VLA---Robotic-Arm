"""diag_grasp_timing.py - replay chosen eval_radial spots and log, per step, the gripper command,
finger opening, fingertip height above the cube centre and horizontal offset to the cube.
  python diag_grasp_timing.py --ckpt CKPT --ids 32 48 --gripper continuous --out ../diag/timing_x.json"""
import argparse, json
import mujoco, numpy as np, torch
import record_episodes as R
from convert_dataset import preprocess_image
from eval_policy import run_episode
from eval_radial import test_spots, MAX_SEC, STABLE_HOLD
from policy import PickupPolicy, TemporalEnsembler

p = argparse.ArgumentParser()
p.add_argument("--ckpt", required=True); p.add_argument("--ids", type=int, nargs="+", required=True)
p.add_argument("--gripper", default="continuous"); p.add_argument("--seed", type=int, default=9700)
p.add_argument("--per-band", type=int, default=32); p.add_argument("--cube-mm", type=float, nargs=2, default=(60., 60.))
p.add_argument("--out", required=True)
a = p.parse_args()
torch.set_num_threads(1)
policy, ck = PickupPolicy.load(a.ckpt); size = ck["stats"]["image_size"]
sim = R.Sim("vla_scene_v3.xml"); ren = mujoco.Renderer(sim.model, height=R.IMAGE_H, width=R.IMAGE_W)
spots = {s["id"]: s for s in test_spots(a.seed, a.per_band, a.cube_mm)}
out = {}
for i in a.ids:
    sp = spots[i]; ens = TemporalEnsembler(policy.chunk); log = []
    def ctrl(obs, t):
        imgs = np.stack([preprocess_image(obs["ws"], size), preprocess_image(obs["wr"], size)])
        d, g = policy.predict_chunk(imgs, obs["state"]); dl, gg = ens.step(t, d, g)
        cmd = float(gg > 0.5) if a.gripper == "binary" else float(np.clip(gg, 0, 1))
        ee, c = sim.ee_pos(), sim.cube_pos()
        log.append(dict(t=t, cmd=round(cmd, 3), raw=round(float(gg), 3), open=round(float(sim.gripper_opening()), 3),
                        dz=round(float(ee[2] - c[2]), 4), dxy=round(float(np.hypot(*(ee[:2] - c[:2]))), 4),
                        vz=round(float(dl[2]), 4)))
        return dl, cmd
    res, _ = run_episode(sim, ren, (sp["x"], sp["y"]), ctrl, size, yaw=sp["yaw"], max_steps=MAX_SEC * R.CONTROL_HZ,
                         half=sp["half"], extra_hold=STABLE_HOLD)
    out[i] = dict(outcome=res["outcome"], held=res["held_to_end"], log=log)
    k = next((r["t"] for r in log if r["cmd"] > 0.1), None)
    print(i, res["outcome"], "| first cmd>0.1 at", k, ":", {kk: log[k][kk] for kk in ("dz", "dxy", "open")} if k is not None else "",
          "| at cmd>0.6:", next(({kk: r[kk] for kk in ("t", "dz", "dxy", "open")} for r in log if r["cmd"] > 0.6), None), flush=True)
json.dump(out, open(a.out, "w"))
