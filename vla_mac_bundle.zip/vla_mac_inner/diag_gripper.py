"""diag_gripper.py - how does the Robotiq 2F-85 respond to in-between commands?
(1) free air: command 0..255 -> steady finger opening;  (2) closing on the cube: command -> grip / lift."""
import json, sys
import mujoco, numpy as np
import record_episodes as R

sim = R.Sim(sys.argv[1] if len(sys.argv) > 1 else "vla_scene_v3.xml")
m, d = sim.model, sim.data
lpad, rpad = m.body("gripper_left_pad").id, m.body("gripper_right_pad").id


def finger_gap():
    return float(np.linalg.norm(d.xpos[lpad] - d.xpos[rpad]))


def settle(cmd, steps=40):
    for _ in range(steps):
        sim.apply_action(np.zeros(3), False)            # holds arm, sets gripper to open...
        d.ctrl[sim.grip_act] = cmd                      # ...then override with the raw command
        sim.grip_cmd = cmd


out = {"free": [], "on_cube": []}
for cmd in np.linspace(0, 255, 18):
    sim.reset(np.random.default_rng(0))
    q = sim.cube_qpos
    d.qpos[q:q + 3] = [0.0, 0.6, R.CUBE_Z]              # cube far away
    mujoco.mj_forward(m, d)
    sim.target_pos = sim.ee_pos()
    sim.grip_cmd = cmd
    for _ in range(40):
        sim.target_pos = sim.target_pos
        sim.apply_action_cmd = None
        # one control step with this gripper command
        sim.target_pos += 0
        dt = m.opt.timestep
        for _ in range(sim.substeps):
            sim.ik_step(dt)
            d.ctrl[sim.arm_act] = sim.joint_targets
            d.ctrl[sim.grip_act] = cmd
            mujoco.mj_step(m, d)
    out["free"].append(dict(cmd=round(float(cmd), 1), opening=round(sim.gripper_opening(), 3), gap_mm=round(finger_gap() * 1000, 1)))
print("FREE AIR  cmd -> opening(0..1), pad gap")
for r in out["free"]:
    print(r)
json.dump(out, open("../diag/gripper_response.json", "w"), indent=1)


def step(cmd, delta=np.zeros(3)):
    sim.target_pos += delta
    for _ in range(sim.substeps):
        sim.ik_step(m.opt.timestep)
        d.ctrl[sim.arm_act] = sim.joint_targets
        d.ctrl[sim.grip_act] = cmd
        mujoco.mj_step(m, d)


print("\nON CUBE (6 cm): close with command c, then lift 15 cm")
for half in (0.03, 0.025, 0.02):
    gid = m.geom("cube_geom").id
    m.geom_size[gid] = [half] * 3
    for cmd in (100, 120, 140, 150, 160, 170, 180, 200, 230, 255):
        sim.reset(np.random.default_rng(0))
        q = sim.cube_qpos
        ee = sim.ee_pos()
        d.qpos[q:q + 7] = [ee[0], ee[1], half, 1, 0, 0, 0]
        mujoco.mj_forward(m, d)
        sim.target_pos = ee.copy()
        z0 = sim.cube_pos()[2]
        for _ in range(60):                               # go down, open
            step(0, np.array([0, 0, np.clip(half - sim.target_pos[2], -0.006, 0.006)]))
        for _ in range(20):
            step(cmd)
        opening_closed = sim.gripper_opening()
        for _ in range(40):
            step(cmd, np.array([0, 0, 0.004]))
        for _ in range(20):
            step(cmd)
        lift = sim.cube_pos()[2] - z0
        held = lift > 0.10 and np.linalg.norm(sim.cube_pos() - sim.ee_pos()) < 0.05
        out["on_cube"].append(dict(cube_mm=round(half * 2000), cmd=cmd, opening=round(opening_closed, 3),
                                   lift_cm=round(lift * 100, 1), held=bool(held)))
        print(out["on_cube"][-1])
    m.geom_size[gid] = [0.03] * 3
json.dump(out, open("../diag/gripper_response.json", "w"), indent=1)
