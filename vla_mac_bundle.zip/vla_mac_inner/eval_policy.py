"""
eval_policy.py  -  run the trained policy in the same MuJoCo scene, no human input.

  python eval_policy.py --ckpt ../training/run1/checkpoints/best.pt --episodes 30 --seed 777 \
                        --train-data ../dataset/episodes --out ../evaluation/run1

For each fresh episode the cube is placed at a new random spot (seed different from
all training seeds). The policy sees only the two camera images and the robot state;
the cube position is used ONLY by the scorer below, never by the policy.
The scripted pilot (which does use the true cube position) is run on the same cube
positions as a reference.

Writes results.json, episodes.csv, success_map.png and mp4 videos.
"""
import argparse
import csv
import glob
import json
import os

import h5py
import imageio
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mujoco
import numpy as np
import torch

import record_episodes as R
from convert_dataset import preprocess_image, state_vector
from policy import PickupPolicy, TemporalEnsembler

MAX_STEPS = 15 * R.CONTROL_HZ          # same 15 s limit as the scripted recorder
EXTRA_HOLD = 5                          # keep holding a bit after success, like the recorder


def floor_contact(sim, floor_id, robot_geoms):
    d = sim.data
    for k in range(d.ncon):
        g1, g2 = d.contact[k].geom1, d.contact[k].geom2
        if (g1 == floor_id and g2 in robot_geoms) or (g2 == floor_id and g1 in robot_geoms):
            return True
    return False


def run_episode(sim, renderer, cube_xy, controller, size, record_video=False, yaw=0.0, max_steps=MAX_STEPS,
                half=None, trace=None, extra_hold=EXTRA_HOLD):
    """controller(obs_dict, t) -> (delta, grip) with grip a bool or 0..1. Returns metrics (+ frames).
    yaw = cube rotation about z in radians; half = cube half-size in m (None = scene default);
    trace = a dict that receives per-step gripper command and measured opening."""
    rng = np.random.default_rng(0)
    sim.reset(rng)
    # place the cube at the requested spot
    q = sim.cube_qpos
    z = R.CUBE_Z
    if half is not None:
        sim.set_cube_half(half)
        z = half
    sim.data.qpos[q:q + 7] = [cube_xy[0], cube_xy[1], z, np.cos(yaw / 2), 0, 0, np.sin(yaw / 2)]
    mujoco.mj_forward(sim.model, sim.data)
    sim.target_pos = sim.ee_pos()
    sim.cube_start_z = sim.cube_pos()[2]
    start = sim.cube_pos()

    floor_id = sim.model.geom("floor").id
    base = sim.model.body("base").id
    robot_geoms = {g for g in range(sim.model.ngeom)
                   if sim.model.body_rootid[sim.model.geom_bodyid[g]] == base}

    frames, hold, success_step = [], 0, None
    min_dist, lifted_any, closed_near, floor_hit, knocked = 9.0, False, False, False, False
    t = 0
    while t < max_steps:
        ws = wr = None
        if renderer is not None:
            renderer.update_scene(sim.data, camera="workspace_camera")
            ws = renderer.render().copy()
            renderer.update_scene(sim.data, camera="wrist_camera")
            wr = renderer.render().copy()
            if record_video:
                frames.append(np.concatenate([ws, wr], 1))
        obs = dict(ws=ws, wr=wr, state=state_vector(sim.data.qpos[sim.qpos_addr], sim.gripper_opening(),
                                                    sim.ee_pos()))
        delta, grip = controller(obs, t)
        sim.apply_action(np.asarray(delta, float), grip)
        t += 1
        if trace is not None:
            trace.setdefault("cmd", []).append(float(grip))
            trace.setdefault("opening", []).append(sim.gripper_opening())

        cube, ee = sim.cube_pos(), sim.ee_pos()
        dist = np.linalg.norm(cube - ee)
        min_dist = min(min_dist, dist)
        closed_near |= float(grip) > 0.5 and dist < 0.04
        lifted_any |= cube[2] > start[2] + R.LIFT_HEIGHT
        floor_hit |= floor_contact(sim, floor_id, robot_geoms)
        if cube[2] < start[2] + 0.01 and np.linalg.norm(cube[:2] - start[:2]) > 0.02:
            knocked = True
        hold = hold + 1 if sim.is_lifted() else 0
        if hold >= R.SUCCESS_HOLD_STEPS and success_step is None:
            success_step = t
        if success_step is not None and hold >= R.SUCCESS_HOLD_STEPS + extra_hold:
            break

    success = success_step is not None and sim.is_lifted()
    if success:
        outcome = "success"
    elif lifted_any:
        outcome = "lifted then dropped"
    elif min_dist > 0.03:
        outcome = "missed reach"
    elif closed_near:
        outcome = "grasp failure"
    else:
        outcome = "reached, never closed"
    res = dict(cube_x=round(float(cube_xy[0]), 3), cube_y=round(float(cube_xy[1]), 3), success=success,
               success_step=success_step, held_to_end=bool(success_step is not None and hold >= R.SUCCESS_HOLD_STEPS + extra_hold),
               lifted=lifted_any, outcome=outcome, steps=t, seconds=t / R.CONTROL_HZ,
               min_dist_cm=round(min_dist * 100, 1), floor_contact=floor_hit, cube_knocked=knocked)
    return res, frames


def write_video(path, frames):
    imageio.mimsave(path, frames, fps=R.CONTROL_HZ, codec="libx264", quality=7, macro_block_size=8)


def summarize(rows):
    n = len(rows)
    return {
        "episodes": n,
        "pickup_success_rate": sum(r["success"] for r in rows) / n,
        "lift_rate": sum(r["lifted"] for r in rows) / n,
        "outcomes": {o: sum(r["outcome"] == o for r in rows) for o in sorted({r["outcome"] for r in rows})},
        "floor_contact_episodes": sum(r["floor_contact"] for r in rows),
        "cube_knocked_episodes": sum(r["cube_knocked"] for r in rows),
        "avg_steps": float(np.mean([r["steps"] for r in rows])),
        "avg_seconds_successful": float(np.mean([r["seconds"] for r in rows if r["success"]]))
        if any(r["success"] for r in rows) else None,
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", default="vla_scene_v2.xml")
    p.add_argument("--ckpt", required=True)
    p.add_argument("--episodes", type=int, default=30)
    p.add_argument("--seed", type=int, default=777)
    p.add_argument("--train-data", default=None, help="folder of training HDF5s, to check positions are new")
    p.add_argument("--out", required=True)
    p.add_argument("--videos", type=int, default=3, help="videos per outcome type (success / failure)")
    p.add_argument("--no-baseline", action="store_true")
    p.add_argument("--blind", action="store_true",
                   help="ablation: give the policy black images, to test that it relies on the cameras")
    p.add_argument("--threads", type=int, default=os.cpu_count())
    args = p.parse_args()
    os.makedirs(os.path.join(args.out, "videos"), exist_ok=True)
    torch.set_num_threads(args.threads)

    policy, ck = PickupPolicy.load(args.ckpt)
    size = ck["stats"]["image_size"]
    sim = R.Sim(args.model)
    renderer = mujoco.Renderer(sim.model, height=R.IMAGE_H, width=R.IMAGE_W)

    rng = np.random.default_rng(args.seed)
    cubes = np.stack([rng.uniform(*R.CUBE_X, args.episodes), rng.uniform(*R.CUBE_Y, args.episodes)], 1)

    nearest = None
    if args.train_data:
        train_xy = []
        for f in sorted(glob.glob(os.path.join(args.train_data, "episode_*.hdf5"))):
            with h5py.File(f, "r") as h:
                train_xy.append(h["observations/cube_pos"][0, :2])
        train_xy = np.array(train_xy)
        nearest = [float(np.linalg.norm(train_xy - c, axis=1).min()) for c in cubes]

    rows, vids = [], {"success": 0, "failure": 0}
    for i, c in enumerate(cubes):
        ens = TemporalEnsembler(policy.chunk)

        def policy_ctrl(obs, t):
            imgs = np.stack([preprocess_image(obs["ws"], size), preprocess_image(obs["wr"], size)])
            if args.blind:
                imgs = np.zeros_like(imgs)
            deltas, grips = policy.predict_chunk(imgs, obs["state"])
            d, g = ens.step(t, deltas, grips)
            return d, g > 0.5

        res, frames = run_episode(sim, renderer, c, policy_ctrl, size, record_video=True)
        res["episode"] = i
        if nearest:
            res["nearest_train_start_cm"] = round(nearest[i] * 100, 1)
        kind = "success" if res["success"] else "failure"
        if vids[kind] < args.videos:
            write_video(os.path.join(args.out, "videos", f"policy_ep{i:02d}_{res['outcome'].replace(' ', '_')}.mp4"),
                        frames)
            vids[kind] += 1
        rows.append(res)
        print(f"policy ep {i:2d} cube ({c[0]:.3f}, {c[1]:+.3f}): {res['outcome']:22s} {res['steps']} steps", flush=True)

    base_rows = []
    if not args.no_baseline:
        for i, c in enumerate(cubes):
            pilot = R.AutoPilot(np.random.default_rng(10_000 + i))
            first = {"done": False}

            def pilot_ctrl(obs, t):
                if not first["done"]:
                    pilot.reset(sim)
                    first["done"] = True
                d, g, _, _ = pilot.read(sim, 1.0 / R.CONTROL_HZ)
                return d, g

            res, _ = run_episode(sim, None, c, pilot_ctrl, size)
            res["episode"] = i
            base_rows.append(res)
            print(f"pilot  ep {i:2d}: {res['outcome']}", flush=True)

    results = {"checkpoint": args.ckpt, "checkpoint_epoch": ck["extra"].get("epoch"), "seed": args.seed,
               "policy": summarize(rows), "scripted_pilot_reference": summarize(base_rows) if base_rows else None,
               "min_distance_to_any_training_start_cm": round(min(nearest) * 100, 2) if nearest else None,
               "note": "policy input = 2 camera images + joint_pos + gripper + ee_pos; the scripted pilot "
                       "reads the true cube position, so it is a privileged reference, not a fair rival."}
    json.dump(results, open(os.path.join(args.out, "results.json"), "w"), indent=2)
    with open(os.path.join(args.out, "episodes.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)

    fig, ax = plt.subplots(figsize=(5.5, 4.5))
    xy = np.array([[r["cube_y"], r["cube_x"]] for r in rows])
    ok = np.array([r["success"] for r in rows])
    ax.scatter(xy[ok, 0], xy[ok, 1], c="tab:green", label="pickup success", s=40)
    ax.scatter(xy[~ok, 0], xy[~ok, 1], c="tab:red", marker="x", label="failure", s=40)
    ax.add_patch(plt.Rectangle((R.CUBE_Y[0], R.CUBE_X[0]), np.ptp(R.CUBE_Y), np.ptp(R.CUBE_X),
                               fill=False, ls="--", color="gray"))
    ax.set(xlabel="cube y (m)", ylabel="cube x (m)", title="Policy result by cube start position")
    ax.set_aspect("equal")
    ax.legend(loc="upper right", fontsize=8)
    fig.tight_layout()
    fig.savefig(os.path.join(args.out, "success_map.png"), dpi=110)
    print(json.dumps(results, indent=2))
    renderer.close()


if __name__ == "__main__":
    main()
