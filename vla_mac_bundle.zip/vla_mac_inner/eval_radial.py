"""
eval_radial.py  -  test a policy in radial bands around the robot (inner / middle / outer),
with the same fixed test spots for every model, so before/after numbers are comparable.

Bands (distance of the cube from the robot base):
  inner 0.20-0.33 m   (closer than 0.20 m the gripper hits the robot's own base, see diag_controller.py)
  middle 0.33-0.50 m
  outer 0.50-0.66 m
Each band gets the same number of spots, spread evenly over 8 directions (45 deg sectors).
The cube is turned randomly by +-30 deg; --cube-mm sets its size range (default 60 mm = old scene).

Per try: reset, gripper open, cube placed, policy runs alone (cameras + robot state only) for up
to 25 s. Scored from physics:
  pickup         cube lifted >= 5 cm and held between the fingers for 0.5 s
  grasp-and-lift pickup AND still held 2 s later (stable grasp)
Also records the gripper command and the measured finger opening at every step.

  python eval_radial.py --ckpt CKPT --out DIR --gripper continuous --part 0 --parts 4   (x4 in parallel)
  python eval_radial.py --out DIR --summarize
--gripper binary  = threshold the model's gripper output at 0.5 (how the old model was always run)
--gripper continuous = send the model's gripper value (0..1) to the gripper as it is
"""
import argparse
import glob
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mujoco
import numpy as np
import torch

import record_episodes as R
from convert_dataset import preprocess_image
from eval_policy import run_episode, write_video
from policy import PickupPolicy, TemporalEnsembler

BANDS = {"inner": (0.20, 0.33), "middle": (0.33, 0.50), "outer": (0.50, 0.66)}
MAX_SEC = 25
STABLE_HOLD = 40            # extra steps (2 s) the cube must stay up after a pickup


def test_spots(seed, per_band, cube_mm):
    rng = np.random.default_rng(seed)
    out = []
    for band, (r0, r1) in BANDS.items():
        for i in range(per_band):
            sector = i % 8
            a = np.radians(sector * 45 + rng.uniform(0, 45))
            r = np.sqrt(rng.uniform(r0 ** 2, r1 ** 2))
            out.append(dict(band=band, x=r * np.cos(a), y=r * np.sin(a), yaw=np.radians(rng.uniform(-30, 30)),
                            half=rng.uniform(*cube_mm) / 2000.0))
    for i, o in enumerate(out):
        o.update(id=i, angle_deg=round(float(np.degrees(np.arctan2(o["y"], o["x"])) % 360), 1),
                 radius=round(float(np.hypot(o["x"], o["y"])), 3))
    return out


def run_part(args):
    torch.set_num_threads(args.threads)
    policy, ck = PickupPolicy.load(args.ckpt)
    size = ck["stats"]["image_size"]
    sim = R.Sim(args.model)
    renderer = mujoco.Renderer(sim.model, height=R.IMAGE_H, width=R.IMAGE_W)
    spots = [s for s in test_spots(args.seed, args.per_band, args.cube_mm) if s["band"] in args.bands][args.part::args.parts]
    os.makedirs(os.path.join(args.out, "videos"), exist_ok=True)
    os.makedirs(os.path.join(args.out, "traces"), exist_ok=True)
    part_file = os.path.join(args.out, f"part{args.part}.json")
    rows = json.load(open(part_file)) if os.path.exists(part_file) else []   # resume after an interruption
    done = {r["id"] for r in rows}
    nvid = {}
    for r in rows:
        if "video" in r:
            nvid[(r["band"], r["grasp_lift"])] = nvid.get((r["band"], r["grasp_lift"]), 0) + 1
    for sp in spots:
        if sp["id"] in done:
            continue
        ens = TemporalEnsembler(policy.chunk)

        def ctrl(obs, t):
            imgs = np.stack([preprocess_image(obs["ws"], size), preprocess_image(obs["wr"], size)])
            d, g = policy.predict_chunk(imgs, obs["state"])
            a, gg = ens.step(t, d, g)
            return a, (float(gg > 0.5) if args.gripper == "binary" else float(np.clip(gg, 0, 1)))

        trace = {}
        res, frames = run_episode(sim, renderer, (sp["x"], sp["y"]), ctrl, size, record_video=True, yaw=sp["yaw"],
                                  max_steps=MAX_SEC * R.CONTROL_HZ, half=sp["half"], trace=trace,
                                  extra_hold=STABLE_HOLD)
        res.update(id=sp["id"], band=sp["band"], angle_deg=sp["angle_deg"], radius=sp["radius"],
                   yaw_deg=round(float(np.degrees(sp["yaw"])), 1), cube_mm=round(sp["half"] * 2000, 1),
                   pickup=res["success_step"] is not None, grasp_lift=res["held_to_end"])
        np.savez_compressed(os.path.join(args.out, "traces", f"id{sp['id']:03d}.npz"),
                            cmd=np.array(trace["cmd"], np.float32), opening=np.array(trace["opening"], np.float32))
        key = (sp["band"], res["grasp_lift"])
        if nvid.get(key, 0) < args.videos:
            v = f"{sp['band']}_id{sp['id']:03d}_{'ok' if res['grasp_lift'] else res['outcome'].replace(' ', '_')}.mp4"
            write_video(os.path.join(args.out, "videos", v), frames)
            res["video"] = "videos/" + v
            nvid[key] = nvid.get(key, 0) + 1
        rows.append(res)
        print(f"[{sp['id']:3d}] {sp['band']:6s} ang {sp['angle_deg']:5.1f} r {sp['radius']:.2f} {res['cube_mm']:.0f}mm: "
              f"{'GRASP+LIFT' if res['grasp_lift'] else res['outcome']:20s} {res['steps']} steps", flush=True)
        with open(os.path.join(args.out, f"part{args.part}.json"), "w") as f:
            json.dump(rows, f, indent=1, default=lambda o: o.item() if hasattr(o, "item") else str(o))
    renderer.close()


def load_rows(d):
    rows = sum([json.load(open(f)) for f in sorted(glob.glob(os.path.join(d, "part*.json")))], [])
    return sorted(rows, key=lambda r: r["id"])


def band_stats(rows):
    n = len(rows)
    if not n:
        return {"attempts": 0}
    fails = [r for r in rows if not r["grasp_lift"]]
    causes = {}
    for r in fails:
        c = "dropped after lift" if r["pickup"] else r["outcome"]
        causes[c] = causes.get(c, 0) + 1
    return {"attempts": n, "pickup": sum(r["pickup"] for r in rows), "pickup_rate": round(sum(r["pickup"] for r in rows) / n, 3),
            "grasp_lift": sum(r["grasp_lift"] for r in rows), "grasp_lift_rate": round(sum(r["grasp_lift"] for r in rows) / n, 3),
            "failure_rate": round(len(fails) / n, 3), "failure_causes": causes,
            "floor_contact": sum(r["floor_contact"] for r in rows), "cube_knocked": sum(r["cube_knocked"] for r in rows)}


def gripper_stats(d, rows):
    """Command vs measured opening while holding (from 5 steps after pickup) and during approach."""
    hold_cmd, hold_open, uniq = [], [], []
    for r in rows:
        tr = np.load(os.path.join(d, "traces", f"id{r['id']:03d}.npz"))
        uniq.append(len(np.unique(np.round(tr["cmd"], 2))))
        if r["pickup"]:
            k = r["success_step"]
            hold_cmd += tr["cmd"][k:].tolist()
            hold_open += tr["opening"][k:].tolist()
    return {"distinct_command_values_per_episode_median": float(np.median(uniq)),
            "holding_command_mean": round(float(np.mean(hold_cmd)), 3) if hold_cmd else None,
            "holding_opening_mean": round(float(np.mean(hold_open)), 3) if hold_open else None}


def summarize(args):
    rows = load_rows(args.out)
    present = [b for b in BANDS if any(r["band"] == b for r in rows)]
    s = {"spots": len(rows), "overall": band_stats(rows), "by_band": {b: band_stats([r for r in rows if r["band"] == b]) for b in present},
         "gripper": {b: gripper_stats(args.out, [r for r in rows if r["band"] == b]) for b in present}}
    cfg = os.path.join(args.out, "eval_config.json")
    if os.path.exists(cfg):
        s["config"] = json.load(open(cfg))
    json.dump(s, open(os.path.join(args.out, "results.json"), "w"), indent=2)
    print(json.dumps({k: v for k, v in s.items() if k != "config"}, indent=1))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", default="vla_scene_v3.xml")
    p.add_argument("--ckpt", default=None)
    p.add_argument("--out", required=True)
    p.add_argument("--seed", type=int, default=9700)
    p.add_argument("--per-band", type=int, default=32)
    p.add_argument("--cube-mm", type=float, nargs=2, default=(60.0, 60.0))
    p.add_argument("--gripper", default="continuous", choices=["binary", "continuous"])
    p.add_argument("--bands", nargs="+", default=list(BANDS), choices=list(BANDS), help="test only these bands (same spots)")
    p.add_argument("--videos", type=int, default=3, help="videos kept per band for successes and for failures")
    p.add_argument("--part", type=int, default=0)
    p.add_argument("--parts", type=int, default=1)
    p.add_argument("--threads", type=int, default=1)
    p.add_argument("--summarize", action="store_true")
    args = p.parse_args()
    os.makedirs(args.out, exist_ok=True)
    if args.summarize:
        summarize(args)
    else:
        json.dump(vars(args), open(os.path.join(args.out, "eval_config.json"), "w"), indent=1)
        run_part(args)


if __name__ == "__main__":
    main()
