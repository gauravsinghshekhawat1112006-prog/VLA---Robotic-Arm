"""
eval_region.py  -  360-degree evaluation of a policy, split by region around the robot.

Regions (angle of the cube seen from the base, 0 deg = robot front = +x, counter-clockwise):
  front -45..45, left 45..135, back 135..225, right 225..315
Distances: near 0.33-0.44 m, mid 0.44-0.55 m, far 0.55-0.66 m.
Plus "rear_center": cubes straight behind the robot (180 +- 10 deg) at all distances.

Every test position is new (fixed eval seed, never used for training), the cube is turned
by a random +-30 deg, the gripper starts open at the normal start pose, and the policy
only sees the 2 camera images + robot state. The true cube position is used only to score.

  # run 4 parts in parallel, then combine
  python eval_region.py --ckpt CKPT --out ../evaluation/run2 --part 0 --parts 4 &   (... parts 1..3)
  python eval_region.py --ckpt CKPT --out ../evaluation/run2 --summarize --train-data ../dataset360/episodes
"""
import argparse
import glob
import json
import os

import h5py
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mujoco
import numpy as np
import torch

import record_episodes as R
from convert_dataset import preprocess_image
from eval_policy import run_episode, write_video
from policy import PickupPolicy, TemporalEnsembler

REGIONS = {"front": 0, "left": 90, "back": 180, "right": 270}
DISTS = {"near": (0.33, 0.44), "mid": (0.44, 0.55), "far": (0.55, 0.66)}
MAX_SEC = 25


def test_positions(seed, per_cell, rear_center):
    rng = np.random.default_rng(seed)
    out = []
    for reg, c in REGIONS.items():
        for dn, (r0, r1) in DISTS.items():
            for _ in range(per_cell):
                a = np.radians(c + rng.uniform(-45, 45))
                r = np.sqrt(rng.uniform(r0 ** 2, r1 ** 2))
                out.append(dict(region=reg, dist=dn, x=r * np.cos(a), y=r * np.sin(a),
                                yaw=np.radians(rng.uniform(-30, 30))))
    for i in range(rear_center):
        a = np.radians(180 + rng.uniform(-10, 10))
        dn = list(DISTS)[i % 3]
        r = np.sqrt(rng.uniform(DISTS[dn][0] ** 2, DISTS[dn][1] ** 2))
        out.append(dict(region="rear_center", dist=dn, x=r * np.cos(a), y=r * np.sin(a),
                        yaw=np.radians(rng.uniform(-30, 30))))
    for i, o in enumerate(out):
        o.update(id=i, angle_deg=round(float(np.degrees(np.arctan2(o["y"], o["x"])) % 360), 1),
                 radius=round(float(np.hypot(o["x"], o["y"])), 3))
    return out


def run_part(args):
    torch.set_num_threads(args.threads)
    policy, ck = PickupPolicy.load(args.ckpt)
    size = ck["stats"]["image_size"]
    sim = R.Sim(args.model)
    renderer = mujoco.Renderer(sim.model, height=R.IMAGE_H, width=R.IMAGE_W)
    tests = test_positions(args.seed, args.per_cell, args.rear_center)[args.part::args.parts]
    os.makedirs(os.path.join(args.out, "videos"), exist_ok=True)
    rows = []
    for tp in tests:
        instr = R.INSTRUCTIONS[tp["id"] % len(R.INSTRUCTIONS)]     # stored only; policy ignores text
        ens = TemporalEnsembler(policy.chunk)

        def ctrl(obs, t):
            imgs = np.stack([preprocess_image(obs["ws"], size), preprocess_image(obs["wr"], size)])
            d, g = policy.predict_chunk(imgs, obs["state"])
            a, gg = ens.step(t, d, g)
            return a, gg > 0.5

        res, frames = run_episode(sim, renderer, (tp["x"], tp["y"]), ctrl, size, record_video=True,
                                  yaw=tp["yaw"], max_steps=MAX_SEC * R.CONTROL_HZ)
        res.update(id=tp["id"], region=tp["region"], dist=tp["dist"], angle_deg=tp["angle_deg"],
                   radius=tp["radius"], yaw_deg=round(float(np.degrees(tp["yaw"])), 1), instruction=instr)
        vname = f"{tp['region']}_{tp['dist']}_id{tp['id']:03d}_{res['outcome'].replace(' ', '_')}.mp4"
        write_video(os.path.join(args.out, "videos", vname), frames)
        res["video"] = "videos/" + vname
        rows.append(res)
        print(f"[{tp['id']:3d}] {tp['region']:11s} {tp['dist']:4s} ang {tp['angle_deg']:5.1f} r {tp['radius']:.2f}: "
              f"{res['outcome']:20s} {res['steps']} steps", flush=True)
        if not args.no_baseline:          # privileged scripted pilot on the same spot (physics only)
            pilot = R.AutoPilot(np.random.default_rng(10_000 + tp["id"]))
            st = {"first": True}

            def pctrl(obs, t):
                if st["first"]:
                    pilot.reset(sim)
                    st["first"] = False
                d, g, _, _ = pilot.read(sim, 1.0 / R.CONTROL_HZ)
                return d, g
            b, _ = run_episode(sim, None, (tp["x"], tp["y"]), pctrl, size, yaw=tp["yaw"],
                               max_steps=MAX_SEC * R.CONTROL_HZ)
            res["pilot_success"] = b["success"]
        with open(os.path.join(args.out, f"part{args.part}.json"), "w") as f:
            json.dump(rows, f, indent=1, default=lambda o: o.item() if hasattr(o, "item") else str(o))
    renderer.close()


def rate(rows):
    n = len(rows)
    k = sum(r["success"] for r in rows)
    return {"n": n, "success": k, "rate": round(k / n, 3) if n else None}


def summarize(args):
    rows = sum([json.load(open(f)) for f in sorted(glob.glob(os.path.join(args.out, "part*.json")))], [])
    rows.sort(key=lambda r: r["id"])
    if args.train_data:
        xy = []
        for f in sorted(glob.glob(os.path.join(args.train_data, "episode_*.hdf5"))):
            with h5py.File(f, "r") as h:
                xy.append(h["observations/cube_pos"][0, :2])
        xy = np.array(xy)
        for r in rows:
            r["nearest_train_start_cm"] = round(float(np.linalg.norm(xy - [r["cube_x"], r["cube_y"]], axis=1).min()) * 100, 1)
    regions = list(REGIONS) + ["rear_center"]
    summary = {
        "checkpoint": json.load(open(os.path.join(args.out, "eval_config.json")))["ckpt"]
        if os.path.exists(os.path.join(args.out, "eval_config.json")) else None,
        "overall": rate(rows),
        "overall_4_regions": rate([r for r in rows if r["region"] != "rear_center"]),
        "by_region": {g: rate([r for r in rows if r["region"] == g]) for g in regions},
        "by_region_and_distance": {g: {d: rate([r for r in rows if r["region"] == g and r["dist"] == d])
                                       for d in DISTS} for g in REGIONS},
        "outcomes": {o: sum(r["outcome"] == o for r in rows) for o in sorted({r["outcome"] for r in rows})},
        "floor_contact_episodes": sum(r["floor_contact"] for r in rows),
        "cube_knocked_episodes": sum(r["cube_knocked"] for r in rows),
        "avg_seconds_successful": round(float(np.mean([r["seconds"] for r in rows if r["success"]])), 2)
        if any(r["success"] for r in rows) else None,
        "scripted_pilot_reference": rate([{"success": r["pilot_success"]} for r in rows if "pilot_success" in r]),
        "min_distance_to_training_start_cm": min(r["nearest_train_start_cm"] for r in rows) if args.train_data else None,
        "note": "policy input = 2 camera images + joint_pos + gripper + ee_pos. Pilot = privileged reference.",
    }
    json.dump(summary, open(os.path.join(args.out, "results.json"), "w"), indent=2)
    keys = ["id", "region", "dist", "angle_deg", "radius", "yaw_deg", "cube_x", "cube_y", "success", "outcome",
            "steps", "seconds", "min_dist_cm", "floor_contact", "cube_knocked", "pilot_success",
            "nearest_train_start_cm", "instruction", "video"]
    import csv
    with open(os.path.join(args.out, "episodes.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)

    fig, ax = plt.subplots(figsize=(6, 6))
    ok = np.array([r["success"] for r in rows])
    # plot in the overhead-camera layout: robot front (+x) up, robot left (+y) to the left
    px, py = -np.array([r["cube_y"] for r in rows]), np.array([r["cube_x"] for r in rows])
    ax.scatter(px[ok], py[ok], c="tab:green", s=36, label="pickup success")
    ax.scatter(px[~ok], py[~ok], c="tab:red", marker="x", s=44, label="failure")
    for rr in (0.33, 0.44, 0.55, 0.66):
        ax.add_patch(plt.Circle((0, 0), rr, fill=False, ls=":", color="gray"))
    for a in (45, 135, 225, 315):
        ax.plot([0, -0.7 * np.sin(np.radians(a))], [0, 0.7 * np.cos(np.radians(a))], ":", color="gray")
    ax.plot(0, 0, "ks", ms=10)
    for g, c in REGIONS.items():
        ax.text(-0.76 * np.sin(np.radians(c)), 0.76 * np.cos(np.radians(c)), f"{g}\n{summary['by_region'][g]['success']}/{summary['by_region'][g]['n']}",
                ha="center", va="center", fontsize=9)
    ax.set(xlim=(-0.9, 0.9), ylim=(-0.9, 0.9), aspect="equal", xlabel="<- robot left (y)   right ->",
           ylabel="<- behind (x)   front ->", title=f"Pickup by cube position: {summary['overall']['success']}/{summary['overall']['n']}")
    ax.legend(loc="lower right", fontsize=8)
    fig.tight_layout()
    fig.savefig(os.path.join(args.out, "success_map_360.png"), dpi=110)
    print(json.dumps(summary, indent=2))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", default="vla_scene_v3.xml")
    p.add_argument("--ckpt", default=None)
    p.add_argument("--out", required=True)
    p.add_argument("--seed", type=int, default=9001)
    p.add_argument("--per-cell", type=int, default=5, help="positions per region x distance cell (12 cells)")
    p.add_argument("--rear-center", type=int, default=9, help="extra positions straight behind the robot")
    p.add_argument("--part", type=int, default=0)
    p.add_argument("--parts", type=int, default=1)
    p.add_argument("--threads", type=int, default=1)
    p.add_argument("--no-baseline", action="store_true")
    p.add_argument("--summarize", action="store_true")
    p.add_argument("--train-data", default=None)
    args = p.parse_args()
    os.makedirs(args.out, exist_ok=True)
    if args.summarize:
        summarize(args)
    else:
        json.dump(vars(args), open(os.path.join(args.out, "eval_config.json"), "w"), indent=1)
        run_part(args)


if __name__ == "__main__":
    main()
