"""
inspect_episode.py  -  quick check of a recorded episode.

  python inspect_episode.py episodes/episode_000000.hdf5

Prints every array with its shape, the episode info (instruction, success,
fps), and saves <episode>_preview.png: 6 frames from the workspace camera
(top row) and the wrist camera (bottom row).
"""
import sys

import h5py
import numpy as np
from PIL import Image

path = sys.argv[1]
with h5py.File(path, "r") as h:
    h.visititems(lambda name, obj: print(f"{name:35s} {getattr(obj, 'shape', '')}"))
    for k, v in h.attrs.items():
        print(f"{k}: {v}")

    cube = h["observations/cube_pos"][:]
    print(f"cube height: start {cube[0, 2]:.3f} m, end {cube[-1, 2]:.3f} m")

    T = len(cube)
    idx = np.linspace(0, T - 1, 6).astype(int)
    top = np.concatenate([h["observations/images/workspace"][i] for i in idx], axis=1)
    bottom = np.concatenate([h["observations/images/wrist"][i] for i in idx], axis=1)

out = path.replace(".hdf5", "_preview.png")
Image.fromarray(np.concatenate([top, bottom], axis=0)).save(out)
print("preview saved to", out)
