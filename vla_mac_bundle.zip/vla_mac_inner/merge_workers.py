"""
merge_workers.py  -  merge the per-worker folders from parallel collection into
one folder numbered episode_000000.hdf5 ... in a fixed order (worker, then index).

  python merge_workers.py --raw ../raw --out ../dataset/episodes [--limit 100]

Writes <out>/../provenance.csv mapping each final file to its worker file.
"""
import argparse
import csv
import glob
import os
import shutil


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--raw", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--limit", type=int, default=None)
    p.add_argument("--link", action="store_true", help="hard-link instead of copy (saves disk space)")
    args = p.parse_args()
    os.makedirs(args.out, exist_ok=True)
    src = []
    for w in sorted(glob.glob(os.path.join(args.raw, "w*"))):
        if os.path.isdir(w):
            src += sorted(glob.glob(os.path.join(w, "episode_*.hdf5")))
    if args.limit:
        src = src[:args.limit]
    rows = []
    for i, s in enumerate(src):
        dst = os.path.join(args.out, f"episode_{i:06d}.hdf5")
        if args.link:
            os.link(s, dst)
        else:
            shutil.copy2(s, dst)
        rows.append({"file": os.path.basename(dst), "source": os.path.relpath(s, args.raw)})
    with open(os.path.join(os.path.dirname(os.path.abspath(args.out)), "provenance.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["file", "source"])
        w.writeheader()
        w.writerows(rows)
    print(f"merged {len(rows)} episodes into {args.out}")


if __name__ == "__main__":
    main()
