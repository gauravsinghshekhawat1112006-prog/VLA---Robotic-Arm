"""
play_policy.py  -  watch the trained policy pick up the cube, live in the MuJoCo viewer.

  Mac:      mjpython play_policy.py
  Windows:  python play_policy.py

Options:
  --ckpt PATH      model to use (default: training/run3_360/checkpoints/best.pt, the 360-degree model)
  --model XML      scene (default: vla_scene_v3.xml, overhead camera; the 360 models need it)
  --x X --y Y      put the cube at this spot instead of a random one (metres)
  --yaw DEG        turn the cube by this many degrees (with --x/--y)
  --spawn ring     random spots all around the robot (default); "rect" = old front area only
  --episodes N     stop after N tries (default: run until you close the window)

The OLD front-only model still works with:
  mjpython play_policy.py --ckpt training/run1/checkpoints/best.pt --model vla_scene_v2.xml --spawn rect

Keys (click the viewer window first):
  N       new try with the cube at a new random spot
  P       pause / resume

The 360 model was trained on cubes 0.33..0.66 m from the base, any direction, turned
up to +-30 deg. Try e.g. behind the robot: --x -0.45 --y 0.0. You can also
double-click the cube and Ctrl + right-drag it to push it while the arm works.
"""
import argparse
import time

import mujoco
import mujoco.viewer
import numpy as np
import torch

import record_episodes as R
from convert_dataset import preprocess_image, state_vector
from policy import PickupPolicy, TemporalEnsembler

MAX_STEPS = 25 * R.CONTROL_HZ          # trips to the back take up to ~17 s


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", default="vla_scene_v3.xml")
    p.add_argument("--ckpt", default="training/run3_360/checkpoints/best.pt")
    p.add_argument("--x", type=float, default=None)
    p.add_argument("--y", type=float, default=None)
    p.add_argument("--yaw", type=float, default=0.0)
    p.add_argument("--spawn", default="ring", choices=["ring", "rect"])
    p.add_argument("--episodes", type=int, default=0)
    p.add_argument("--seed", type=int, default=None)
    p.add_argument("--gripper", default="continuous", choices=["continuous", "binary"],
                   help="continuous = send the model's 0..1 gripper value as is; binary = old on/off (threshold 0.5)")
    p.add_argument("--inner-frac", type=float, default=0.5, help="share of random spots closer than 0.33 m (0.20-0.33)")
    args = p.parse_args()

    policy, ck = PickupPolicy.load(args.ckpt)
    size = ck["stats"]["image_size"]
    sim = R.Sim(args.model, spawn=args.spawn, yaw_deg=30 if args.spawn == "ring" else 0,
                inner_frac=args.inner_frac if args.spawn == "ring" else 0.0)
    renderer = mujoco.Renderer(sim.model, height=R.IMAGE_H, width=R.IMAGE_W)
    rng = np.random.default_rng(args.seed)
    keys = {"new": False, "pause": False}

    def on_key(k):
        if k == ord("N"):
            keys["new"] = True
        elif k == ord("P"):
            keys["pause"] = not keys["pause"]

    def new_try():
        sim.reset(rng)
        if args.x is not None and args.y is not None:
            q = sim.cube_qpos
            a = np.radians(args.yaw)
            sim.data.qpos[q:q + 7] = [args.x, args.y, R.CUBE_Z, np.cos(a / 2), 0, 0, np.sin(a / 2)]
            mujoco.mj_forward(sim.model, sim.data)
            sim.cube_start_z = sim.cube_pos()[2]
        c = sim.cube_pos()
        ang = np.degrees(np.arctan2(c[1], c[0])) % 360
        where = "front" if (ang < 45 or ang >= 315) else "left" if ang < 135 else "BEHIND" if ang < 225 else "right"
        print(f"\nnew try: cube at x={c[0]:.3f} y={c[1]:+.3f}  ({where}, {np.hypot(c[0], c[1]):.2f} m from base)")
        return TemporalEnsembler(policy.chunk), 0, 0

    tries, wins = 0, 0
    viewer = mujoco.viewer.launch_passive(sim.model, sim.data, key_callback=on_key)
    viewer.cam.distance, viewer.cam.azimuth, viewer.cam.elevation = 2.2, 135, -40
    viewer.cam.lookat[:] = [0.0, 0.0, 0.1]
    ens, t, hold = new_try()
    dt = 1.0 / R.CONTROL_HZ
    print("Keys: N = new random cube, P = pause. Close the window to quit.")

    while viewer.is_running():
        tick = time.perf_counter()
        if keys["new"]:
            keys["new"] = False
            ens, t, hold = new_try()
        if keys["pause"]:
            viewer.sync()
            time.sleep(dt)
            continue

        # the policy sees only the two camera images + the robot's own state
        renderer.update_scene(sim.data, camera="workspace_camera")
        ws = renderer.render()
        renderer.update_scene(sim.data, camera="wrist_camera")
        wr = renderer.render()
        imgs = np.stack([preprocess_image(ws, size), preprocess_image(wr, size)])
        state = state_vector(sim.data.qpos[sim.qpos_addr], sim.gripper_opening(), sim.ee_pos())
        with torch.no_grad():
            deltas, grips = policy.predict_chunk(imgs, state)
        delta, grip = ens.step(t, deltas, grips)
        with viewer.lock():
            sim.apply_action(delta, float(grip > 0.5) if args.gripper == "binary" else float(np.clip(grip, 0, 1)))
        t += 1
        hold = hold + 1 if sim.is_lifted() else 0

        done = None
        if hold == R.SUCCESS_HOLD_STEPS + 20:            # held it for 1.5 s
            done = "SUCCESS - cube picked up"
        elif t >= MAX_STEPS:
            done = "gave up after 25 s (no pickup)"
        if done:
            tries += 1
            wins += done.startswith("SUCCESS")
            print(f"{done}  ({t / R.CONTROL_HZ:.1f} s)   score so far: {wins}/{tries}")
            if args.episodes and tries >= args.episodes:
                break
            time.sleep(1.0)
            ens, t, hold = new_try()

        viewer.sync()
        left = dt - (time.perf_counter() - tick)
        if left > 0:
            time.sleep(left)

    viewer.close()
    renderer.close()
    print(f"\nFinal score: {wins}/{tries}")


if __name__ == "__main__":
    main()
