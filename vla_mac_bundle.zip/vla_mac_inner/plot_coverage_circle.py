"""plot_coverage_circle.py - top-down circle around the robot: where the training demos were
recorded (left) and where the new model was tested, picked or missed (right)."""
import glob, json, sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

INK, MUTED, GRID, BG = "#0b0b0b", "#52514e", "#d9d8d3", "#fcfcfb"
OLD, NEW, OK, BAD = "#2a78d6", "#eb6834", "#1baf7a", "#d03b3b"
meta, evals, out = sys.argv[1], sys.argv[2:4], sys.argv[4]

m = np.load(meta)
xy, names = m["episode_cube_xy"], m["names"]
new = np.array(["dataset_graded" in n for n in names])
rows = sum([json.load(open(f)) for d in evals for f in glob.glob(d + "/part*.json")], [])


def disc(ax, title):
    ax.set_theta_zero_location("N")          # 0 deg = in front of the robot, drawn at the top
    ax.set_rlim(0, 0.70)
    ax.set_rticks([0.20, 0.33, 0.50, 0.66])
    ax.set_yticklabels(["0.20 m", "0.33", "0.50", "0.66"], color=MUTED, fontsize=8)
    ax.set_rlabel_position(112)
    ax.set_xticks(np.radians([0, 90, 180, 270]))
    ax.set_xticklabels(["front", "left", "behind", "right"], color=INK)
    ax.grid(color=GRID, lw=0.8)
    ax.set_facecolor(BG)
    th = np.linspace(0, 2 * np.pi, 200)
    ax.fill_between(th, 0, 0.20, color="#c9c8c2", zorder=0)                 # arm hits its own base
    for (a, b), c in (((0.20, 0.33), "#fbe9df"), ((0.33, 0.50), "#ffffff"), ((0.50, 0.66), "#e7f0fb")):
        ax.fill_between(th, a, b, color=c, zorder=0)
    for r0, r1, lab in ((0.20, 0.33, "inner"), (0.33, 0.50, "middle"), (0.50, 0.66, "outer")):
        ax.text(np.radians(-45), (r0 + r1) / 2, lab, color=INK, fontsize=8, ha="center", va="center",
                bbox=dict(boxstyle="round,pad=0.2", fc=BG, ec="none", alpha=0.85), zorder=6)
    ax.text(0, 0, "robot", ha="center", va="center", fontsize=8, color=INK)
    ax.set_title(title, color=INK, pad=18, fontsize=12)


def polar(p):
    return np.arctan2(p[:, 1], p[:, 0]), np.hypot(p[:, 0], p[:, 1])


fig = plt.figure(figsize=(13, 7.4), facecolor=BG)
ax = fig.add_subplot(121, projection="polar")
disc(ax, "Where the training demos were recorded")
for sel, col, lab in ((~new, OLD, f"original demos ({(~new).sum()}, 60 mm cube)"),
                      (new, NEW, f"new demos ({new.sum()}, 45-60 mm cubes)")):
    t, r = polar(xy[sel])
    ax.scatter(t, r, s=10, color=col, alpha=0.75, lw=0, label=lab, zorder=3)
ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.07), frameon=False, fontsize=9, ncol=2)

ax = fig.add_subplot(122, projection="polar")
p = np.array([[np.radians(x["angle_deg"]), x["radius"]] for x in rows])
ok = np.array([x["grasp_lift"] for x in rows])
disc(ax, f"Where the new model was tested ({len(rows)} spots)")
ax.scatter(p[ok, 0], p[ok, 1], s=34, color=OK, edgecolor=BG, lw=1, label=f"picked up and held ({ok.sum()})", zorder=3)
ax.scatter(p[~ok, 0], p[~ok, 1], s=60, marker="X", color=BAD, edgecolor=BG, lw=0.8,
           label=f"missed ({(~ok).sum()})", zorder=4)
ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.06), frameon=False, fontsize=9, ncol=2)
fig.text(0.5, 0.012, "Grey centre = closer than 0.20 m: the arm hits its own base there, so nothing can be picked up.",
         ha="center", color=MUTED, fontsize=9)
fig.tight_layout(rect=(0, 0.05, 1, 0.97))
fig.savefig(out, dpi=130, facecolor=BG)
print("saved", out)
