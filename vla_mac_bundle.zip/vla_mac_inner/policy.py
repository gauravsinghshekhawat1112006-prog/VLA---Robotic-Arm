"""
policy.py  -  the pickup policy network (used by train_policy.py and eval_policy.py).

A small vision-based behaviour-cloning policy with ACT-style action chunking:
  * each camera image -> its own small CNN -> spatial-softmax keypoints
    (x, y "where is the interesting thing" per feature map, good for locating the cube)
  * robot state (joint angles, gripper opening, gripper position) -> MLP
  * everything concatenated -> MLP -> the next K actions
    (K x 3 normalised EE deltas + K gripper logits)
At run time overlapping chunks are blended with ACT's temporal ensembling.

Inputs are only camera pixels + robot proprioception. The cube position is never given.
"""
import json

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


class SpatialSoftmax(nn.Module):
    def forward(self, x):
        b, c, h, w = x.shape
        sm = F.softmax(x.flatten(2), dim=-1).view(b, c, h, w)
        ys = torch.linspace(-1, 1, h, device=x.device)
        xs = torch.linspace(-1, 1, w, device=x.device)
        ex = (sm.sum(2) * xs).sum(-1)
        ey = (sm.sum(3) * ys).sum(-1)
        return torch.cat([ex, ey], 1)                     # (b, 2c)


def conv_encoder(c=64):
    def block(i, o, s):
        return nn.Sequential(nn.Conv2d(i, o, 3, s, 1), nn.GroupNorm(8, o), nn.ReLU(inplace=True))
    return nn.Sequential(block(3, 32, 2), block(32, 32, 1), block(32, 64, 2), block(64, 64, 1),
                         block(64, c, 2), nn.Conv2d(c, c, 3, 1, 1), SpatialSoftmax())


class PickupPolicy(nn.Module):

    def __init__(self, stats, chunk=10, hidden=512):
        super().__init__()
        self.chunk = chunk
        self.config = {"chunk": chunk, "hidden": hidden}
        self.stats = stats
        for k in ["state_mean", "state_std", "action_mean", "action_std"]:
            self.register_buffer(k, torch.tensor(stats[k], dtype=torch.float32))
        self.enc = nn.ModuleList([conv_encoder(), conv_encoder()])   # workspace, wrist
        self.state_mlp = nn.Sequential(nn.Linear(10, 128), nn.ReLU(), nn.Linear(128, 128), nn.ReLU())
        self.head = nn.Sequential(
            nn.Linear(2 * 128 + 128, hidden), nn.ReLU(), nn.Dropout(0.1),
            nn.Linear(hidden, hidden), nn.ReLU(),
            nn.Linear(hidden, chunk * 4))

    def forward(self, images, state):
        """images: (B, 2, H, W, 3) uint8 tensor; state: (B, 10) raw.
        Returns normalised deltas (B, K, 3) and gripper logits (B, K)."""
        x = images.float().div(255.0).permute(0, 1, 4, 2, 3)          # B,2,3,H,W
        feats = [enc(x[:, i]) for i, enc in enumerate(self.enc)]
        s = self.state_mlp((state - self.state_mean) / self.state_std)
        out = self.head(torch.cat(feats + [s], 1)).view(-1, self.chunk, 4)
        return out[..., :3], out[..., 3]

    @torch.no_grad()
    def predict_chunk(self, images, state):
        """Single observation (numpy) -> K actions in metres + gripper probability."""
        img = torch.from_numpy(images[None])
        st = torch.from_numpy(state[None].astype(np.float32))
        d, g = self(img, st)
        delta = d[0] * self.action_std + self.action_mean
        return delta.numpy(), torch.sigmoid(g[0]).numpy()

    def save(self, path, extra=None):
        torch.save({"state_dict": self.state_dict(), "stats": self.stats, "config": self.config,
                    "extra": extra or {}}, path)

    @staticmethod
    def load(path):
        ck = torch.load(path, map_location="cpu", weights_only=False)
        m = PickupPolicy(ck["stats"], **ck["config"])
        m.load_state_dict(ck["state_dict"])
        m.eval()
        return m, ck


class TemporalEnsembler:
    """ACT temporal ensembling: every step a new K-step chunk is predicted; the
    action executed now is a weighted average of all chunks' predictions for
    this step (older predictions weighted by exp(-m * age))."""

    def __init__(self, chunk, m=0.1):
        self.chunk, self.m = chunk, m
        self.buf = []                                  # (start_step, deltas, grips)

    def reset(self):
        self.buf = []

    def step(self, t, deltas, grips):
        self.buf.append((t, deltas, grips))
        self.buf = [b for b in self.buf if t - b[0] < self.chunk]
        ds, gs, ws = [], [], []
        for start, d, g in self.buf:
            ds.append(d[t - start])
            gs.append(g[t - start])
            ws.append(np.exp(-self.m * (len(ws))))       # oldest first gets weight 1
        ws = np.array(ws) / np.sum(ws)
        return (np.array(ds) * ws[:, None]).sum(0), float((np.array(gs) * ws).sum())
