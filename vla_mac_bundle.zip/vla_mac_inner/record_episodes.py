"""
record_episodes.py  -  record VLA training episodes in the UR5e + Robotiq scene.

This is ares_ik_control.py (gamepad -> red target dot -> damped IK) plus:
  * a FIXED control/record rate (20 Hz) instead of "as fast as the loop runs"
  * offscreen rendering of workspace_camera + wrist_camera with mujoco.Renderer
  * one HDF5 file per episode (images, robot state, actions, language instruction)
  * gamepad buttons to save / discard / reset
  * automatic success detection (cube lifted and held between the fingers)
  * an optional scripted "auto pilot" that records demos with no gamepad

Gamepad (Xbox layout as seen by pygame on Windows):
  LEFT STICK X/Y   move red target dot in X / Y
  RIGHT STICK Y    move red target dot in Z
  A  (button 0)    close gripper
  B  (button 1)    open gripper
  Y  (button 3)    SAVE episode, then reset
  X  (button 2)    DISCARD episode, then reset
  START (button 7) quit

Recording starts on your first stick/button input after a reset, so there
are no idle frames at the start of an episode.

Usage:
  python record_episodes.py                       # gamepad teleop
  python record_episodes.py --auto 50             # 50 scripted demos, with viewer
  python record_episodes.py --auto 50 --headless  # 50 scripted demos, no window
  python record_episodes.py --model path\\to\\vla_scene_v2.xml --out episodes

Needs:  pip install mujoco pygame h5py numpy
"""

import argparse
import json
import os
import time

import h5py
import mujoco
import mujoco.viewer
import numpy as np


# =========================================================
# SETTINGS
# =========================================================

# vla_scene_v2.xml = your vla_scene.xml with a fixed workspace camera and a
# wrist camera mounted on the gripper (see the notes doc). Put it in the same
# folder as vla_scene.xml so it finds the assets/ folder.
MODEL_PATH = r"C:\mujoco_menagerie\universal_robots_ur5e\vla_scene_v2.xml"
OUT_DIR = "episodes"

# One language instruction per task. A random variant is stored per episode so
# the model learns that different wordings mean the same thing.
INSTRUCTIONS = [
    "pick up the red cube",
    "grab the red cube and lift it",
    "lift the red block",
]

CONTROL_HZ = 20                 # actions + camera frames per second
IMAGE_W, IMAGE_H = 224, 224     # most VLAs resize to 224x224 anyway
MAX_EPISODE_SEC = 60            # safety limit, episode is discarded after this

TARGET_SPEED = 0.12             # m/s of the red dot at full stick
IK_GAIN = 5.0
DAMPING = 0.06
MAX_JOINT_SPEED = 0.65          # rad/s
DEADZONE = 0.06

GRIPPER_OPEN = 0.0
GRIPPER_CLOSED = 255.0

# Same pose as ares_ik_control.py, but shoulder pan = pi.
# The base body is rotated 180 deg (quat="0 0 0 -1"), so with pan = 0 the
# gripper sits at x = -0.6 while the cube spawns at x = +0.25..0.55, on the
# other side of the robot. pan = pi puts the gripper above the cube area.
START_Q = np.array([np.pi, -1.20, 1.65, -2.02, -1.57, 0.0])

# Cube spawn area (cube half-size is 0.03, so z = 0.03 rests on the floor)
CUBE_X = (0.35, 0.60)
CUBE_Y = (-0.25, 0.25)
CUBE_Z = 0.03
# 360-degree workspace ("--spawn ring"): cube anywhere on a ring around the base.
# Radii come from the reachability map in diag_controller.py (IK + collisions).
RING_R = (0.33, 0.66)
REACH_RADIUS = 0.70             # the red dot is kept inside this horizontal radius
# Inner area close to the base. diag_controller.py: the pilot picks cleanly at 0.20 m and
# 0.22 m in every direction, but at 0.18 m and closer the gripper hits the robot's own base.
INNER_R = (0.20, 0.33)

# Success = cube centre this far above its start height, near the fingers,
# for this many consecutive control steps
LIFT_HEIGHT = 0.05
SUCCESS_HOLD_STEPS = 10

# Button numbers
BTN_CLOSE, BTN_OPEN, BTN_DISCARD, BTN_SAVE, BTN_QUIT = 0, 1, 2, 3, 7


# =========================================================
# SIMULATION WRAPPER
# =========================================================

ARM_JOINTS = ["shoulder_pan_joint", "shoulder_lift_joint", "elbow_joint",
              "wrist_1_joint", "wrist_2_joint", "wrist_3_joint"]
ARM_ACTUATORS = ["shoulder_pan", "shoulder_lift", "elbow",
                 "wrist_1", "wrist_2", "wrist_3"]


def sample_cube_xy(rng, spawn="rect", angles=(-180.0, 180.0), inner_frac=0.0):
    if spawn == "ring":
        # uniform over the ring's AREA (not radius); angles = (from, to) in degrees,
        # 0 = robot front, 90 = robot left. Used to add extra demos for weak regions.
        # inner_frac > 0: that share of spots goes to the inner area INNER_R (denser there),
        # the rest stays on the normal ring RING_R, so the outer area keeps its demos.
        r0, r1 = INNER_R if rng.uniform() < inner_frac else RING_R
        r = np.sqrt(rng.uniform(r0 ** 2, r1 ** 2))
        a = np.radians(rng.uniform(*angles))
        return r * np.cos(a), r * np.sin(a)
    return rng.uniform(*CUBE_X), rng.uniform(*CUBE_Y)


def wrap_angle(a):
    return (a + np.pi) % (2 * np.pi) - np.pi


class Sim:

    def __init__(self, model_path, spawn="rect", yaw_deg=0.0, angles=(-180.0, 180.0), inner_frac=0.0,
                 size_mm=(60.0, 60.0)):
        self.spawn = spawn              # "rect" = original front area, "ring" = all around
        self.inner_frac = inner_frac    # ring only: share of cubes in the inner area
        self.size_mm = size_mm          # cube edge length range (the scene's cube is 60 mm)
        self.angles = angles            # ring only: limit the cube direction (degrees)
        self.yaw_deg = yaw_deg          # cube turned by up to +-yaw_deg around z (the gripper
                                        # cannot rotate, so keep this <= 30: 45 fails often)
        self.model = mujoco.MjModel.from_xml_path(model_path)
        self.data = mujoco.MjData(self.model)
        m = self.model

        joint_ids = [m.joint(n).id for n in ARM_JOINTS]
        self.qpos_addr = np.array([m.jnt_qposadr[j] for j in joint_ids])
        self.dof_addr = np.array([m.jnt_dofadr[j] for j in joint_ids])
        self.joint_low = m.jnt_range[joint_ids, 0].copy()
        self.joint_high = m.jnt_range[joint_ids, 1].copy()
        self.arm_act = np.array([m.actuator(n).id for n in ARM_ACTUATORS])
        self.grip_act = m.actuator("gripper_fingers_actuator").id
        self.grip_qpos = m.jnt_qposadr[m.joint("gripper_right_driver_joint").id]
        self.pinch = m.site("gripper_pinch").id

        # The cube has a free joint. NOTE: it is the FIRST joint in the file,
        # so data.qpos[0:7] is the cube, NOT the arm. Always use the addresses.
        self.cube_body = m.body("cube").id
        cube_joint = m.body_jntadr[self.cube_body]
        self.cube_qpos = m.jnt_qposadr[cube_joint]
        self.cube_dof = m.jnt_dofadr[cube_joint]
        self.cube_geom = m.geom("cube_geom").id
        self.cube_half = float(m.geom_size[self.cube_geom][0])

        self.substeps = max(1, int(round(1.0 / CONTROL_HZ / m.opt.timestep)))

    # ----------------------------------------------------- reset
    def reset(self, rng):
        m, d = self.model, self.data
        mujoco.mj_resetData(m, d)          # also resets the gripper linkage

        d.qpos[self.qpos_addr] = START_Q
        x, y = sample_cube_xy(rng, self.spawn, self.angles, self.inner_frac)
        yaw = np.radians(rng.uniform(-self.yaw_deg, self.yaw_deg)) if self.yaw_deg else 0.0
        lo, hi = self.size_mm
        self.set_cube_half((rng.uniform(lo, hi) if hi > lo else lo) / 2000.0)
        z = self.cube_half                 # resting on the floor
        d.qpos[self.cube_qpos:self.cube_qpos + 7] = [x, y, z, np.cos(yaw / 2), 0, 0, np.sin(yaw / 2)]

        d.ctrl[self.arm_act] = START_Q
        d.ctrl[self.grip_act] = GRIPPER_OPEN
        mujoco.mj_forward(m, d)

        self.joint_targets = START_Q.copy()
        self.target_pos = d.site_xpos[self.pinch].copy()
        self.target_rot = d.site_xmat[self.pinch].reshape(3, 3).copy()
        self.grip_cmd = GRIPPER_OPEN
        self.cube_start_z = d.xpos[self.cube_body][2]

    def set_cube_half(self, half):
        """Change the cube's size (half edge, metres). Collision and rendering both use it."""
        self.cube_half = float(half)
        self.model.geom_size[self.cube_geom] = [half, half, half]

    def cube_yaw(self):
        q = self.data.qpos[self.cube_qpos + 3:self.cube_qpos + 7]
        return float(2 * np.arctan2(q[3], q[0]))

    def hold_start_pose(self):
        """Before the first input: keep the arm frozen, don't advance physics."""
        d = self.data
        d.qpos[self.qpos_addr] = START_Q
        d.qvel[self.dof_addr] = 0.0
        mujoco.mj_forward(self.model, d)

    # ----------------------------------------------------- IK (same as ares_ik_control.py)
    def ik_step(self, dt):
        m, d = self.model, self.data
        cur_pos = d.site_xpos[self.pinch]
        cur_rot = d.site_xmat[self.pinch].reshape(3, 3)

        pos_err = self.target_pos - cur_pos
        rot_err = 0.5 * sum(np.cross(cur_rot[:, i], self.target_rot[:, i]) for i in range(3))

        lin_vel = IK_GAIN * pos_err
        n = np.linalg.norm(lin_vel)
        if n > 0.20:
            lin_vel *= 0.20 / n
        twist = np.concatenate([lin_vel, 2.0 * rot_err])

        jacp = np.zeros((3, m.nv))
        jacr = np.zeros((3, m.nv))
        mujoco.mj_jacSite(m, d, jacp, jacr, self.pinch)
        J = np.vstack([jacp[:, self.dof_addr], jacr[:, self.dof_addr]])

        dq = J.T @ np.linalg.solve(J @ J.T + DAMPING ** 2 * np.eye(6), twist)
        dq = np.clip(dq, -MAX_JOINT_SPEED, MAX_JOINT_SPEED)
        self.joint_targets = np.clip(self.joint_targets + dq * dt,
                                     self.joint_low, self.joint_high)

    # ----------------------------------------------------- one control step
    def apply_action(self, delta_xyz, grip_closed):
        """Move the red dot by delta_xyz (metres), set gripper, run physics
        for one control period (substeps x timestep)."""
        self.target_pos += delta_xyz
        # keep the dot inside a cylinder around the base. (v2 clipped y to +-0.55,
        # which made cubes further out to the sides unreachable.)
        r = np.hypot(*self.target_pos[:2])
        if r > REACH_RADIUS:
            self.target_pos[:2] *= REACH_RADIUS / r
        self.target_pos[2] = np.clip(self.target_pos[2], 0.01, 0.85)
        # gripper: 0 = fully open .. 1 = fully closed. A bool still works (True = 1.0).
        # The Robotiq model is a position servo on the finger tendon, so in-between values
        # give in-between finger positions (checked in diag_gripper.py).
        self.grip_cmd = GRIPPER_CLOSED * float(np.clip(grip_closed, 0.0, 1.0))

        dt = self.model.opt.timestep
        for _ in range(self.substeps):
            self.ik_step(dt)
            self.data.ctrl[self.arm_act] = self.joint_targets
            self.data.ctrl[self.grip_act] = self.grip_cmd
            mujoco.mj_step(self.model, self.data)

    # ----------------------------------------------------- readings
    def ee_pos(self):
        return self.data.site_xpos[self.pinch].copy()

    def cube_pos(self):
        return self.data.xpos[self.cube_body].copy()

    def gripper_opening(self):
        """0 = fully open, 1 = fully closed (driver joint range is 0..0.8)."""
        return float(np.clip(self.data.qpos[self.grip_qpos] / 0.8, 0.0, 1.0))

    def is_lifted(self):
        cube = self.cube_pos()
        near = np.linalg.norm(cube - self.ee_pos()) < 0.05
        return near and cube[2] > self.cube_start_z + LIFT_HEIGHT


# =========================================================
# EPISODE BUFFER + HDF5 WRITER
# =========================================================

class Episode:

    def __init__(self, instruction, cube_init, cube_quat=(1, 0, 0, 0), cube_half=0.03):
        self.cube_half = float(cube_half)
        self.cube_quat = np.asarray(cube_quat, float)
        self.instruction = instruction
        self.cube_init = cube_init
        self.frames = {k: [] for k in [
            "workspace", "wrist", "joint_pos", "joint_vel", "gripper",
            "ee_pos", "cube_pos", "action", "action_ee_target", "action_joint"]}
        self.success = False

    def __len__(self):
        return len(self.frames["action"])

    def add(self, **kw):
        for k, v in kw.items():
            self.frames[k].append(v)

    def save(self, out_dir):
        os.makedirs(out_dir, exist_ok=True)
        idx = len([f for f in os.listdir(out_dir) if f.endswith(".hdf5")])
        path = os.path.join(out_dir, f"episode_{idx:06d}.hdf5")
        while os.path.exists(path):
            idx += 1
            path = os.path.join(out_dir, f"episode_{idx:06d}.hdf5")

        f = self.frames
        with h5py.File(path, "w") as h:
            h.attrs["language_instruction"] = self.instruction
            h.attrs["success"] = self.success
            h.attrs["fps"] = CONTROL_HZ
            h.attrs["num_steps"] = len(self)
            h.attrs["cube_init_pos"] = self.cube_init
            h.attrs["cube_init_quat"] = self.cube_quat
            h.attrs["cube_half_size"] = self.cube_half
            h.attrs["action_space"] = "delta_ee_xyz(3, metres per step) + gripper(1, 0=open 1=close)"

            obs = h.create_group("observations")
            img = obs.create_group("images")
            # gzip keeps files small; chunk = one frame so random access is fast
            for cam in ["workspace", "wrist"]:
                arr = np.stack(f[cam]).astype(np.uint8)
                img.create_dataset(cam, data=arr, compression="gzip", compression_opts=4,
                                   chunks=(1,) + arr.shape[1:])
            obs.create_dataset("joint_pos", data=np.array(f["joint_pos"], np.float32))
            obs.create_dataset("joint_vel", data=np.array(f["joint_vel"], np.float32))
            obs.create_dataset("gripper", data=np.array(f["gripper"], np.float32)[:, None])
            obs.create_dataset("ee_pos", data=np.array(f["ee_pos"], np.float32))
            # Privileged info: NOT for the policy input, only for debugging/analysis
            obs.create_dataset("cube_pos", data=np.array(f["cube_pos"], np.float32))

            h.create_dataset("action", data=np.array(f["action"], np.float32))
            h.create_dataset("action_ee_target", data=np.array(f["action_ee_target"], np.float32))
            h.create_dataset("action_joint", data=np.array(f["action_joint"], np.float32))
        return path


# =========================================================
# INPUT SOURCES: gamepad or scripted auto pilot
# Both return (delta_xyz, grip_closed, event) once per control step.
# event is None, "save", "discard" or "quit".
# =========================================================

class GamepadInput:

    def __init__(self):
        import pygame
        self.pg = pygame
        pygame.init()
        pygame.joystick.init()
        if pygame.joystick.get_count() == 0:
            raise RuntimeError("Controller not detected!")
        self.js = pygame.joystick.Joystick(0)
        self.js.init()
        print("Controller:", self.js.get_name())
        self.prev = {}
        self.grip_closed = False

    def _pressed(self, b):
        """True only on the frame the button goes down (edge detect)."""
        now = bool(self.js.get_button(b))
        was = self.prev.get(b, False)
        self.prev[b] = now
        return now and not was

    def reset(self, sim):
        self.grip_closed = False

    def read(self, sim, dt):
        self.pg.event.pump()
        lx, ly, ry = (self.js.get_axis(i) for i in (0, 1, 3))
        lx, ly, ry = (0.0 if abs(v) < DEADZONE else v for v in (lx, ly, ry))

        if self.js.get_button(BTN_CLOSE):
            self.grip_closed = True
        if self.js.get_button(BTN_OPEN):
            self.grip_closed = False

        event = None
        if self._pressed(BTN_SAVE):
            event = "save"
        elif self._pressed(BTN_DISCARD):
            event = "discard"
        elif self._pressed(BTN_QUIT):
            event = "quit"

        moving = lx != 0 or ly != 0 or ry != 0 or self.js.get_button(BTN_CLOSE)
        delta = np.array([lx, -ly, -ry]) * TARGET_SPEED * dt
        return delta, self.grip_closed, event, moving


class AutoPilot:
    """Scripted expert: go above cube -> descend -> close -> lift.
    Moves the red dot exactly like a stick would (same speed limit), so the
    recorded actions look like gamepad actions. Small random noise + random
    speeds make the demos less identical."""

    ARC_RADIUS = (0.42, 0.60)       # swing around the base at this distance
    ARC_LEAD = np.radians(25)       # aim this far ahead along the arc
    ARC_DONE = np.radians(30)       # within this angle of the cube: go straight
    ARC_SPEEDUP = 1.2               # swing a bit faster than full stick (rear trips are long)

    def __init__(self, rng, gripper="binary"):
        self.rng = rng
        self.gripper = gripper          # "binary" = old 0/1 gripper, "smooth" = graded commands

    # --- graded gripper (gripper="smooth"). Measured in diag_gripper.py: in free air the
    # finger opening follows the command linearly; fingers touch a cube of width w (mm)
    # at about command (86 + 3.0 * (60 - w)) / 255. The width that matters is the cube's
    # extent across the fingers, which grows when the cube is turned.
    def _grip_plan(self, sim):
        a = abs(sim.cube_yaw()) % (np.pi / 2)
        extent_mm = 2000 * sim.cube_half * (np.cos(a) + np.sin(a))
        def contact(w_mm):
            return (86 + 3.0 * (60 - w_mm)) / 255
        self.pre = float(np.clip(contact(extent_mm) - 0.25, 0.0, 1.0))   # ~20 mm wider than the cube
        # closing turns the cube square to the fingers, so squeeze relative to its real width
        self.secure = float(np.clip(contact(2000 * sim.cube_half) + 0.32, 0.0, 1.0))

    def _via_arc(self, sim, goal):
        """A straight line from the front to a cube behind the robot passes
        through the robot's own base (self-collision + IK singularity at r->0).
        So when the cube is far around, steer along a circle around the base
        and only go straight once the angle is small."""
        t = sim.target_pos
        th_t, th_g = np.arctan2(t[1], t[0]), np.arctan2(goal[1], goal[0])
        dth = wrap_angle(th_g - th_t)
        if abs(dth) < self.ARC_DONE:
            return goal
        r = np.clip(max(np.hypot(*t[:2]), np.hypot(*goal[:2])), *self.ARC_RADIUS)
        a = th_t + np.sign(dth) * self.ARC_LEAD
        return np.array([r * np.cos(a), r * np.sin(a), goal[2]])

    def reset(self, sim):
        self.phase = 0
        self.wait = 0
        self.speed = self.rng.uniform(0.6, 1.0)
        self.offset = self.rng.normal(0, 0.004, size=3)
        self.settle = 0
        if self.gripper in ("smooth", "graded"):
            self._grip_plan(sim)

    def _move_towards(self, sim, goal, dt, factor=1.0):
        step = TARGET_SPEED * self.speed * factor * dt
        delta = np.clip(goal - sim.target_pos, -step, step)
        delta += self.rng.normal(0, 0.0005, size=3)
        return delta, np.linalg.norm(goal - sim.ee_pos()) < 0.01

    def read(self, sim, dt):
        cube = sim.cube_pos() + self.offset
        if self.phase == 0:                                   # above the cube
            hover = cube + [0, 0, 0.12]
            via = self._via_arc(sim, hover)
            arcing = not np.array_equal(via, hover)
            delta, done = self._move_towards(sim, via, dt, self.ARC_SPEEDUP if arcing else 1.0)
            done = np.linalg.norm(hover - sim.ee_pos()) < 0.01
            grip = False
        elif self.phase == 1:                                 # go down
            goal = cube.copy()
            if self.gripper in ("smooth", "graded"):          # small cubes: don't push the
                goal[2] = max(goal[2], 0.029)                 # fingertips into the floor
            delta, done = self._move_towards(sim, goal, dt)
            grip = False
            if self.gripper == "smooth":                      # pre-shape: half-close to just
                above = sim.ee_pos()[2] - sim.cube_pos()[2]   # wider than the cube while aligning
                grip = self.pre * float(np.clip((0.09 - above) / 0.05, 0.0, 1.0))
            if self.gripper == "graded":                      # fully open; only close once the
                grip = 0.0                                    # fingers are within 4 mm of the goal
                done = np.linalg.norm(goal - sim.ee_pos()) < 0.004 and self.settle >= 3
                self.settle = self.settle + 1 if np.linalg.norm(goal - sim.ee_pos()) < 0.004 else 0
                if self.settle:
                    delta = np.zeros(3)                       # stand still for 3 steps first
        elif self.phase == 2:                                 # close and wait
            delta, grip = np.zeros(3), True
            if self.gripper == "smooth":                      # close gradually over 0.5 s
                grip = self.pre + (self.secure - self.pre) * min(1.0, (self.wait + 1) / 10)
            if self.gripper == "graded":                      # one size-dependent squeeze command
                grip = self.secure
            self.wait += 1
            done = self.wait > 0.8 * CONTROL_HZ
        else:                                                 # lift
            goal = np.array([cube[0], cube[1], sim.cube_start_z + 0.20])
            delta, _ = self._move_towards(sim, goal, dt)
            grip, done = (self.secure if self.gripper in ("smooth", "graded") else True), False
        if done:
            self.phase += 1
        return delta, grip, None, True


# =========================================================
# VIEWER HELPERS
# =========================================================

def draw_target_dot(viewer, pos):
    viewer.user_scn.ngeom = 1
    mujoco.mjv_initGeom(viewer.user_scn.geoms[0], mujoco.mjtGeom.mjGEOM_SPHERE,
                        np.array([0.01, 0.01, 0.01]), pos, np.eye(3).flatten(),
                        np.array([1.0, 0.0, 0.0, 1.0]))


# =========================================================
# MAIN LOOP
# =========================================================

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", default=MODEL_PATH)
    p.add_argument("--out", default=OUT_DIR)
    p.add_argument("--auto", type=int, default=0, help="record N scripted episodes (no gamepad)")
    p.add_argument("--headless", action="store_true", help="no viewer window (only with --auto)")
    p.add_argument("--seed", type=int, default=None)
    p.add_argument("--spawn", default="rect", choices=["rect", "ring"],
                   help="rect = original area in front; ring = anywhere around the base (360 deg)")
    p.add_argument("--angles", type=float, nargs=2, default=(-180.0, 180.0), metavar=("FROM", "TO"),
                   help="ring only: cube direction range in degrees, 0 = front, 90 = left, -90 = right")
    p.add_argument("--inner-frac", type=float, default=0.0,
                   help="ring only: share of cubes placed in the inner area 0.20-0.33 m (rest on the ring)")
    p.add_argument("--cube-mm", type=float, nargs=2, default=(60.0, 60.0), metavar=("MIN", "MAX"),
                   help="cube edge length range in mm (scene default 60)")
    p.add_argument("--gripper", default="binary", choices=["binary", "smooth", "graded"],
                   help="auto pilot gripper: binary 0/1 (old) or smooth graded commands")
    p.add_argument("--yaw-deg", type=float, default=0.0, help="random cube rotation +- this many degrees")
    p.add_argument("--max-sec", type=float, default=15, help="auto mode: give up after this many seconds")
    p.add_argument("--log", default=None, help="append one JSON line per attempt (saved or discarded)")
    args = p.parse_args()

    rng = np.random.default_rng(args.seed)
    sim = Sim(args.model, spawn=args.spawn, yaw_deg=args.yaw_deg, angles=tuple(args.angles),
              inner_frac=args.inner_frac, size_mm=tuple(args.cube_mm))
    # Renderer must exist before the viewer opens. Its size can't exceed the
    # model's offscreen buffer (640x480 by default), 224x224 is fine.
    renderer = mujoco.Renderer(sim.model, height=IMAGE_H, width=IMAGE_W)

    pilot = AutoPilot(rng, gripper=args.gripper) if args.auto else GamepadInput()
    dt = 1.0 / CONTROL_HZ
    saved = 0
    attempts = 0

    def render(cam):
        renderer.update_scene(sim.data, camera=cam)
        return renderer.render().copy()

    def new_episode():
        sim.reset(rng)
        pilot.reset(sim)
        q = sim.cube_qpos
        ep = Episode(str(rng.choice(INSTRUCTIONS)), sim.cube_pos(), sim.data.qpos[q + 3:q + 7].copy(), sim.cube_half)
        print(f"\n--- new episode | cube at {np.round(sim.cube_pos()[:2], 3)} "
              f"| task: '{ep.instruction}'")
        return ep

    def finish(ep, keep):
        nonlocal saved
        path = None
        if keep and len(ep) > 0:
            path = ep.save(args.out)
            saved += 1
            print(f"SAVED {path}  ({len(ep)} steps, success={ep.success})  total saved: {saved}")
        else:
            print(f"discarded ({len(ep)} steps)")
        if args.log:
            with open(args.log, "a") as f:
                f.write(json.dumps({"saved_as": path, "steps": len(ep), "success": bool(ep.success),
                                    "cube_init": [round(float(v), 4) for v in ep.cube_init],
                                    "instruction": ep.instruction}) + "\n")

    viewer = None
    if not args.headless:
        viewer = mujoco.viewer.launch_passive(sim.model, sim.data)
        viewer.cam.distance, viewer.cam.azimuth, viewer.cam.elevation = 1.3, 135, -25
        viewer.cam.lookat[:] = [0.45, 0.0, 0.1]

    ep = new_episode()
    recording = False
    hold = 0

    try:
        while viewer is None or viewer.is_running():
            tick = time.perf_counter()

            # 1. read the input for this step
            delta, grip, event, moving = pilot.read(sim, dt)

            if event == "quit":
                break
            if event in ("save", "discard"):
                finish(ep, keep=(event == "save"))
                ep, recording, hold = new_episode(), False, 0
                continue

            if not recording:
                if not moving:                     # wait for the first input
                    sim.hold_start_pose()
                    if viewer:
                        draw_target_dot(viewer, sim.target_pos)
                        viewer.sync()
                    time.sleep(dt)
                    continue
                recording = True
                print("recording...")

            # 2. observation at time t (BEFORE the action is applied)
            d = sim.data
            obs = dict(
                workspace=render("workspace_camera"),
                wrist=render("wrist_camera"),
                joint_pos=d.qpos[sim.qpos_addr].copy(),
                joint_vel=d.qvel[sim.dof_addr].copy(),
                gripper=sim.gripper_opening(),
                ee_pos=sim.ee_pos(),
                cube_pos=sim.cube_pos(),
            )

            # 3. apply action a_t and step physics for one control period
            sim.apply_action(delta, grip)

            # 4. store (o_t, a_t). The red dot after the move is the absolute
            #    EE target; joint_targets are what the servos were told.
            g = float(grip)                         # 0/1, or in between with --gripper smooth
            ep.add(**obs,
                   action=np.concatenate([delta, [g]]),
                   action_ee_target=np.concatenate([sim.target_pos, [g]]),
                   action_joint=np.concatenate([sim.joint_targets, [g]]))

            # 5. success check
            hold = hold + 1 if sim.is_lifted() else 0
            if hold == SUCCESS_HOLD_STEPS and not ep.success:
                ep.success = True
                print("SUCCESS detected!" + ("" if args.auto else "  Press Y to save."))

            # auto mode: save on success, give up after 15 s
            if args.auto:
                done_ok = ep.success and hold >= SUCCESS_HOLD_STEPS + 5
                timeout = len(ep) >= args.max_sec * CONTROL_HZ
                if done_ok or timeout:
                    finish(ep, keep=done_ok)
                    attempts += 1
                    if saved >= args.auto:
                        break
                    ep, recording, hold = new_episode(), False, 0
                    continue
            elif len(ep) >= MAX_EPISODE_SEC * CONTROL_HZ:
                print("episode too long, discarding")
                finish(ep, keep=False)
                ep, recording, hold = new_episode(), False, 0
                continue

            # 6. show it and keep real time (skip sleeping when headless)
            if viewer:
                draw_target_dot(viewer, sim.target_pos)
                viewer.sync()
                left = dt - (time.perf_counter() - tick)
                if left > 0:
                    time.sleep(left)
    finally:
        if viewer:
            viewer.close()
        renderer.close()

    print(f"\nDone. {saved} episodes saved in '{args.out}'.")
    if args.auto:
        print(f"Scripted pilot succeeded in {saved} of {attempts} attempts.")


if __name__ == "__main__":
    main()
