"""
relabel_gripper.py  -  make the gripper labels in a training cache consistent (no images rewritten).

Why: the smooth pilot started pre-closing the fingers 4-9 cm above the cube and then ramped the
command up. A policy trained on that starts closing ~12 mm too high and ~12 mm off-centre
(diag_grasp_timing.py), pinches the top of the cube and squeezes it out. The old binary demos
instead say "fully open until the moment of grasp, then 1.0".

New labels for every episode:
  0                     until the pilot stops moving to grasp (first frame whose move is exactly 0)
  secure(cube width)    from that frame on - a graded command that depends on the cube's size
                        (60 mm -> 0.66, 45 mm -> 0.83; see AutoPilot._grip_plan)
Old binary demos (label 1.0, 60 mm cube) get 1.0 -> secure(60 mm) so both sources agree.

  python relabel_gripper.py --cache ../cache_inner --out ../cache_inner_v2
"""
import argparse
import json
import os

import numpy as np


def secure_cmd(width_mm):
    return float(np.clip((86 + 3.0 * (60 - width_mm)) / 255 + 0.32, 0, 1))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--cache", required=True)
    p.add_argument("--out", required=True)
    a = p.parse_args()
    m = dict(np.load(os.path.join(a.cache, "meta.npz")))
    act = m["action"].copy()
    ends = m["episode_ends"]
    starts = np.r_[0, ends[:-1]]
    report = {"smooth": 0, "binary": 0, "no_stop_found": 0}
    for s, e in zip(starts, ends):
        g = act[s:e, 3].copy()
        if np.all((g == 0) | (g == 1)):                 # old binary demo
            act[s:e, 3] = np.where(g > 0.5, secure_cmd(60.0), 0.0)
            report["binary"] += 1
            continue
        still = np.where(np.all(act[s:e, :3] == 0, axis=1) & (g > 0))[0]
        if len(still) == 0:
            report["no_stop_found"] += 1
            continue
        t0 = still[0]
        act[s:e, 3] = 0.0
        act[s + t0:e, 3] = g.max()                      # the pilot's size-dependent "secure" value
        report["smooth"] += 1
    m["action"] = act
    os.makedirs(a.out, exist_ok=True)
    np.savez(os.path.join(a.out, "meta.npz"), **m)
    dst = os.path.join(a.out, "images.npy")
    if not os.path.exists(dst):
        os.link(os.path.join(a.cache, "images.npy"), dst)   # same images, no extra disk space
    print(json.dumps(report), "label values:", np.unique(np.round(act[:, 3], 2))[:20])


if __name__ == "__main__":
    main()
