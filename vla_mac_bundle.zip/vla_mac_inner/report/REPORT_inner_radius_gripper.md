# Close-in pickups and a smooth gripper: what I found and what changed

*Fine-tune of `training/run3_360` (the 360-degree model), 2026-10-21 to 2026-10-22. All numbers come from physics tests in MuJoCo, not from training loss.*

## 1. Short answer

| | Original model (run3) | New model (run7) |
|---|---|---|
| **60 mm cube, 96 fixed spots** | inner 29/32, middle 30/32, outer 29/32 | inner 27/32, middle 29/32, outer 28/32 |
| **45–60 mm cubes, 48 fixed spots** | inner 15/16, middle 11/16, outer 11/16 | inner 13/16, middle 15/16, outer 14/16 |
| **All 144 spots** | **125/144 (87%)** | **126/144 (88%)** |
| Fingers hitting the floor (60 mm set) | 10 tries | 0 tries |
| Gripper | on/off only (0 or 1) | graded: squeezes 0.82 for a 45 mm cube, 0.64 for a 60 mm cube |

- **Close-in (inner band):** the original model was **not** weak there. It scored 29/32 even though it had never trained inside 0.33 m. The old charts looked empty in the middle only because no test was run there. The new model is slightly lower close-in (40/48 against 44/48). With this many tries, that gap is within luck, but it is **not** an improvement. I am not claiming one.
- **Smaller cubes:** the new model is clearly better in the middle and outer bands (29/32 against 22/32 for 45–60 mm cubes).
- **Gripper:** the new model really does use in-between values. The squeeze it sends follows the cube's size, and I measured the finger response for each value (section 4).
- **Overall:** the same success rate (126 against 125 of 144), with no floor scraping and a size-aware grip.
- **Original model:** untouched, and still the default in `play_policy.py` and `viewer_sidebar.py` (section 7 explains how to pick the new one).

## 2. What I checked first

| Question | Answer | Evidence |
|---|---|---|
| Is the inner area reachable? | Yes, from **0.20 m**. At 0.18 m only 6/24 scripted pickups work, and at 0.16 m and closer 0/24 work, because the arm hits its own base. | `diag_controller.py`, logs in `diag_inner/` |
| Was it trained or tested there? | No. Demos and tests only covered 0.33–0.66 m (`RING_R` in `record_episodes.py`). | code |
| Can the cameras see close-in cubes? | Partly. At the start pose the arm hides cubes 0.20–0.30 m away in the front-left (0–90°) from both cameras. | `diag_visibility.py`, `diag_inner/visibility_v3_inner.json` |
| Is there a reward function? | **No.** This is imitation learning: the model copies scripted demos (L1 loss on moves plus a gripper loss). So there was no reward to adjust and no reward loophole possible. Success is judged only by the physics test: the cube is lifted 5 cm and still held 2 s later. | `train_policy.py` |
| Where did the on/off gripper come from? | Not from the hardware. The Robotiq actuator is a position servo that accepts any value 0–255. The on/off behaviour came from three places in the code: demo labels were 0/1, the model output was cut at 0.5, and `apply_action` turned that into 0 or 255. | `diag_gripper.py` |

## 3. Why my first three fine-tunes got worse, and the fix

**Attempts 1–3** (smooth-gripper demos, several training schedules) all lowered close-in success to 21–23 of 32.

The cause, measured with `diag_grasp_timing.py`, which logs where the fingertips are when the gripper starts closing:
- The original model starts closing about 3 mm from the grasp point.
- The fine-tuned models started closing 12–15 mm too high and 12 mm off-centre.
- The fingers then pinched the top of the cube and squeezed it out sideways. The logged failure was "grasp failure", with the gripper shutting on air.

That habit came from my demo pilot. It began closing the fingers during the last few centimetres of the descent, and it started the squeeze up to 1 cm above the target (median 7 mm).

**The fix (attempt 4)** was a new pilot mode, `--gripper graded`:
- It keeps the gripper fully open until the fingertips are within 4 mm of the grasp point (median now 2.5 mm).
- It stands still for 3 steps.
- It then sends one size-dependent squeeze command. Smaller cubes get a bigger command, and the fingers stop when they touch the cube.

After retraining on these demos, the model closes about 2 mm from the grasp point again, and close-in success came back to 27/32.

![All attempts](eval_inner/charts/6_all_attempts.png)

## 4. Gripper: does in-between control really work?

**Bench test** (`diag_gripper.py`, empty gripper): finger position follows the command in a straight line from 0 to about 0.95.

**On a cube, the fingers stop at contact:**

| Cube width | Command that just touches it |
|---|---|
| 60 mm | 0.33 |
| 50 mm | 0.45 |
| 40 mm | 0.56 |

Above contact, extra command only adds squeeze force, up to the actuator's 5 N limit. So "secure" means contact plus a margin, not "fully closed".

**In the test (45–60 mm set, while holding):**

| Cube | Original model: command / finger closure | New model: command / finger closure |
|---|---|---|
| 45–50 mm | 1.00 / 0.47 | **0.82** / 0.47 |
| 50–55 mm | 1.00 / 0.42 | **0.77** / 0.42 |
| 55–60 mm | 1.00 / 0.36 | **0.70** / 0.36 |

The new model sends a different command for each cube size; the original always sends 1.0. The finger closure is the same, because the cube stops the fingers. The model also outputs about 26 distinct gripper values per try (the original: 2).

**What is honestly not there:** partial pre-shaping while approaching. I tried it in attempt 1, and that pre-closing is exactly what caused the "closes too high" problem. So the final model stays fully open until the grasp, then squeezes according to size. Intermediate values are real and tested, but they are used for "how hard to squeeze", not for a half-closed approach.

![Gripper](eval_inner/charts/5_gripper.png)

## 5. Charts

1. Success vs distance: ![](eval_inner/charts/1_success_vs_radius.png)
2. Before vs after per band: ![](eval_inner/charts/2_before_after_bands.png)
3. Success vs direction: ![](eval_inner/charts/3_success_vs_angle.png)
4. Training loss, plus a physics test after each stage (8 tries per band, 45–60 mm cubes; there is no reward to plot): ![](eval_inner/charts/4_training.png)
5. Gripper command vs actual finger position: above.
6. All four attempts: above.

## 6. What changed (files in `vla/`)

| File | Change |
|---|---|
| `record_episodes.py` | `INNER_R = (0.20, 0.33)` and `--inner-frac` (extra close-in demos while still sampling the whole ring); `--cube-mm MIN MAX` (random cube size); `--gripper binary / smooth / graded`. `apply_action` accepts 0..1 (a bool still works, so old scripts behave the same). |
| `eval_radial.py` (new) | Fixed test spots in inner, middle and outer bands × 8 directions, with random cube turn and size. Records pickup, grasp-and-lift (held 2 s), failure causes, floor contacts, and gripper command vs finger position. Resumes after an interruption. |
| `compare_plots.py` (new) | The six charts above. |
| `train_policy.py` | `--band-weights` (curriculum: how often each band is shown) and `--resume` (`checkpoints/resume.pt` is saved every epoch). |
| `relabel_gripper.py` (new) | Makes old 0/1 demo labels match the graded scheme without re-recording. |
| `diag_gripper.py`, `diag_grasp_timing.py` (new) | Physical gripper response, and where the fingers are when closing starts. |
| `play_policy.py`, `viewer_sidebar.py` | New option `--gripper continuous` (default) or `binary`. Random spots now include 0.20–0.33 m. |
| `run_attempt4.sh` | The full attempt-4 pipeline (merge, cache, 2 training stages, test). Every step is skipped if already done. |

The observation and action format are unchanged: 10 state numbers and 2 cameras in; 3 moves plus 1 gripper value out. The architecture is unchanged, so every old checkpoint still loads.

**Checkpoints:**
- Original: `training/run3_360` (untouched) and `training/run3_360_BACKUP_original`.
- New: `training/run7_graded_b/checkpoints/best.pt`.

**Training recipe for the new model:**
- Started from the original run3 weights, with 300 graded-pilot demos (half close-in, 45–60 mm cubes) plus 340 of the original demos to keep its existing skills.
- Stage 1: 50% close-in, 25% middle, 25% outer; 5 epochs at learning rate 1.5e-4.
- Stage 2: the natural mix; 4 epochs at learning rate 7e-5.

## 7. Commands

```bash
# watch either model (Mac: mjpython instead of python)
python viewer_sidebar.py --ckpt training/run7_graded_b/checkpoints/best.pt
python viewer_sidebar.py --ckpt training/run3_360/checkpoints/best.pt --gripper binary   # original

# full test (same spots as above), 4 parts in parallel, then the summary
for k in 0 1 2 3; do python eval_radial.py --ckpt training/run7_graded_b/checkpoints/best.pt \
  --out eval/run7_60mm --gripper continuous --per-band 32 --seed 9700 --part $k --parts 4 & done; wait
python eval_radial.py --out eval/run7_60mm --summarize
#   45-60 mm set: add  --per-band 16 --seed 9800 --cube-mm 45 60

# resume an interrupted training stage
python train_policy.py --data CACHE --out training/run7_graded_b --resume --epochs 4 --lr 7e-5 --frames-per-epoch 40000

# record demos like the new ones
python record_episodes.py --auto 75 --headless --model vla_scene_v3.xml --spawn ring --inner-frac 0.5 \
  --cube-mm 45 60 --yaw-deg 30 --gripper graded --max-sec 25 --out raw/w0 --seed 5000
```

## 8. Limits and next steps

- **Storage:** the project's file storage is full (10 GB). The 300 graded demos (2.3 GB) could not be saved here; they exist only in my temporary workspace. The 400 attempt-1 demos in `dataset_inner/` (3 GB) are no longer needed and could be deleted to make room, but I have not deleted them.
- **Closest ring (0.20–0.24 m)** is the new model's weakest spot: 4 of 7 there (the original got 6 of 7). See chart 1.
- **Remaining close-in misses** are mostly in two places: the front-left, where the arm hides the cube from both cameras at the start, and the right side around 275–290°. A different start pose or a third camera would be the next thing to try.
- **Small numbers:** 16–32 tries per band means differences of about 2 tries are within luck.
