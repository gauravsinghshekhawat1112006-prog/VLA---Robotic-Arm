"""
train_policy.py  -  train the pickup policy on the converted dataset (CPU is fine).

  python train_policy.py --data ../dataset/train_cache.npz --out ../training/run1 --epochs 60

Fine-tune an existing checkpoint on a new dataset (weights are copied, the input/output
normalisation is recomputed from the new data because the joint angles now cover 360 deg):
  python train_policy.py --data ../dataset360/cache --out ../training/run2_360 \
         --init ../training/run1/checkpoints/best.pt --epochs 30 --frames-per-epoch 40000

Curriculum / targeted training (inner area = cube 0.20-0.33 m from the base):
  --band-weights 0.6 0.2 0.2   sample training frames so inner / middle (0.33-0.50) / outer (0.50+)
                               episodes get these shares (needs a cache made by the current
                               convert_dataset.py, which stores each episode's cube position)
Resume after an interruption:  add --resume (continues from <out>/checkpoints/resume.pt)

Gripper target: the recorded gripper value (0..1). Old demos are 0/1, new demos have graded
values; binary cross-entropy works with both, and the model's sigmoid output is the command.

Saves in --out:
  config.json            all settings + dataset stats + train/val episode split
  log.csv                per-epoch train/val losses, learning rate, time
  loss_curve.png         the loss curves
  checkpoints/epoch_XXX.pt and best.pt (lowest validation loss), last.pt
"""
import argparse
import csv
import json
import os
import time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F

from convert_dataset import load_cache
from policy import PickupPolicy


class ChunkDataset(torch.utils.data.Dataset):
    """Sample = (images_t, state_t) -> actions t..t+K-1 of the same episode.
    Past the episode end the chunk is padded (delta 0, last gripper) and masked."""

    def __init__(self, d, frames, chunk, stats, augment):
        self.images, self.state, self.action = d["images"], d["state"], d["action"]
        self.ep_end = d["episode_ends"][d["episode_index"]]
        self.frames, self.chunk, self.augment = frames, chunk, augment
        self.a_mean = np.array(stats["action_mean"], np.float32)
        self.a_std = np.array(stats["action_std"], np.float32)

    def __len__(self):
        return len(self.frames)

    def shift(self, img, pad=6):
        h, w = img.shape[:2]
        p = np.pad(img, ((pad, pad), (pad, pad), (0, 0)), mode="edge")
        y, x = np.random.randint(0, 2 * pad + 1, 2)
        return p[y:y + h, x:x + w]

    def __getitem__(self, i):
        g = self.frames[i]
        end = self.ep_end[g]
        idx = np.arange(g, g + self.chunk)
        valid = idx < end
        idx = np.minimum(idx, end - 1)
        a = self.action[idx].copy()
        a[~valid, :3] = 0.0
        delta = (a[:, :3] - self.a_mean) / self.a_std
        img = self.images[g]
        if self.augment:
            img = np.stack([self.shift(im) for im in img])
        return (torch.from_numpy(np.ascontiguousarray(img)), torch.from_numpy(self.state[g]),
                torch.from_numpy(delta.astype(np.float32)), torch.from_numpy(a[:, 3].astype(np.float32)),
                torch.from_numpy(valid))


def run_epoch(model, loader, opt=None, sched=None, device="cpu"):
    train = opt is not None
    model.train(train)
    tot = {"loss": 0.0, "l1": 0.0, "grip_bce": 0.0, "grip_acc": 0.0}
    n = 0
    with torch.set_grad_enabled(train):
        for img, st, delta, grip, valid in loader:
            img, st, delta, grip, valid = (x.to(device) for x in (img, st, delta, grip, valid))
            pd, pg = model(img, st)
            m = valid.float().unsqueeze(-1)
            l1 = (torch.abs(pd - delta) * m).sum() / (m.sum() * 3)
            bce = F.binary_cross_entropy_with_logits(pg, grip)
            loss = l1 + bce
            if train:
                opt.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 10.0)
                opt.step()
                sched.step()
            b = img.shape[0]
            n += b
            tot["loss"] += loss.item() * b
            tot["l1"] += l1.item() * b
            tot["grip_bce"] += bce.item() * b
            # gripper "accuracy": predicted command within 0.1 of the label (same as before for 0/1 labels)
            tot["grip_acc"] += ((torch.sigmoid(pg[:, 0]) - grip[:, 0]).abs() < 0.1).float().mean().item() * b
    return {k: v / n for k, v in tot.items()}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--epochs", type=int, default=60)
    p.add_argument("--batch", type=int, default=64)
    p.add_argument("--lr", type=float, default=3e-4)
    p.add_argument("--chunk", type=int, default=10)
    p.add_argument("--val-episodes", type=int, default=10)
    p.add_argument("--threads", type=int, default=os.cpu_count())
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--device", default="auto", help="auto | cpu | mps (Apple GPU) | cuda")
    p.add_argument("--init", default=None, help="start from this checkpoint's weights (fine-tuning)")
    p.add_argument("--band-weights", type=float, nargs=3, default=None, metavar=("INNER", "MIDDLE", "OUTER"),
                   help="share of training samples from inner / middle / outer episodes")
    p.add_argument("--resume", action="store_true", help="continue an interrupted run from <out>/checkpoints/resume.pt")
    p.add_argument("--frames-per-epoch", type=int, default=0,
                   help="random training frames per epoch (0 = all). Keeps epochs short on big datasets")
    args = p.parse_args()

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    torch.set_num_threads(args.threads)
    os.makedirs(os.path.join(args.out, "checkpoints"), exist_ok=True)

    raw = load_cache(args.data)
    d = {k: raw[k] for k in ["images", "state", "action", "episode_index", "episode_ends"]}
    ep_r = np.hypot(*raw["episode_cube_xy"].T) if "episode_cube_xy" in raw else None
    stats = json.loads(str(raw["stats"]))
    names = raw["names"].tolist()
    E = len(names)
    rng = np.random.default_rng(args.seed)
    val_eps = sorted(rng.choice(E, args.val_episodes, replace=False).tolist())
    is_val = np.isin(d["episode_index"], val_eps)
    tr_frames, va_frames = np.where(~is_val)[0], np.where(is_val)[0]
    print(f"{E} episodes ({E - len(val_eps)} train / {len(val_eps)} val), "
          f"{len(tr_frames)} train frames, {len(va_frames)} val frames")

    tr_set = ChunkDataset(d, tr_frames, args.chunk, stats, True)
    band_info = None
    if args.band_weights:
        assert ep_r is not None, "cache has no episode_cube_xy: re-run convert_dataset.py"
        band = np.digitize(ep_r, [0.33, 0.50])[d["episode_index"][tr_frames]]     # 0 inner, 1 middle, 2 outer
        counts = np.bincount(band, minlength=3).astype(float)
        w = np.array(args.band_weights, float) / np.maximum(counts, 1)
        band_info = {"frames_per_band": counts.astype(int).tolist(), "target_shares": args.band_weights}
        print("frames per band (inner/middle/outer):", band_info["frames_per_band"], "-> sampled shares", args.band_weights)
        sampler = torch.utils.data.WeightedRandomSampler(torch.as_tensor(w[band]), replacement=True,
                                                         num_samples=args.frames_per_epoch or len(tr_frames))
    elif 0 < args.frames_per_epoch < len(tr_frames):
        sampler = torch.utils.data.RandomSampler(tr_set, replacement=False, num_samples=args.frames_per_epoch)
    else:
        sampler = torch.utils.data.RandomSampler(tr_set)
    tr = torch.utils.data.DataLoader(tr_set, batch_size=args.batch, sampler=sampler, num_workers=2,
                                     drop_last=True, persistent_workers=True)
    va = torch.utils.data.DataLoader(ChunkDataset(d, va_frames, args.chunk, stats, False),
                                     batch_size=128, num_workers=1)

    if args.device == "auto":
        args.device = ("cuda" if torch.cuda.is_available() else
                       "mps" if torch.backends.mps.is_available() else "cpu")
    print("device:", args.device)
    model = PickupPolicy(stats, chunk=args.chunk)
    if args.init and not args.resume:
        old, ck0 = PickupPolicy.load(args.init)
        assert old.chunk == args.chunk, "chunk size must match the checkpoint"
        sd = {k: v for k, v in old.state_dict().items() if not k.endswith(("_mean", "_std"))}
        missing, unexpected = model.load_state_dict(sd, strict=False)
        assert not unexpected and all(k.endswith(("_mean", "_std")) for k in missing), (missing, unexpected)
        print(f"initialised from {args.init} (epoch {ck0['extra'].get('epoch')}); normalisation stats from new data")
    model = model.to(args.device)
    n_params = sum(p.numel() for p in model.parameters())
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=args.lr, total_steps=args.epochs * len(tr),
                                                pct_start=0.05)
    cfg = dict(vars(args), stats=stats, band_info=band_info, n_params=n_params, val_episodes=[names[i] for i in val_eps],
               train_episodes=[names[i] for i in range(E) if i not in val_eps],
               inputs="workspace + wrist images, joint_pos, gripper, ee_pos (no cube position)")
    if not args.resume:
        json.dump(cfg, open(os.path.join(args.out, "config.json"), "w"), indent=2)
    print(f"model parameters: {n_params:,}")

    log = []
    best = 1e9
    first = 1
    resume_path = os.path.join(args.out, "checkpoints", "resume.pt")
    if args.resume:
        rs = torch.load(resume_path, map_location="cpu", weights_only=False)
        model.load_state_dict(rs["model"])
        opt.load_state_dict(rs["opt"])
        sched.load_state_dict(rs["sched"])
        log, best, first = rs["log"], rs["best"], rs["epoch"] + 1
        print(f"resumed from {resume_path} after epoch {rs['epoch']}")
    t0 = time.time()
    for ep in range(first, args.epochs + 1):
        a = run_epoch(model, tr, opt, sched, args.device)
        b = run_epoch(model, va, device=args.device)
        row = {"epoch": ep, **{f"train_{k}": round(v, 5) for k, v in a.items()},
               **{f"val_{k}": round(v, 5) for k, v in b.items()},
               "lr": sched.get_last_lr()[0], "minutes": round((time.time() - t0) / 60, 2)}
        log.append(row)
        print(row, flush=True)
        extra = {"epoch": ep, "val_loss": b["loss"]}
        if b["loss"] < best:
            best = b["loss"]
            model.save(os.path.join(args.out, "checkpoints", "best.pt"), extra)
        if ep % 10 == 0 or ep == args.epochs:
            model.save(os.path.join(args.out, "checkpoints", f"epoch_{ep:03d}.pt"), extra)
        model.save(os.path.join(args.out, "checkpoints", "last.pt"), extra)
        torch.save({"model": model.state_dict(), "opt": opt.state_dict(), "sched": sched.state_dict(),
                    "log": log, "best": best, "epoch": ep}, resume_path)
        with open(os.path.join(args.out, "log.csv"), "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(row))
            w.writeheader()
            w.writerows(log)

        fig, ax = plt.subplots(1, 2, figsize=(11, 4))
        e = [r["epoch"] for r in log]
        for k, lab in [("l1", "action L1 (normalised)"), ("grip_bce", "gripper BCE")]:
            ax[0 if k == "l1" else 1].plot(e, [r[f"train_{k}"] for r in log], label="train")
            ax[0 if k == "l1" else 1].plot(e, [r[f"val_{k}"] for r in log], label="validation")
            ax[0 if k == "l1" else 1].set(xlabel="epoch", title=lab, yscale="log")
            ax[0 if k == "l1" else 1].legend()
        fig.tight_layout()
        fig.savefig(os.path.join(args.out, "loss_curve.png"), dpi=110)
        plt.close(fig)

    # prove the saved checkpoint loads and runs
    m2, ck = PickupPolicy.load(os.path.join(args.out, "checkpoints", "best.pt"))
    x = torch.from_numpy(d["images"][:2])
    s = torch.from_numpy(d["state"][:2])
    out = m2(x, s)
    print(f"reloaded best.pt (epoch {ck['extra']['epoch']}), output shapes {[tuple(o.shape) for o in out]}")


if __name__ == "__main__":
    main()
