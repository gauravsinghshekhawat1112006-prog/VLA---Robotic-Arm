"""
validate_dataset.py  -  check every recorded episode before training.

  python validate_dataset.py --data ../dataset/episodes --logs "../raw/*.jsonl" --out ../dataset/validation

Writes <out>/validation_report.md, <out>/episode_checks.csv and preview images.
Exit code 1 if any episode fails a check.
"""
import argparse
import csv
import glob
import json
import os

import h5py
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image

import record_episodes as R

EXPECTED = {
    "observations/images/workspace": ((R.IMAGE_H, R.IMAGE_W, 3), np.uint8),
    "observations/images/wrist": ((R.IMAGE_H, R.IMAGE_W, 3), np.uint8),
    "observations/joint_pos": ((6,), np.float32),
    "observations/joint_vel": ((6,), np.float32),
    "observations/gripper": ((1,), np.float32),
    "observations/ee_pos": ((3,), np.float32),
    "observations/cube_pos": ((3,), np.float32),
    "action": ((4,), np.float32),
    "action_ee_target": ((4,), np.float32),
    "action_joint": ((7,), np.float32),
}


def red_pixels(img):
    """Pixels that are clearly red. Relative test, so the cube still counts when it
    sits in the gripper's shadow (a fixed brightness threshold missed those)."""
    r, g, b = (img[..., i].astype(int) for i in range(3))
    return int(((r > 50) & (r > 2.5 * g) & (r > 2.5 * b)).sum())


def check_episode(path):
    r = {"file": os.path.basename(path)}
    problems = []
    with h5py.File(path, "r") as h:
        T = int(h.attrs["num_steps"])
        r["steps"] = T
        for name, (shape, dtype) in EXPECTED.items():
            if name not in h:
                problems.append(f"missing {name}")
                continue
            d = h[name]
            if d.shape != (T,) + shape or d.dtype != dtype:
                problems.append(f"{name} shape {d.shape} dtype {d.dtype}")
        if problems:
            r["problems"] = "; ".join(problems)
            return r, None

        ws = h["observations/images/workspace"][:]       # decodes every frame
        wr = h["observations/images/wrist"][:]
        cube = h["observations/cube_pos"][:]
        ee = h["observations/ee_pos"][:]
        grip = h["observations/gripper"][:, 0]
        act = h["action"][:]
        tgt = h["action_ee_target"][:]
        aj = h["action_joint"][:]
        instr = h.attrs["language_instruction"]
        r["instruction"] = instr
        r["success_attr"] = bool(h.attrs["success"])
        r["fps"] = int(h.attrs["fps"])

    # images readable and not blank
    stds = np.array([ws.reshape(T, -1).std(1), wr.reshape(T, -1).std(1)])
    r["min_image_std"] = round(float(stds.min()), 1)
    if stds.min() < 5:
        problems.append("blank image frame")
    r["cube_px_first_ws"] = red_pixels(ws[0])
    r["cube_px_first_wrist"] = red_pixels(wr[0])
    # with the v3 overhead camera a cube right under the gripper is hidden from above at
    # the start pose, but then the wrist camera sees it, so either camera counts
    if r["cube_px_first_ws"] < 5 and r["cube_px_first_wrist"] < 5:
        problems.append("cube not visible in first frame of either camera")

    # action label consistency
    # (a) delta action == change of the absolute target (exact unless the target hit a clip limit)
    d_tgt = np.diff(tgt[:, :3], axis=0)
    r["delta_vs_target_err_mm"] = round(float(np.abs(d_tgt - act[1:, :3]).max() * 1000), 3)
    if r["delta_vs_target_err_mm"] > 0.01:
        problems.append("delta action does not match target change")
    # (b) gripper label identical in all three action versions
    if not (np.array_equal(act[:, 3], tgt[:, 3]) and np.array_equal(act[:, 3], aj[:, 6])):
        problems.append("gripper labels disagree")
    if not set(np.unique(act[:, 3])) <= {0.0, 1.0}:
        problems.append("gripper label not binary")
    # (c) synchronization: observation t+1 must reflect action t. The gripper
    #     follows the red-dot target with a small lag; a misaligned (shifted)
    #     log would show a much larger error at one of the neighbouring offsets.
    lag = {k: float(np.linalg.norm(ee[1 + k:] - tgt[:T - 1 - k, :3] if k >= 0 else
                                   ee[1:k] - tgt[-k:T - 1, :3], axis=1).mean() * 1000)
           for k in (-1, 0, 1, 2)}
    r["track_err_mm"] = round(lag[0], 2)
    r["best_offset"] = min(lag, key=lag.get)
    if r["best_offset"] < 0:
        problems.append("observations lead actions (misaligned)")
    # (d) first action is taken from the first observation's state
    if np.linalg.norm(tgt[0, :3] - act[0, :3] - ee[0]) > 0.002:
        problems.append("first target does not start at the gripper")

    # verified pickup: cube raised >= 5 cm, still raised and between the fingers at the end
    z0 = cube[0, 2]
    r["lift_max_cm"] = round(float((cube[:, 2].max() - z0) * 100), 1)
    r["lift_end_cm"] = round(float((cube[-1, 2] - z0) * 100), 1)
    r["end_cube_to_fingers_cm"] = round(float(np.linalg.norm(cube[-1] - ee[-1]) * 100), 1)
    r["end_gripper"] = round(float(grip[-1]), 2)
    verified = (r["lift_end_cm"] >= R.LIFT_HEIGHT * 100 and r["end_cube_to_fingers_cm"] < 5
                and act[-1, 3] == 1.0)
    r["verified_pickup"] = verified
    if not verified:
        problems.append("pickup not verified")
    if verified != r["success_attr"]:
        problems.append("success attribute disagrees with physics")
    if instr not in R.INSTRUCTIONS:
        problems.append("unknown instruction")

    r["cube_x"], r["cube_y"] = round(float(cube[0, 0]), 3), round(float(cube[0, 1]), 3)
    r["problems"] = "; ".join(problems)
    # keep only 6 preview frames per episode (keeping every frame ran out of RAM at 600 episodes)
    idx = np.linspace(0, T - 1, 6).astype(int)
    traj = dict(ee=ee, ws=ws[idx], wr=wr[idx], grip_cmd=act[:, 3])
    return r, traj


def resample(x, n=50):
    t = np.linspace(0, len(x) - 1, n)
    return np.stack([np.interp(t, np.arange(len(x)), x[:, i]) for i in range(x.shape[1])], 1)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", required=True)
    p.add_argument("--logs", default=None, help="glob of attempt logs (jsonl) from record_episodes --log")
    p.add_argument("--out", required=True)
    args = p.parse_args()
    os.makedirs(args.out, exist_ok=True)

    files = sorted(glob.glob(os.path.join(args.data, "episode_*.hdf5")))
    rows, trajs = [], []
    for f in files:
        r, tr = check_episode(f)
        rows.append(r)
        trajs.append(tr)
        print(f"{r['file']}: {'OK' if not r['problems'] else 'FAIL ' + r['problems']}")

    keys = sorted({k for r in rows for k in r}, key=lambda k: (k != "file", k))
    with open(os.path.join(args.out, "episode_checks.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)

    attempts = []
    if args.logs:
        for lf in sorted(glob.glob(args.logs)):
            attempts += [json.loads(line) for line in open(lf)]
    n_fail_attempts = sum(1 for a in attempts if not a["saved_as"])

    good = [r for r in rows if not r["problems"]]
    ok_tr = [t for r, t in zip(rows, trajs) if t is not None and not r["problems"]]
    steps = np.array([r["steps"] for r in good])
    xy = np.array([[r["cube_x"], r["cube_y"]] for r in good])
    instr = {}
    for r in good:
        instr[r["instruction"]] = instr.get(r["instruction"], 0) + 1

    # diversity
    dmin = min(np.linalg.norm(xy[i] - xy[j]) for i in range(len(xy)) for j in range(i)) if len(xy) > 1 else 0
    E = np.stack([resample(t["ee"]) for t in ok_tr])
    E_rel = E - E[:, :1]                                    # shape of the path, start removed
    pair = [np.linalg.norm(E_rel[i] - E_rel[j], axis=1).mean() for i in range(len(E)) for j in range(i)]
    close_step = np.array([int(np.argmax(t["grip_cmd"] > 0)) for t in ok_tr])

    # plots
    fig, ax = plt.subplots(1, 3, figsize=(15, 4.2))
    ax[0].scatter(xy[:, 1], xy[:, 0], s=14)
    ax[0].add_patch(plt.Rectangle((R.CUBE_Y[0], R.CUBE_X[0]), np.ptp(R.CUBE_Y), np.ptp(R.CUBE_X),
                                  fill=False, ls="--", color="gray"))
    ax[0].set(xlabel="cube y (m)", ylabel="cube x (m)", title="Cube start positions (dashed = spawn area)")
    ax[0].set_aspect("equal")
    ax[1].hist(steps / R.CONTROL_HZ, bins=15)
    ax[1].set(xlabel="episode length (s)", ylabel="episodes", title="Episode lengths")
    for t in ok_tr:
        ax[2].plot(t["ee"][:, 1], t["ee"][:, 2], lw=0.6, alpha=0.5)
    ax[2].set(xlabel="gripper y (m)", ylabel="gripper z (m)", title="Gripper paths (side view)")
    fig.tight_layout()
    fig.savefig(os.path.join(args.out, "dataset_overview.png"), dpi=110)

    # representative previews: shortest, median, longest, and an edge-of-workspace cube
    order = np.argsort(steps)
    picks = {"shortest": order[0], "median": order[len(order) // 2], "longest": order[-1],
             "far corner": int(np.argmax(np.abs(xy[:, 1]) + xy[:, 0]))}
    tiles = []
    for label, i in picks.items():
        t = ok_tr[i]
        tiles.append(np.concatenate([np.concatenate(list(t["ws"]), 1), np.concatenate(list(t["wr"]), 1)], 0))
    Image.fromarray(np.concatenate(tiles, 0)).resize((6 * 160, 8 * 160)).save(
        os.path.join(args.out, "preview_representative.jpg"), quality=85)

    lines = [
        "# Dataset validation report",
        "",
        f"- Episode files found: **{len(files)}**, passing every check: **{len(good)}**",
        f"- Recording attempts logged: {len(attempts)} ({len(attempts) - n_fail_attempts} saved, "
        f"{n_fail_attempts} failed and discarded)",
        f"- Steps per episode: min {steps.min()}, median {int(np.median(steps))}, max {steps.max()} "
        f"(at {R.CONTROL_HZ} Hz: {steps.min() / R.CONTROL_HZ:.1f} to {steps.max() / R.CONTROL_HZ:.1f} s); "
        f"total {steps.sum()} steps",
        f"- Images: every frame decoded, {R.IMAGE_H}x{R.IMAGE_W}x3 uint8, min per-frame std "
        f"{min(r['min_image_std'] for r in good)}; cube visible in the first frame of every episode "
        f"(workspace camera in {sum(r['cube_px_first_ws'] >= 5 for r in good)}, otherwise the wrist camera)",
        f"- Action labels: delta action equals change of absolute target in every step "
        f"(max error {max(r['delta_vs_target_err_mm'] for r in good)} mm); gripper label binary and identical "
        f"in action / action_ee_target / action_joint",
        f"- Synchronization: the schema has no per-step timestamps; observation t and action t share index t "
        f"at a fixed {R.CONTROL_HZ} Hz. Check: gripper position at t+1 vs commanded target at t, mean "
        f"{np.mean([r['track_err_mm'] for r in good]):.1f} mm; best-matching offset is 0 or +1 step in "
        f"{sum(r['best_offset'] >= 0 for r in good)}/{len(good)} episodes (no observation leads its action)",
        f"- Verified pickups (physics, not the success flag): {sum(r['verified_pickup'] for r in good)}/{len(good)}; "
        f"cube height at episode end: {min(r['lift_end_cm'] for r in good)} to "
        f"{max(r['lift_end_cm'] for r in good)} cm above start, cube-to-fingers at end <= "
        f"{max(r['end_cube_to_fingers_cm'] for r in good)} cm",
        f"- Instructions: " + ", ".join(f'"{k}" x{v}' for k, v in sorted(instr.items())),
        f"- Cube start x {xy[:, 0].min():.3f}..{xy[:, 0].max():.3f} m, y {xy[:, 1].min():.3f}..{xy[:, 1].max():.3f} m "
        f"(spawn area x {R.CUBE_X}, y {R.CUBE_Y}); closest pair of starts {dmin * 100:.1f} cm apart",
        f"- Trajectory diversity: mean pairwise gripper-path difference (start-aligned, time-normalised) "
        f"{np.mean(pair) * 100:.1f} cm (min {np.min(pair) * 100:.1f} cm); grasp closes at step "
        f"{close_step.min()}..{close_step.max()}",
        "",
        "All demos come from the scripted pilot (same strategy every time: above, down, close, lift), so",
        "paths differ mainly because the cube position, pilot speed and small noise differ. They are not",
        "a substitute for varied human demonstrations.",
        "",
        "![overview](dataset_overview.png)",
        "",
        "![previews](preview_representative.jpg)",
        "",
        "Preview rows (top to bottom, workspace then wrist camera): " + ", ".join(picks),
    ]
    bad = [r for r in rows if r["problems"]]
    if bad:
        lines += ["", "## Failing episodes", ""] + [f"- {r['file']}: {r['problems']}" for r in bad]
    open(os.path.join(args.out, "validation_report.md"), "w").write("\n".join(lines) + "\n")
    print("\n".join(lines[:12]))
    raise SystemExit(1 if bad else 0)


if __name__ == "__main__":
    main()
