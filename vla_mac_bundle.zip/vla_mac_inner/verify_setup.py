"""
verify_setup.py  -  checks the recording setup before collecting data.

  python verify_setup.py [--model vla_scene_v2.xml]

Runs without a window. Checks:
  1. UR5e + Robotiq model loads (joints, actuators, cameras, cube)
  2. both cameras render valid (non-blank) images
  3. the gamepad code path moves the gripper in +X, +Y, +Z
     (driven by a software fake of pygame's joystick API, since no
     physical controller may be attached)
  4. gripper closes and opens
  5. the cube spawn area is reachable (IK reaches above all 4 corners)
  6. reset restores the arm and gripper to the start state
Prints PASS/FAIL per check and exits with code 1 if anything failed.
"""
import argparse
import sys
import types

import mujoco
import numpy as np

import record_episodes as R

results = []


def check(name, ok, detail=""):
    results.append(ok)
    print(f"[{'PASS' if ok else 'FAIL'}] {name}  {detail}")


def fake_pygame(state):
    """Minimal stand-in for pygame.joystick, driven by the `state` dict."""
    class JS:
        def __init__(self, i): pass
        def init(self): pass
        def get_name(self): return "software gamepad"
        def get_axis(self, i): return state["axes"][i]
        def get_button(self, b): return state["buttons"][b]
    return types.SimpleNamespace(
        init=lambda: None,
        event=types.SimpleNamespace(pump=lambda: None),
        joystick=types.SimpleNamespace(init=lambda: None, get_count=lambda: 1, Joystick=JS))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", default="vla_scene_v2.xml")
    args = p.parse_args()

    # 1. model
    sim = R.Sim(args.model)
    m = sim.model
    cams = [m.camera(i).name for i in range(m.ncam)]
    check("model loads", m.nu == 7 and {"workspace_camera", "wrist_camera"} <= set(cams),
          f"nq={m.nq} nv={m.nv} nu={m.nu} cameras={cams} substeps/control={sim.substeps}")

    rng = np.random.default_rng(0)
    sim.reset(rng)

    # 2. cameras
    renderer = mujoco.Renderer(m, height=R.IMAGE_H, width=R.IMAGE_W)
    for cam in ["workspace_camera", "wrist_camera"]:
        renderer.update_scene(sim.data, camera=cam)
        img = renderer.render()
        red = ((img[..., 0] > 150) & (img[..., 1] < 60) & (img[..., 2] < 60)).sum()
        check(f"{cam} image", img.shape == (R.IMAGE_H, R.IMAGE_W, 3) and img.std() > 10,
              f"shape={img.shape} std={img.std():.1f} red_cube_pixels={red}")

    # 3. gamepad -> Cartesian motion
    state = {"axes": [0.0, 0.0, 0.0, 0.0], "buttons": [0] * 8}
    sys.modules["pygame"] = fake_pygame(state)
    pad = R.GamepadInput()
    dt = 1.0 / R.CONTROL_HZ
    tests = [("+X", (0, 1.0), 0, +1), ("+Y", (1, -1.0), 1, +1), ("+Z", (3, -1.0), 2, +1)]
    for label, (axis, val), dim, sign in tests:
        sim.reset(rng)
        pad.reset(sim)
        state["axes"] = [0.0, 0.0, 0.0, 0.0]
        state["axes"][axis] = val
        start = sim.ee_pos()
        for _ in range(20):                       # 1 s of full stick
            delta, grip, ev, moving = pad.read(sim, dt)
            sim.apply_action(delta, grip)
        move = sim.ee_pos() - start
        other = np.delete(np.abs(move), dim).max()
        check(f"gamepad stick {label}", sign * move[dim] > 0.08 and other < 0.03,
              f"moved {np.round(move, 3)} m (expected ~0.12 along axis {dim})")
    state["axes"] = [0.0, 0.0, 0.0, 0.0]

    # 4. gripper
    sim.reset(rng)
    state["buttons"][R.BTN_CLOSE] = 1
    for _ in range(20):
        delta, grip, _, _ = pad.read(sim, dt)
        sim.apply_action(delta, grip)
    closed = sim.gripper_opening()
    state["buttons"][R.BTN_CLOSE] = 0
    state["buttons"][R.BTN_OPEN] = 1
    for _ in range(20):
        delta, grip, _, _ = pad.read(sim, dt)
        sim.apply_action(delta, grip)
    opened = sim.gripper_opening()
    state["buttons"][R.BTN_OPEN] = 0
    check("gripper close/open (A/B)", closed > 0.8 and opened < 0.05,
          f"closed={closed:.2f} open={opened:.2f} (0=open, 1=closed)")

    # 5. reachability of spawn corners: drive the dot above each corner
    worst = 0.0
    for x in R.CUBE_X:
        for y in R.CUBE_Y:
            sim.reset(rng)
            goal = np.array([x, y, R.CUBE_Z])
            for _ in range(int(6 * R.CONTROL_HZ)):
                step = R.TARGET_SPEED * dt
                sim.apply_action(np.clip(goal - sim.target_pos, -step, step), False)
            worst = max(worst, np.linalg.norm(sim.ee_pos() - goal))
    check("cube spawn corners reachable", worst < 0.01, f"worst gripper error {worst * 1000:.1f} mm")

    # 6. reset restores state
    sim.reset(rng)
    q0 = sim.data.qpos[sim.qpos_addr].copy()
    ee0 = sim.ee_pos()
    for _ in range(40):
        sim.apply_action(np.array([0.004, 0.004, -0.003]), True)
    sim.reset(rng)
    err_q = np.abs(sim.data.qpos[sim.qpos_addr] - q0).max()
    err_ee = np.linalg.norm(sim.ee_pos() - ee0)
    check("reset restores arm + gripper",
          err_q < 1e-9 and err_ee < 1e-9 and sim.gripper_opening() < 1e-6
          and np.allclose(sim.joint_targets, R.START_Q) and sim.grip_cmd == R.GRIPPER_OPEN,
          f"joint err={err_q:.1e} ee err={err_ee:.1e} gripper={sim.gripper_opening():.3f}")

    renderer.close()
    print(f"\n{sum(results)}/{len(results)} checks passed")
    sys.exit(0 if all(results) else 1)


if __name__ == "__main__":
    main()
