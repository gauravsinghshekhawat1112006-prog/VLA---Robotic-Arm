"""
viewer_sidebar.py  -  watch the 360-degree model, and move the cube with sliders in the viewer.

  Mac:      mjpython viewer_sidebar.py
  Windows:  python viewer_sidebar.py

In the viewer's RIGHT panel, open the "Control" section. At the bottom there are 3 sliders:
  CUBE_X     forward (+) / behind (-), metres
  CUBE_Y     robot's left (+) / right (-), metres
  CUBE_YAW   turn the cube, degrees (-30..30)
A see-through green box shows where the cube will go (orange = outside the trained area,
0.20-0.66 m from the base; closer than 0.20 m the arm hits its own base). Then press:

  R       restart: arm back to start, gripper open, cube at the slider spot, model runs
  N       new random spot (also moves the sliders there)
  P       pause / resume

Click the 3D view first so the keys reach it (not the sliders).
Ignore the arm's own sliders in that panel: the model drives the arm, so it overwrites them.

Options: --ckpt (default training/run3_360/checkpoints/best.pt) --model (default vla_scene_v3.xml)
"""
import argparse
import os
import time

import mujoco
import mujoco.viewer
import numpy as np
import torch

import record_episodes as R
from convert_dataset import preprocess_image, state_vector
from policy import PickupPolicy, TemporalEnsembler

MAX_STEPS = 25 * R.CONTROL_HZ
SLIDERS = {"CUBE_X": (-0.66, 0.66), "CUBE_Y": (-0.66, 0.66), "CUBE_YAW": (-30, 30)}


def scene_with_sliders(path):
    """Copy of the scene with 3 extra 'actuators' that do nothing except show up as sliders
    in the viewer's Control panel. They have zero force and no joint, so the robot, the cube
    and the camera images are exactly the same as in the original scene."""
    xml = open(path).read()
    xml = xml.replace("  </worldbody>",
                      '    <site name="sidebar_anchor" pos="0 0 -1" size="0.001" group="5"/>\n  </worldbody>', 1)
    sliders = "".join(f'    <general name="{n}" site="sidebar_anchor" ctrlrange="{lo} {hi}" '
                      f'gainprm="0" biasprm="0 0 0"/>\n' for n, (lo, hi) in SLIDERS.items())
    xml = xml.replace("  </actuator>", sliders + "  </actuator>", 1)
    out = os.path.join(os.path.dirname(os.path.abspath(path)), "_viewer_sidebar_scene.xml")
    with open(out, "w") as f:                  # next to the original so assets/ is found
        f.write(xml)
    return out


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", default="vla_scene_v3.xml")
    p.add_argument("--ckpt", default="training/run3_360/checkpoints/best.pt")
    p.add_argument("--seed", type=int, default=None)
    p.add_argument("--gripper", default="continuous", choices=["continuous", "binary"],
                   help="continuous = send the model's 0..1 gripper value as is; binary = old on/off (threshold 0.5)")
    args = p.parse_args()

    policy, ck = PickupPolicy.load(args.ckpt)
    size = ck["stats"]["image_size"]
    scene = scene_with_sliders(args.model)
    sim = R.Sim(scene, spawn="ring", yaw_deg=30, inner_frac=0.5)
    os.remove(scene)
    m, d = sim.model, sim.data
    slider = {n: m.actuator(n).id for n in SLIDERS}
    renderer = mujoco.Renderer(m, height=R.IMAGE_H, width=R.IMAGE_W)
    rng = np.random.default_rng(args.seed)
    keys = {"restart": False, "random": False, "pause": False}

    def on_key(k):
        if k == ord("R"):
            keys["restart"] = True
        elif k == ord("N"):
            keys["random"] = True
        elif k == ord("P"):
            keys["pause"] = not keys["pause"]

    def read_sliders():
        return [float(d.ctrl[slider[n]]) for n in SLIDERS]

    def set_sliders(x, y, yaw):
        for n, v in zip(SLIDERS, (x, y, yaw)):
            d.ctrl[slider[n]] = v

    def start(x, y, yaw):
        sim.reset(rng)                         # arm to start pose, gripper open (clears ctrl)
        set_sliders(x, y, yaw)                 # put the slider values back
        a = np.radians(yaw)
        q = sim.cube_qpos
        d.qpos[q:q + 7] = [x, y, R.CUBE_Z, np.cos(a / 2), 0, 0, np.sin(a / 2)]
        mujoco.mj_forward(m, d)
        sim.target_pos = sim.ee_pos()
        sim.cube_start_z = sim.cube_pos()[2]
        ang = np.degrees(np.arctan2(y, x)) % 360
        where = "front" if (ang < 45 or ang >= 315) else "left" if ang < 135 else "BEHIND" if ang < 225 else "right"
        r = np.hypot(x, y)
        note = "" if R.INNER_R[0] <= r <= R.RING_R[1] else "   (outside the trained 0.20-0.66 m area!)"
        print(f"\nstart: cube x={x:+.3f} y={y:+.3f} yaw={yaw:+.0f} deg  ({where}, {r:.2f} m){note}")
        return TemporalEnsembler(policy.chunk), 0, 0, False

    def draw_marker(viewer):
        x, y, yaw = read_sliders()
        ok = R.INNER_R[0] <= np.hypot(x, y) <= R.RING_R[1]
        a = np.radians(yaw)
        rot = np.array([[np.cos(a), -np.sin(a), 0], [np.sin(a), np.cos(a), 0], [0, 0, 1]])
        viewer.user_scn.ngeom = 1              # drawn only in the viewer, never in the camera images
        mujoco.mjv_initGeom(viewer.user_scn.geoms[0], mujoco.mjtGeom.mjGEOM_BOX,
                            np.array([0.032, 0.032, 0.032]), np.array([x, y, R.CUBE_Z]), rot.flatten(),
                            np.array([0.1, 0.9, 0.2, 0.35] if ok else [1.0, 0.5, 0.0, 0.45]))

    x0, y0 = R.sample_cube_xy(rng, "ring", inner_frac=0.5)
    ens, t, hold, done = start(x0, y0, 0.0)
    tries = wins = 0
    viewer = mujoco.viewer.launch_passive(m, d, key_callback=on_key)
    viewer.cam.distance, viewer.cam.azimuth, viewer.cam.elevation = 2.2, 135, -40
    viewer.cam.lookat[:] = [0.0, 0.0, 0.1]
    print("Right panel > Control > CUBE_X / CUBE_Y / CUBE_YAW, then click the 3D view and press R.")
    print("N = random spot, P = pause. Close the window to quit.")
    dt = 1.0 / R.CONTROL_HZ

    while viewer.is_running():
        tick = time.perf_counter()
        with viewer.lock():
            if keys["restart"]:
                keys["restart"] = False
                ens, t, hold, done = start(*read_sliders())
            if keys["random"]:
                keys["random"] = False
                x, y = R.sample_cube_xy(rng, "ring", inner_frac=0.5)
                ens, t, hold, done = start(x, y, float(rng.uniform(-30, 30)))
            draw_marker(viewer)

        if not keys["pause"] and not done:
            renderer.update_scene(d, camera="workspace_camera")
            ws = renderer.render()
            renderer.update_scene(d, camera="wrist_camera")
            wr = renderer.render()
            imgs = np.stack([preprocess_image(ws, size), preprocess_image(wr, size)])
            state = state_vector(d.qpos[sim.qpos_addr], sim.gripper_opening(), sim.ee_pos())
            with torch.no_grad():
                deltas, grips = policy.predict_chunk(imgs, state)
            delta, grip = ens.step(t, deltas, grips)
            with viewer.lock():
                sim.apply_action(delta, float(grip > 0.5) if args.gripper == "binary" else float(np.clip(grip, 0, 1)))
            t += 1
            hold = hold + 1 if sim.is_lifted() else 0
            result = None
            if hold == R.SUCCESS_HOLD_STEPS + 20:
                result = "SUCCESS - cube picked up"
            elif t >= MAX_STEPS:
                result = "gave up after 25 s (no pickup)"
            if result:
                tries += 1
                wins += result.startswith("SUCCESS")
                print(f"{result}  ({t / R.CONTROL_HZ:.1f} s)   score: {wins}/{tries}   "
                      f"- move the sliders and press R, or N for random")
                done = True                    # wait here, holding the cube, until R or N

        viewer.sync()
        left = dt - (time.perf_counter() - tick)
        if left > 0:
            time.sleep(left)

    viewer.close()
    renderer.close()
    print(f"\nFinal score: {wins}/{tries}")


if __name__ == "__main__":
    main()
